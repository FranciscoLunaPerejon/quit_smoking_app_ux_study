# README #

This README would normally document whatever steps are necessary to get your application up and running.

# What is this repository for?

### Quick summary ###

This repository contains the front end of SFB Taiwan Pilot. This android app has been structured in three blocks:

* User section: where the user in a quitting period can see her/his progress through achievements and badges. 
*  Message section: which contains the motivational messages received in a quitting period.
*  Support section: from where the user can access to relaxation exercise and medical information about the smoke habit. 
In addition, it's possible sign in and sign up with a new account, add the personal data necessary for begin a quitting period, information about how to use the app and the capability of change the language or configure the notification and message preferences. 

### Version ###
0.1-demo

# How do I get set up?

### Summary of set up ###

  It's recommendable use Android Studio version tools 

### Configuration ###

1.   Install Git if not installed it yet

2.   (File -> New -> Project from version control -> Git)

3.   Insert the bitbucket project url <your https link to the repository (see in bitbucket project page)> and click in test.

4.   Insert bitbucket username and password. If success, click "clone" option. 

### Dependencies ###

Android Studio uses gradle for sync dependencies

### Database configuration ###

--

### How to run tests ###

--

### Deployment instructions ###

--

# Contribution guidelines

### Writing tests ###

--

### Code review ###

--

### Other guidelines ###

--

# Who do I talk to?

### Repo owner or admin ###

--

### Other community or team contact ###

--