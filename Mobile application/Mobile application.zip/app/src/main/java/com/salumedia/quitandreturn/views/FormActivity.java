package com.salumedia.quitandreturn.views;


import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBNotification;
import com.salumedia.quitandreturn.model.SFBQuittingAttempt;
import com.salumedia.quitandreturn.model.SFBSmokingData;
import com.salumedia.quitandreturn.session.local.AlarmReceiver;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.XMLHttpPost;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.ImageConversions;
import com.salumedia.quitandreturn.utils.SFBChecks;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBCurrencyConversions;
import com.salumedia.quitandreturn.utils.SFBDate;
import com.salumedia.quitandreturn.utils.SFBEncode;
import com.salumedia.quitandreturn.utils.SFBTestForm;
import com.salumedia.quitandreturn.views.dialogs.DatePickerDialogFragment;
import com.salumedia.quitandreturn.views.dialogs.TimePickerDialogFragment;
import com.salumedia.quitandreturn.views.forms.ConfirmationSignUpFormFragment;
import com.salumedia.quitandreturn.views.forms.PersonalDataFormFragment;
import com.salumedia.quitandreturn.views.forms.PreviousSmokingHabitsFormFragment;
import com.salumedia.quitandreturn.views.forms.QuittingAttemptStartDateFormFragment;
import com.salumedia.quitandreturn.views.forms.SignUpFormFragment;
import com.salumedia.quitandreturn.views.forms.TestFagerstromFormFragment;
import com.salumedia.quitandreturn.views.forms.TestRichmondFormFragment;
import com.salumedia.quitandreturn.views.forms.WeekDaysPreferencesFormFragment;
import com.salumedia.quitandreturn.views.main_navigationdrawer_sections.TabsInitFragment;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;



/**
 * Created by Francisco on 12/1/17.
 */

public class FormActivity extends AppCompatActivity implements
        PersonalDataFormFragment.OnDemographicsDataFormInteractionListener,
        DatePickerDialogFragment.OnDatePickerFragmentInteractionListener,
        TimePickerDialogFragment.OnTimePickedListener {

    private UserRegistrationTask mRegTask = null;
    private ConfirmUserRegistrationTask mConfirmRegTask = null;
    private UserSetPersonalDataTask mSetPersonalDataTask = null;
    private SaveWeekDaysPreferencesTask mSaveWeekDaysPreferencesTask = null;
    private AddQuittingAttemptTask mAddQuitAttempt = null;

    FragmentManager mFragmentManager = getSupportFragmentManager();
    Toolbar toolbar;

    // Progress completing form information Views
    CardView progressFormView;
    FloatingActionButton goToPersonalDataFormButton;
    FloatingActionButton goToFagerstromFormButton;
    FloatingActionButton goToRichmondFormButton;
    FloatingActionButton goToPreviousSmokingHabitsFormButton;


    // where is saved the button id that invoke a DatePickerDialogFragment
    int idButtonDatePicker;

    // Extract the type of form that have been requested
    int id;

    // Button pressed which save the form values
    int idSaveButtonPressed;

    // Session information
    SessionData sessionData;

    List<RadioGroup> radioGroupList;

    //SignUp Data Views
    EditText username;

    // Demographics Data Views
    EditText name;
    RadioGroup gender;
    EditText birthday;
    RadioGroup employment;
    EditText startSmokingDate;
    RadioGroup havePatientCode;
    EditText patientCode;
    TextView patientCodeTextView;

    // Quitting Attempt Data Views
    EditText dailyCigarettes;
    EditText weeklyExpenditure;
    Spinner currency;
    DatePicker startQuittingAttempt;


    Fragment fragment;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sessionData = SessionData.getSessionData(getApplicationContext());
        id = getIntent().getExtras().getInt("idForm");

        setContentView(R.layout.activity_form);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        progressFormView = (CardView) findViewById(R.id.progress_form_bar);

        goToPersonalDataFormButton = (FloatingActionButton) findViewById(R.id.progress_form_view_button_1);
        goToFagerstromFormButton = (FloatingActionButton) findViewById(R.id.progress_form_view_button_2);
        goToRichmondFormButton = (FloatingActionButton) findViewById(R.id.progress_form_view_button_3);
        goToPreviousSmokingHabitsFormButton = (FloatingActionButton) findViewById(R.id.progress_form_view_button_4);

        //This button have a "check and save" purpose, depending of form-fragment that contains the activity
        Button button2 = (Button) findViewById(R.id.button2_toolbar);

        toolbar.setNavigationIcon(R.drawable.ic_go_back);
        toolbar.setTitle(R.string.menu_08_form);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                switch (id) {
                    case SFBConstantsAndCodes.SIGN_UP_FORM_CONFIRMATION_ID:
                    case SFBConstantsAndCodes.SIGN_UP_FORM_ID:
                        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                        finish();
                        break;
                    default:
                        finish();
                        break;
                }
            }
        });

        // Display selected form by screen
        loadForm(id, savedInstanceState);
        // Indicate the current form in the progress form information bar
        indicateCurrentForm();
        // Refresh the completion  form progress in the form progress information bar
        updateCompletionFormProgress();

        View.OnClickListener onClickSaveFormButtonListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                idSaveButtonPressed = v.getId();

                if((sessionData.isQuittingDateFilled() && (
                        v.getId() == R.id.progress_form_view_button_2
                                || v.getId() == R.id.progress_form_view_button_3
                                || v.getId() == R.id.progress_form_view_button_4))){
                    Toast toast = Toast.makeText(getApplicationContext(), R.string.cannot_edit_smoking, Toast.LENGTH_SHORT);
                    toast.show();
                }else {
                    checkIfFormIsCorrectlyFilledAndStored();
                }
            }
        };

        button2.setVisibility(View.VISIBLE);
        button2.setOnClickListener(onClickSaveFormButtonListener);

        goToPersonalDataFormButton.setOnClickListener(onClickSaveFormButtonListener);
        goToFagerstromFormButton.setOnClickListener(onClickSaveFormButtonListener);
        goToRichmondFormButton.setOnClickListener(onClickSaveFormButtonListener);
        goToPreviousSmokingHabitsFormButton.setOnClickListener(onClickSaveFormButtonListener);

    }

    private void indicateCurrentForm() {
        int colorPrimary = getResources().getColor(R.color.colorPrimary);
        int colorWhite = getResources().getColor(R.color.colorWhite);

        RelativeLayout selectFagerstromFormInformationBackground  = (RelativeLayout) findViewById(R.id.go_to_fagerstrom_test_background);
        RelativeLayout selectRichmondFormInformationBackground  = (RelativeLayout) findViewById(R.id.go_to_richmond_test_background);
        RelativeLayout selectPersonalDataFormInformationBackground  = (RelativeLayout) findViewById(R.id.go_to_personal_data_form_background);
        RelativeLayout  selectPreviousSmokingHabitsFormInformationBackground  = (RelativeLayout) findViewById(R.id.go_to_previous_smoking_habits_form_background);

        selectFagerstromFormInformationBackground.setBackgroundColor(colorWhite);
        selectRichmondFormInformationBackground.setBackgroundColor(colorWhite);
        selectPersonalDataFormInformationBackground.setBackgroundColor(colorWhite);
        selectPreviousSmokingHabitsFormInformationBackground.setBackgroundColor(colorWhite);

        switch (id) {
            case SFBConstantsAndCodes.PERSONAL_DATA_FORM_ID:
                selectPersonalDataFormInformationBackground.setBackgroundColor(colorPrimary);
                break;
            case SFBConstantsAndCodes.FAGERSTROM_TEST_FORM_ID:
                selectFagerstromFormInformationBackground.setBackgroundColor(colorPrimary);
                break;
            case SFBConstantsAndCodes.RICHMOND_TEST_FORM_ID:
                selectRichmondFormInformationBackground.setBackgroundColor(colorPrimary);
                break;
            case SFBConstantsAndCodes.PREVIOUS_SMOKING_HABITS_ID:
                selectPreviousSmokingHabitsFormInformationBackground.setBackgroundColor(colorPrimary);
            default:
                break;
        }
    }

    private void updateCompletionFormProgress(){
        int colorFormFilled = getResources().getColor(R.color.colorAccent);
        int colorFormIncomplete = getResources().getColor(R.color.colorIncompleteForm);
        int colorFormDisabled = getResources().getColor(R.color.colorDivider);

        if(sessionData.isFilledPersonalData())
            goToPersonalDataFormButton.setBackgroundTintList(ColorStateList.valueOf(colorFormFilled));
        else if(sessionData.isIncompletePersonalData())
            goToPersonalDataFormButton.setBackgroundTintList(ColorStateList.valueOf(colorFormIncomplete));
        if(sessionData.isQuittingDateFilled()){
            goToFagerstromFormButton.setBackgroundTintList(ColorStateList.valueOf(colorFormDisabled));
            goToRichmondFormButton.setBackgroundTintList(ColorStateList.valueOf(colorFormDisabled));
            goToPreviousSmokingHabitsFormButton.setBackgroundTintList(ColorStateList.valueOf(colorFormDisabled));
        }else {
            if (sessionData.isFilledFagerstromTest())
                goToFagerstromFormButton.setBackgroundTintList(ColorStateList.valueOf(colorFormFilled));
            if (sessionData.isFilledRichmondTest())
                goToRichmondFormButton.setBackgroundTintList(ColorStateList.valueOf(colorFormFilled));
            if(sessionData.isFilledPreviousSmokingHabits())
                goToPreviousSmokingHabitsFormButton.setBackgroundTintList(ColorStateList.valueOf(colorFormFilled));
            if(!(sessionData.isFilledPersonalData() && sessionData.isFilledFagerstromTest() &&
                    sessionData.isFilledRichmondTest() && sessionData.isFilledPreviousSmokingHabits()))
                goToPreviousSmokingHabitsFormButton.setBackgroundColor(colorFormDisabled);
        }
    }

    private void checkIfFormIsCorrectlyFilledAndStored() {
        SFBTestForm testForm;
        int tResult;
        Toast toast;

        String textErrorAlert = "";
        Toast note = Toast.makeText(getApplicationContext(), "", Toast.LENGTH_SHORT);

        //Hide keyboard
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(findViewById(R.id.form_content).getWindowToken(), 0);

        switch (id) {
            case SFBConstantsAndCodes.SIGN_UP_FORM_ID:
                username = (EditText) findViewById(R.id.sign_up_user_name);
                CheckBox termsOfUseCheckBox = (CheckBox) findViewById(R.id.terms_of_use_checkBox);

                boolean checkNick = SFBChecks.isValidEmail(username.getText());

                if (checkNick) {
                    if(termsOfUseCheckBox.isChecked()) {
                        mRegTask = new UserRegistrationTask(username.getText().toString(), termsOfUseCheckBox.isChecked(), FormActivity.this);
                        mRegTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
                    }else {
                        textErrorAlert = getString(R.string.error_must_accept_terms_of_use);
                        note.setText(textErrorAlert);
                        note.show();
                    }
                } else {
                    textErrorAlert = getString(R.string.nick_must_be_email);
                    note.setText(textErrorAlert);
                    note.show();
                }
                break;

            case SFBConstantsAndCodes.SIGN_UP_FORM_CONFIRMATION_ID:

                String usernameInExtras = getIntent().getExtras().getString("username");
                String tokenInExtras = getIntent().getExtras().getString("token");
                EditText pass = (EditText) findViewById(R.id.sign_up_pass);
                EditText repeatPass = (EditText) findViewById(R.id.sign_up_repeat_pass);

                boolean checkRepeatPass = pass.getText().toString().equals(repeatPass.getText().toString());
                boolean checkPassSize = pass.getText().toString().length() >= 4;

                if (!(checkRepeatPass && checkPassSize)) {
                    if (!checkRepeatPass)
                        textErrorAlert = textErrorAlert + getString(R.string.pass_not_match);
                    if (!checkPassSize)
                        textErrorAlert = textErrorAlert + getString(R.string.pass_too_short);
                    note.setText(textErrorAlert);
                    note.show();
                }else{
                    mConfirmRegTask = new ConfirmUserRegistrationTask(usernameInExtras, pass.getText().toString(), tokenInExtras, getApplicationContext());
                    mConfirmRegTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
                }

                break;

            case SFBConstantsAndCodes.PERSONAL_DATA_FORM_ID:
                name = (EditText) findViewById(R.id.patient_name);
                gender = (RadioGroup) findViewById(R.id.gender);
                birthday = (EditText) findViewById(R.id.change_birthdate_button);
                employment = (RadioGroup) findViewById(R.id.employment_situation);
                startSmokingDate = (EditText) findViewById(R.id.change_start_smoking_date);

                havePatientCode = (RadioGroup) findViewById(R.id.patient_code_radio_group);
                patientCode = (EditText) findViewById(R.id.patient_code_edit_text);
                patientCodeTextView = (TextView) findViewById(R.id.patient_code_text_view);

                if(havePatientCode.getCheckedRadioButtonId() == R.id.have_a_patient_code && patientCode.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(), R.string.error_empty_patient_code, Toast.LENGTH_SHORT).show();
                }else {
                    String patientCodeString;
                    if(havePatientCode.getCheckedRadioButtonId() == R.id.not_have_a_patient_code) {
                        patientCodeString = "";
                    }else{
                        patientCodeString = patientCode.getText().toString();
                    }
                    mSetPersonalDataTask = new UserSetPersonalDataTask(name, gender, birthday, employment, startSmokingDate, patientCodeString, FormActivity.this);
                    mSetPersonalDataTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
                }
                break;

            case SFBConstantsAndCodes.RICHMOND_TEST_FORM_ID:
                radioGroupList = new ArrayList<>();
                radioGroupList.add((RadioGroup) findViewById(R.id.richmond_q1));
                radioGroupList.add((RadioGroup) findViewById(R.id.richmond_q2));
                radioGroupList.add((RadioGroup) findViewById(R.id.richmond_q3));
                radioGroupList.add((RadioGroup) findViewById(R.id.richmond_q4));
                testForm = SFBTestForm.newInstance(SFBTestForm.Type.RICHMOND, radioGroupList);
                if (testForm.isFilled()) {
                    Integer[] answers = new Integer[4];
                    for (int i = 0; i < answers.length; i++) {
                        int idSelectedRadioButton = radioGroupList.get(i).getCheckedRadioButtonId();
                        answers[i] = radioGroupList.get(i).indexOfChild(findViewById(idSelectedRadioButton));
                    }
                    sessionData.setRichmondAnswers(answers);
                    tResult = testForm.getTestResults();
                    sessionData.setRichmondResult(tResult);
                    toast = Toast.makeText(getApplicationContext(), R.string.motivation_test_completed, Toast.LENGTH_SHORT);
                    toast.show();
                    selectFormToGoByButtonPressed();
                } else {
                    toast = Toast.makeText(getApplicationContext(), R.string.fill_all_questions, Toast.LENGTH_SHORT);
                    toast.show();
                }
                break;
            case SFBConstantsAndCodes.FAGERSTROM_TEST_FORM_ID:
                radioGroupList = new ArrayList<>();
                radioGroupList.add((RadioGroup) findViewById(R.id.fagerstrom_q1));
                radioGroupList.add((RadioGroup) findViewById(R.id.fagerstrom_q2));
                radioGroupList.add((RadioGroup) findViewById(R.id.fagerstrom_q3));
                radioGroupList.add((RadioGroup) findViewById(R.id.fagerstrom_q4));
                radioGroupList.add((RadioGroup) findViewById(R.id.fagerstrom_q5));
                radioGroupList.add((RadioGroup) findViewById(R.id.fagerstrom_q6));
                testForm = SFBTestForm.newInstance(SFBTestForm.Type.FAGERSTROM, radioGroupList);
                if (testForm.isFilled()) {

                    Integer[] answers = new Integer[6];
                    for (int i = 0; i < answers.length; i++) {
                        int idSelectedRadioButton = radioGroupList.get(i).getCheckedRadioButtonId();
                        answers[i] = radioGroupList.get(i).indexOfChild(findViewById(idSelectedRadioButton));
                    }
                    sessionData.setFagerstromAnswers(answers);
                    tResult = testForm.getTestResults();
                    sessionData.setFagerstromResult(tResult);
                    toast = Toast.makeText(getApplicationContext(), R.string.adiction_test_completed, Toast.LENGTH_SHORT);
                    toast.show();
                    selectFormToGoByButtonPressed();
                } else {
                    toast = Toast.makeText(getApplicationContext(), R.string.fill_all_questions, Toast.LENGTH_SHORT);
                    toast.show();
                }
                break;
            case SFBConstantsAndCodes.WEEK_DAYS_PREFERENCES_ID:
                String[] preferences = ((WeekDaysPreferencesFormFragment) fragment).checkForCorrectTimeValues();
                if (preferences.length != 0) {
                    mSaveWeekDaysPreferencesTask = new SaveWeekDaysPreferencesTask(FormActivity.this, preferences);
                    mSaveWeekDaysPreferencesTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
                } else {
                    Snackbar.make(findViewById(R.id.form_content), R.string.error_init_end_match, Snackbar.LENGTH_LONG).show();
                }
                break;
            case SFBConstantsAndCodes.PREVIOUS_SMOKING_HABITS_ID:
                dailyCigarettes = (EditText) findViewById(R.id.daily_cigarettes);
                weeklyExpenditure = (EditText) findViewById(R.id.weekly_expenditure);
                currency = (Spinner) findViewById(R.id.currency);

                boolean checkFields = checkPreviousSmokingHabits(); // method to check if data is correct
                if (checkFields) {
                    sessionData.setPreviousDailyCigarettes(Float.parseFloat(dailyCigarettes.getText().toString()));
                    sessionData.setWeeklyTobaccoExpenditure(Float.parseFloat(weeklyExpenditure.getText().toString()));
                    sessionData.setCurrency(currency.getSelectedItem().toString());
                    selectFormToGoByButtonPressed();
                }
                break;
            case SFBConstantsAndCodes.START_QUITTING_ATTEMPT_ID:
                startQuittingAttempt = (DatePicker) findViewById(R.id.quitting_attempt_date);
                boolean checkDate = checkCorrectQuittingAttemptDate(); // tutorial method to check if data is correct
                if (checkDate) {
                    //Background task: send to server the new quitting attempt information
                    mAddQuitAttempt = new AddQuittingAttemptTask(
                            FormActivity.this);
                    mAddQuitAttempt.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
                }
                break;
            default:
                break;
        }
    }

    private void selectFormToGoByButtonPressed(){
        int idFormToGo;
        switch (idSaveButtonPressed) {
            case R.id.progress_form_view_button_1:
                idFormToGo = SFBConstantsAndCodes.PERSONAL_DATA_FORM_ID;
                loadForm(idFormToGo, new Bundle());
                break;
            case R.id.progress_form_view_button_2:
                idFormToGo = SFBConstantsAndCodes.FAGERSTROM_TEST_FORM_ID;
                loadForm(idFormToGo, new Bundle());
                break;
            case R.id.progress_form_view_button_3:
                idFormToGo = SFBConstantsAndCodes.RICHMOND_TEST_FORM_ID;
                loadForm(idFormToGo, new Bundle());

                break;
            case R.id.progress_form_view_button_4:
                idFormToGo = SFBConstantsAndCodes.PREVIOUS_SMOKING_HABITS_ID;
                loadForm(idFormToGo, new Bundle());
                break;
            default:
                if (id != SFBConstantsAndCodes.SIGN_UP_FORM_ID &&
                        id != SFBConstantsAndCodes.SIGN_UP_FORM_CONFIRMATION_ID &&
                        id != SFBConstantsAndCodes.WEEK_DAYS_PREFERENCES_ID &&
                        id != SFBConstantsAndCodes.START_QUITTING_ATTEMPT_ID) {
                    if (existFormsToComplete()) {
                        goToNextNotCompletedForm(new Bundle());
                    } else
                        finish();
                }
                break;
        }
        indicateCurrentForm();
    }

    private boolean existFormsToComplete() {
        return !(sessionData.isFilledPersonalData() &&
                sessionData.isFilledFagerstromTest() &&
                sessionData.isFilledRichmondTest() &&
                sessionData.isFilledPreviousSmokingHabits());
    }

    private void goToNextNotCompletedForm(Bundle savedInstanceState) {
        switch (id) {
            case SFBConstantsAndCodes.PERSONAL_DATA_FORM_ID:
                if (!sessionData.isFilledFagerstromTest())
                    loadForm(SFBConstantsAndCodes.FAGERSTROM_TEST_FORM_ID, savedInstanceState);
                else if (!sessionData.isFilledRichmondTest())
                    loadForm(SFBConstantsAndCodes.RICHMOND_TEST_FORM_ID, savedInstanceState);
                else if(!sessionData.isFilledPreviousSmokingHabits())
                    loadForm(SFBConstantsAndCodes.PREVIOUS_SMOKING_HABITS_ID, savedInstanceState);
                break;
            case SFBConstantsAndCodes.FAGERSTROM_TEST_FORM_ID:
                if (!sessionData.isFilledRichmondTest())
                    loadForm(SFBConstantsAndCodes.RICHMOND_TEST_FORM_ID, savedInstanceState);
                else if(!sessionData.isFilledPreviousSmokingHabits())
                    loadForm(SFBConstantsAndCodes.PREVIOUS_SMOKING_HABITS_ID, savedInstanceState);
                else if (!sessionData.isFilledPersonalData())
                    loadForm(SFBConstantsAndCodes.PERSONAL_DATA_FORM_ID, savedInstanceState);
                break;
            case SFBConstantsAndCodes.RICHMOND_TEST_FORM_ID:
                if(!sessionData.isFilledPreviousSmokingHabits())
                    loadForm(SFBConstantsAndCodes.PREVIOUS_SMOKING_HABITS_ID, savedInstanceState);
                else if (!sessionData.isFilledPersonalData())
                    loadForm(SFBConstantsAndCodes.PERSONAL_DATA_FORM_ID, savedInstanceState);
                else if (!sessionData.isFilledFagerstromTest())
                    loadForm(SFBConstantsAndCodes.FAGERSTROM_TEST_FORM_ID, savedInstanceState);
                break;
            case SFBConstantsAndCodes.PREVIOUS_SMOKING_HABITS_ID:
                if (!sessionData.isFilledPersonalData())
                    loadForm(SFBConstantsAndCodes.PERSONAL_DATA_FORM_ID, savedInstanceState);
                else if (!sessionData.isFilledFagerstromTest())
                    loadForm(SFBConstantsAndCodes.FAGERSTROM_TEST_FORM_ID, savedInstanceState);
                else if (!sessionData.isFilledRichmondTest())
                    loadForm(SFBConstantsAndCodes.RICHMOND_TEST_FORM_ID, savedInstanceState);
                break;
            default:
                break;
        }
    }

    private void loadForm(int formId, Bundle savedInstanceState) {
        String tag;
        switch (formId) {
            case SFBConstantsAndCodes.PERSONAL_DATA_FORM_ID:
                if(sessionData.isQuittingDateFilled())
                    progressFormView.setVisibility(View.GONE);
                fragment = PersonalDataFormFragment.newInstance(savedInstanceState);
                tag = PersonalDataFormFragment.TAG;
                break;
            case SFBConstantsAndCodes.RICHMOND_TEST_FORM_ID:
                fragment = TestRichmondFormFragment.newInstance(savedInstanceState);
                tag = TestRichmondFormFragment.TAG;
                break;
            case SFBConstantsAndCodes.FAGERSTROM_TEST_FORM_ID:
                fragment = TestFagerstromFormFragment.newInstance(savedInstanceState);
                tag = TestFagerstromFormFragment.TAG;
                break;
            case SFBConstantsAndCodes.PREVIOUS_SMOKING_HABITS_ID:
                fragment = PreviousSmokingHabitsFormFragment.newInstance(savedInstanceState);
                tag = PreviousSmokingHabitsFormFragment.TAG;
                break;
            case SFBConstantsAndCodes.START_QUITTING_ATTEMPT_ID:
                fragment = QuittingAttemptStartDateFormFragment.newInstance(savedInstanceState);
                progressFormView.setVisibility(View.GONE);
                tag = QuittingAttemptStartDateFormFragment.TAG;
                break;
            case SFBConstantsAndCodes.SIGN_UP_FORM_CONFIRMATION_ID:
                fragment = ConfirmationSignUpFormFragment.newInstance(savedInstanceState);
                progressFormView.setVisibility(View.GONE);
                tag = ConfirmationSignUpFormFragment.TAG;
                break;
            case SFBConstantsAndCodes.SIGN_UP_FORM_ID:
                fragment = SignUpFormFragment.newInstance(savedInstanceState);
                progressFormView.setVisibility(View.GONE);
                tag = SignUpFormFragment.TAG;
                break;
            case SFBConstantsAndCodes.WEEK_DAYS_PREFERENCES_ID:
                fragment = WeekDaysPreferencesFormFragment.newInstance(savedInstanceState);
                progressFormView.setVisibility(View.GONE);
                tag = WeekDaysPreferencesFormFragment.TAG;
                break;
            default:
                fragment = new TabsInitFragment();
                tag = null;
        }
        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        transaction.replace(R.id.form_content, fragment, tag);
        transaction.commit();
        id = formId;
        updateCompletionFormProgress();
    }

    @Override
    public void setDateInDatePicker(int id, String title) {
        this.idButtonDatePicker = id;
        callDatePicker(title);
    }

    private void callDatePicker(String title) {
        DatePickerDialogFragment fragment =  DatePickerDialogFragment.newInstance(title);

        fragment.show(getSupportFragmentManager(), "date");
    }

    @Override
    public void setDate(final Calendar calendar) {
        ((EditText) findViewById(idButtonDatePicker)).setText(SFBDate.dateToString(calendar));
    }


    @Override
    public void onDemographicsDataFormInteraction(Uri uri) {

    }

    @Override
    public void onTimePicked(int viewId, int hour, int minute, String titleInterval) {
        String title = hour + ":" + (minute == 0 ? "00" : minute);
        ((Button) findViewById(viewId)).setText(((WeekDaysPreferencesFormFragment) fragment).normalize(title));
    }


    /**
     * This method check if all fields are correctly filled, mark the incorrect fields in the screen
     * to alert to the user and show text clarification.
     *
     * @return true if all fields are been correctly filled, false if not.
     */
    private boolean checkPreviousSmokingHabits() {

        boolean res = true;

        String errorText = "";

        Drawable incorrectFieldDrawable = getResources().getDrawable(R.drawable.incorrect_text_field);
        Drawable correctFieldDrawable = getResources().getDrawable(R.drawable.text_field);

        if (dailyCigarettes.getText().toString().equals("") || weeklyExpenditure.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(), R.string.error_all_fields_required, Toast.LENGTH_LONG).show();
            dailyCigarettes.setBackgroundDrawable(incorrectFieldDrawable);
            weeklyExpenditure.setBackgroundDrawable(incorrectFieldDrawable);
            res = false;
        } else {

            //Check for daily cigarettes correctly filled

            Float fDailyCigarettes = Float.parseFloat(dailyCigarettes.getText().toString());

            // Minimum and maximum daily cigarettes exceeded
            if (fDailyCigarettes >= 1f && fDailyCigarettes < 150f) {
                dailyCigarettes.setBackgroundDrawable(correctFieldDrawable);
            } else {
                dailyCigarettes.setBackgroundDrawable(incorrectFieldDrawable);
                errorText = fDailyCigarettes >= 1f ? getString(R.string.error_too_many_cigarettes) : getString(R.string.min_cigarettes);
                Toast.makeText(getApplicationContext(), errorText, Toast.LENGTH_LONG).show();
                res = false;
            }

            //Check for weekly expenditure correctly filled

            Float fWeeklyExpenditure = Float.parseFloat(weeklyExpenditure.getText().toString());

            // TODO: conversionCoefficient can not be enough. It's necessary to know how expensive is
            // tobacco in each region.
            Float conversionCoefficient = SFBCurrencyConversions.getConversionCoefficientToEuros(currency.getSelectedItem().toString());

            // Minimum and maximum weekly expenditure exceeded
            if (fWeeklyExpenditure > 0f * conversionCoefficient && fWeeklyExpenditure <= 5000f * conversionCoefficient) {
                weeklyExpenditure.setBackgroundDrawable(correctFieldDrawable);
            } else {
                if (fWeeklyExpenditure > 5000f * conversionCoefficient)
                    errorText = errorText.equals("") ? getString(R.string.error_too_much_expenditure) : getString(R.string.error_values_so_big);
                else
                    errorText = errorText.equals("") ? getString(R.string.expenditure_cannot_zero) : getString(R.string.incorrect_amounts);
                weeklyExpenditure.setBackgroundDrawable(incorrectFieldDrawable);
                Toast.makeText(getApplicationContext(), errorText, Toast.LENGTH_LONG).show();
                res = false;
            }
        }
        if(res){
            Toast.makeText(getApplicationContext(), R.string.correct_previous_smoking_habits, Toast.LENGTH_LONG).show();
        }
        return res;
    }

    /**
     * This method check if the quitting attempt date is coherent with other personal data pre-established.
     *
     * @return true if all fields are been correctly filled, false if not.
     */
    private boolean checkCorrectQuittingAttemptDate(){

        boolean res = true;

        String errorText = "";

        //Check for start quitting attempt date is correct
        Calendar cQuittingDate = new java.util.GregorianCalendar(startQuittingAttempt.getYear(),
                startQuittingAttempt.getMonth(), startQuittingAttempt.getDayOfMonth());
        Calendar cSmokingDate = sessionData.getStartedSmokingDate();
        if (cSmokingDate.after(cQuittingDate)) {
            Drawable incorrectDateStyle = getResources().getDrawable(R.drawable.datepicker_incorrect);
            errorText = getString(R.string.error_illogical_quitting_date);
            startQuittingAttempt.setBackgroundDrawable(incorrectDateStyle);
            Toast.makeText(getApplicationContext(), errorText, Toast.LENGTH_SHORT).show();
            res = false;
        } else {
            Drawable correctDateStyle = getResources().getDrawable(R.drawable.datepicker);
            startQuittingAttempt.setBackgroundDrawable(correctDateStyle);
        }

        return res;
    }

    /**
     * An {@link AsyncTask} to send to the server the sign up request.
     */
    public class UserRegistrationTask extends AsyncTask<Void, Void, Boolean> {

        private final String mUsername;
        private final String mTermsAccepted;
        private final Context mContext;
        private Integer failCode;
        private ProgressDialog mProgressDialog;
        private final int CODE_NO_FAILS = 0;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;
        private final int CODE_ERROR_REGISTER_USER = 5;

        UserRegistrationTask(String username, Boolean termsOfUseAccepted, Context context) {
            mUsername = username;
            mTermsAccepted = termsOfUseAccepted? "t":"f";
            mContext = context;
            failCode = CODE_NO_FAILS;
        }


        @Override
        protected Boolean doInBackground(Void... voids) {
            /**
             * create xml file
             * string xml request with user in md5
             *
             * check connectivity
             */

            Boolean userCreated = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();
            //String fileXMLRequest = file.getAllDataRequest(mUsername, SFBEncode.encodeToMD5(mPassword));//file.getAllDataRequest(mUsername); //SFBEncode.encodeToMD5(mUsername), token

            if (XMLHttpPost.isConnectedToInternet(FormActivity.this)) {

                String fileXMLRequest = file.registration(mUsername, mTermsAccepted);

                // ENVIAR PETICIÓN HTTP POST
                String responseXML = null;

                try {
                    //Introduces XML y devuelve respuesta del servidor
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, getApplicationContext(), null);


                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }

                userCreated = responseXML == "created";
                if (!userCreated)
                    failCode = CODE_ERROR_REGISTER_USER;

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }

            return userCreated;
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog = new ProgressDialog(mContext);
                mProgressDialog.setMessage(getString(R.string.checking_user));
                mProgressDialog.setCancelable(false);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mRegTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (success) {
                Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), R.string.reset_password_email_sent, Snackbar.LENGTH_LONG);
                View snackbarView = snackbar.getView();
                TextView textView = (TextView) snackbarView.findViewById(android.support.design.R.id.snackbar_text);
                textView.setMaxLines(5);
                snackbar.show();
            } else {
                String errorMessage = "Error";
                switch (failCode) {
                    case CODE_ERROR_REGISTER_USER:
                        errorMessage = getString(R.string.error_getting_user);
                        Snackbar.make(findViewById(android.R.id.content), R.string.user_already_exists, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    case CODE_ERROR_INTERNET_CONNECTION:
                        errorMessage = getString(R.string.error_internet_connection);
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    default:
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                }
            }
        }



        @Override
        protected void onCancelled() {
            mRegTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            //showProgress(false);
        }
    }

    /**
     * An {@link AsyncTask} to send to the server the sign up request.
     */
    public class ConfirmUserRegistrationTask extends AsyncTask<Void, Void, Boolean> {

        LocalDataBaseHelper db = new LocalDataBaseHelper(getApplicationContext());


        private final String mUsername;
        private final String mPassword;
        private final String mToken;
        private final Context mContext;
        private Integer failCode;
        private ProgressDialog mProgressDialog;
        private final int CODE_NO_FAILS = 0;
        private final int CODE_ERROR_USER_EXISTS = 3;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;
        private final int CODE_ERROR_REQUEST_INVALID = 5;

        ConfirmUserRegistrationTask(String username, String password, String token, Context context) {
            mUsername = username;
            mPassword = password;
            mToken = token;
            mContext = context;
            failCode = CODE_NO_FAILS;
        }


        @Override
        protected Boolean doInBackground(Void... voids) {
            /**
             * create xml file
             * string xml request with user in md5
             *
             * check connectivity
             */

            Boolean userCreated = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();
            //String fileXMLRequest = file.getAllDataRequest(mUsername, SFBEncode.encodeToMD5(mPassword));//file.getAllDataRequest(mUsername); //SFBEncode.encodeToMD5(mUsername), token

            if (XMLHttpPost.isConnectedToInternet(FormActivity.this)) {

                String fileXMLRequest = file.confirmUserRegistration(mUsername, mToken, SFBEncode.encodeToMD5(mPassword), sessionData.getFCMToken());

                // ENVIAR PETICIÓN HTTP POST
                String responseXML = "";

                try {
                    //Introduces XML y devuelve respuesta del servidor
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, getApplicationContext(), null);


                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }

                userCreated = responseXML == "created";
                if (!userCreated)
                    if (responseXML.equals("forbidden"))
                        failCode = CODE_ERROR_REQUEST_INVALID;
                    else if(responseXML.equals("method_not_allowed"))
                        failCode = CODE_ERROR_USER_EXISTS;

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }

            return userCreated;
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog = new ProgressDialog(mContext);
                mProgressDialog.setMessage(getString(R.string.checking_user));
                mProgressDialog.setCancelable(false);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mRegTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (success) {

                SessionData sessionData = SessionData.getSessionData(FormActivity.this);
                String credentials = mUsername + ":" + SFBEncode.encodeToMD5(mPassword);
                sessionData.setUserCredentials(credentials);

                Intent mainActivity = new Intent(getApplicationContext(), MainActivity.class);
                mainActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(mainActivity);
                db.insertMessageNotification(SFBNotification.getWelcomeNotification(Calendar.getInstance(),mContext));
                createExtendedFormResponsesInDataBase();

                Toast toast = Toast.makeText(FormActivity.this, getString(R.string.new_user_registration_confirmed), Toast.LENGTH_SHORT);
                toast.show();

                finish();


            } else {
                String errorMessage = "Error";
                switch (failCode) {
                    case CODE_ERROR_REQUEST_INVALID:
                        Snackbar.make(findViewById(android.R.id.content), R.string.error_request_invalid, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    case CODE_ERROR_USER_EXISTS:
                        Snackbar.make(findViewById(android.R.id.content), R.string.error_user_already_confirmed, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    case CODE_ERROR_INTERNET_CONNECTION:
                        errorMessage = getString(R.string.error_internet_connection);
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    default:
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                }
            }
        }

        @Override
        protected void onCancelled() {
            mConfirmRegTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            //showProgress(false);
        }

        private void createExtendedFormResponsesInDataBase() {

            int tagReferenceID = 0;
            int numberOfAnswersReferencesID = 4;

            Resources resources = getResources();
            TypedArray extendedFormQuestionsReferences = resources.obtainTypedArray(R.array.extended_form_questions);

            int questionTagsID = extendedFormQuestionsReferences.getResourceId(tagReferenceID, 0);

            @SuppressWarnings("ResourceType") int questionNumberOfAnswersID = extendedFormQuestionsReferences.getResourceId(numberOfAnswersReferencesID, 0);
            if(questionTagsID > 0 && questionNumberOfAnswersID >0){
                String[] questionTags = resources.getStringArray(questionTagsID);
                int[] questionNumberOfAnswers = resources.getIntArray(questionNumberOfAnswersID);
                for(int i=0; i<questionTags.length; i++){
                    Boolean[] questionResponses = new Boolean[questionNumberOfAnswers[i]];
                    Arrays.fill(questionResponses, false);
                    db.insertExtendedFormQuestion(questionTags[i], questionResponses);
                }
            }
            extendedFormQuestionsReferences.recycle();
        }

    }
    /**
     * An {@link AsyncTask} to send to the server the new user personal data.
     * NOTE: if an error happen, the preferences are stored neither in local nor the server, and
     * alert to the user about this.
     */
    private class UserSetPersonalDataTask extends AsyncTask<Void, Void, Boolean> {

        private EditText name;
        private RadioGroup gender;
        private EditText birthday;
        private RadioGroup employment;
        private EditText startSmokingDate;
        private String patientCode;

        private final Context mContext;
        private Integer failCode;
        private ProgressDialog mProgressDialog;

        private final Integer minUserAgeLimit = 7;
        private final Integer minStartSmokingAgeLimit = 5;

        private final int CODE_NO_FAILS = 0;
        private final int CODE_ERROR_INCORRECT_PATIENT_CODE = 1;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;
        private final int CODE_ERROR_NOT_STORED = 6;
        private final int CODE_ERROR_SOME_DATA_INCORRECT = 7;

        private String incorrectDataErrorText;

        UserSetPersonalDataTask(EditText name, RadioGroup gender, EditText birthday, RadioGroup employment,
                                EditText startSmokingDate, String patientCode, Context context) {
            this.name = name;
            this.gender = gender;
            this.birthday = birthday;
            this.employment = employment;
            this.startSmokingDate = startSmokingDate;
            this.patientCode = patientCode;

            mContext = context;
            failCode = CODE_NO_FAILS;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {

            Boolean everythingCorrect = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();
            //String fileXMLRequest = file.getAllDataRequest(mUsername, SFBEncode.encodeToMD5(mPassword));//file.getAllDataRequest(mUsername); //SFBEncode.encodeToMD5(mUsername), token

            if (XMLHttpPost.isConnectedToInternet(FormActivity.this)) {
                // SEND HTTP POST REQUEST
                String responseXML = null;
                // Check for filled fields correctly
                String[] formFields = getCorrectFields();
                // Prepare values to be used to store it in the external database
                String[] checkedFormFields = checkCorrectFields(formFields);
                // Create the xml request with the previous values
                String fileXMLRequest = file.setPersonalData(checkedFormFields, patientCode);
                //System.out.println(fileXMLRequest);
                try {
                    //Introduce XML and catch server response
                    //System.out.println(SessionData.getSessionData((getApplicationContext())).getUserCredentials());
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, getApplicationContext(),
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    getApplicationContext()).getUserCredentials()));

                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }

                everythingCorrect = responseXML == "created";
                Boolean incorrectPatientCode = responseXML == "unauthorized";

                if(incorrectPatientCode){
                    failCode = CODE_ERROR_INCORRECT_PATIENT_CODE;
                    everythingCorrect = false;
                }else if (!everythingCorrect)
                    failCode = CODE_ERROR_NOT_STORED;
                else {
                    if (alertForIncorrectFieldsAndStoreInSession(formFields)) {
                        everythingCorrect = false;
                        failCode = CODE_ERROR_SOME_DATA_INCORRECT;
                    }
                }

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }
            return everythingCorrect;
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog = new ProgressDialog(mContext);
                mProgressDialog.setMessage(getString(R.string.checking_user));
                mProgressDialog.setCancelable(false);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mSetPersonalDataTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (success) {
                Boolean completeData = sessionData.checkForPersonalDataComplete();
                Toast toast;
                if (completeData) {
                    toast = Toast.makeText(getApplicationContext(),
                            R.string.all_personal_data_completed, Toast.LENGTH_SHORT);
                    toast.show();
                } else {
                    toast = Toast.makeText(getApplicationContext(),
                            R.string.fields_not_yet_filled, Toast.LENGTH_LONG);
                    toast.show();
                }
                if(patientCode.equals("")){
                    sessionData.setPatientCode(SessionData.NOT_HAVE_PATIENT_CODE);
                }else{
                    sessionData.setPatientCode(patientCode);
                    for (int i = 0; i <havePatientCode.getChildCount(); i++)
                    {
                        havePatientCode.getChildAt(i).setEnabled(false);
                    }
                    FormActivity.this.patientCode.setEnabled(false);
                    FormActivity.this.patientCode.setBackgroundColor(getResources().getColor(R.color.colorDisable));
                    FormActivity.this.patientCode.setTextColor(getResources().getColor(R.color.colorDivider));
                    patientCodeTextView.setTextColor(getResources().getColor(R.color.colorDisable));
                }
                selectFormToGoByButtonPressed();
            } else {
                String errorMessage = "Error";
                switch (failCode) {
                    case CODE_ERROR_NOT_STORED:
                        errorMessage = getString(R.string.conection_server_problem);
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    case CODE_ERROR_INTERNET_CONNECTION:
                        errorMessage = getString(R.string.error_internet_connection);
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    case CODE_ERROR_INCORRECT_PATIENT_CODE:
                        errorMessage = getString(R.string.error_incorrect_patient_code);
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    case CODE_ERROR_SOME_DATA_INCORRECT:
                        //errorMessage = getString(R.string.error_not_valid_fields);
                        errorMessage = incorrectDataErrorText;
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    default:
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                }
            }
        }

        @Override
        protected void onCancelled() {
            mSetPersonalDataTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            //showProgress(false);
        }

        // This method search the fields that the user have filled correctly in the personal data form
        public String[] getCorrectFields() {

            String[] res = new String[5];
            //Check for name field correctly filled
            res[0] = name.getText().length() >= 2 && SFBChecks.validateNickName(name.getText()) ? name.getText().toString() : "";
            //Check for gender selected
            res[1] = gender.getCheckedRadioButtonId() != -1 ? (String) (findViewById(gender.getCheckedRadioButtonId())).getTag() : "";
            //Check for employment situation selected
            res[3] = employment.getCheckedRadioButtonId() != -1 ? (String) (findViewById(employment.getCheckedRadioButtonId())).getTag() : "";

            //Check for correct combination of dates (brithdate and start smoking date)
            // Logic:
            // - If date is filled and is correctly filled, it's stored its value
            // - If date is filled but it's incorrectly filled, it's stored a null value
            // - If date is not filled (have the default value "introduce"), it's stored an empty string
            // See comments in checkCorrectFields for more information

            // Case 1: the birthDate field are been filled (or it was filled in the past)
            if (dateHaveBeenFilled(birthday)) {
                //Check if the user declare s/he's too young
                String sBirthday = (birthday.getText().toString()).replace("-", "");
                Calendar cBirthday = SFBDate.stringToCalendar(sBirthday);

                long actualYear = Calendar.getInstance().getTime().getYear();
                long birthdayYear = cBirthday.getTime().getYear();
                //Case 1.1: The birth date is incorrect
                if (actualYear - birthdayYear < minUserAgeLimit) {
                    res[2] = null;
                    //check if the start smoking date field are been filled (or it was filled in the past)
                    res[4] = dateHaveBeenFilled(startSmokingDate) ? "" : null;
                }
                // Case 1.2: The age is correct, and the start smoking date field are been filled (now or in the past)
                else if (dateHaveBeenFilled(startSmokingDate)) {
                    //Check if the user declare begin to smoke when s/he was too young
                    String sSmokeDate = (startSmokingDate.getText().toString()).replace("-,", "");
                    Date smokingDate = SFBDate.stringToCalendar(sSmokeDate).getTime();
                    long smokingYear = smokingDate.getYear();
                    long differenceYears = smokingYear - birthdayYear;
                    // Case 1.2.1: The combination birthdate - start smoking date is incorrect
                    if (differenceYears < minStartSmokingAgeLimit) {
                        res[2] = null;
                        res[4] = null;
                        // Case 1.2.2: The combination it's correct
                    } else {
                        if (smokingDate.after(Calendar.getInstance().getTime()))
                            res[4] = null;
                        else
                            res[4] = startSmokingDate.getText().toString();

                        res[2] = birthday.getText().toString();
                    }
                    // Case 1.3: The start smoking date never are been filled
                } else {
                    res[2] = birthday.getText().toString();
                    res[4] = "";

                }
            }
            // Case 2: the birthDate never are been filled, in opposite to the start Smoking Date
            else if (dateHaveBeenFilled(startSmokingDate)) {
                String sSmokeDate = (startSmokingDate.getText().toString()).replace("-,", "");
                Date smokingDate = SFBDate.stringToCalendar(sSmokeDate).getTime();

                if (smokingDate.after(Calendar.getInstance().getTime()))
                    res[4] = null;
                else
                    res[4] = startSmokingDate.getText().toString();

                res[2] = "";

            } // Case 3: neither birthdate and start smoking date are been filled
            else {
                res[2] = "";
                res[4] = "";
            }

            return res;
        }

        private boolean dateHaveBeenFilled(EditText dateField) {
            return !dateField.getText().toString().equals("");
        }

        // This method check the values obtained in the getCorrectFields method and change them with
        // the sharedPreferences previous values if it's necessary.
        public String[] checkCorrectFields(String[] fields) {
            String[] checkedFields = new String[5];
            //name
            checkedFields[0] = !fields[0].equals("") ? fields[0] : sessionData.getUserNick();
            //gender
            checkedFields[1] = fields[1];
            //employment situation
            checkedFields[3] = fields[3];

            // for dates:
            // - If the value is a date string, it's stored this value
            // - If the value is an empty string, it's stored the empty string
            // - If the value is null, it's stored the previous value in shared preferences
            // birth date
            checkedFields[2] = fields[2] == null ? SFBDate.dateToString(sessionData.getBirthDate()) : fields[2];
            //start smoking date
            checkedFields[4] = fields[4] == null ? SFBDate.dateToString(sessionData.getStartedSmokingDate()) : fields[4];
            return checkedFields;
        }

        // Finally, this method have a double purpose:
        // 1. The correct filled values are stored in SharedPreferences
        // 2. The incorrect filled values are remarked in the form to alert to the user
        // Alert: We use this method with the result of "getCorrectField" method as parameters
        public boolean alertForIncorrectFieldsAndStoreInSession(String[] fields) {

            boolean flagIncorrectValue = false;
            Drawable incorrectFieldDrawable = getResources().getDrawable(R.drawable.incorrect_text_field);
            Drawable correctFieldDrawable = getResources().getDrawable(R.drawable.text_field);

            if (!fields[0].equals("")) {
                sessionData.setUserNick(fields[0]);
                changeBackgroundDrawable(name, correctFieldDrawable);
            } else {
                changeBackgroundDrawable(name, incorrectFieldDrawable);
                //changeBackgroundColor(name, incorrectColorBackground);
                incorrectDataErrorText = getString(R.string.name_not_correct);
                flagIncorrectValue = true;
            }

            if (!fields[1].equals(""))
                sessionData.setGender(fields[1]);

            if (!fields[3].equals(""))
                sessionData.setEmploymentStatus(fields[3]);


            if (fields[4] == null) {
                changeBackgroundDrawable(startSmokingDate, incorrectFieldDrawable);

                if (incorrectDataErrorText != null)
                    incorrectDataErrorText = getString(R.string.error_not_valid_fields);
                else if (fields[2] == null) {
                    changeBackgroundDrawable(birthday, incorrectFieldDrawable);
                    incorrectDataErrorText = getString(R.string.error_dates_not_correct1);
                } else
                    incorrectDataErrorText = getString(R.string.error_start_smoking_date_incorrect);
                flagIncorrectValue = true;
            } else {
                changeBackgroundDrawable(startSmokingDate, correctFieldDrawable);
                if (!fields[4].equals(""))
                    sessionData.setStartedSmokingDate(fields[4].replace("-,", ""));

                if (fields[2] == null) {
                    changeBackgroundDrawable(birthday, incorrectFieldDrawable);
                    incorrectDataErrorText = getString(R.string.error_birth_date);
                    flagIncorrectValue = true;
                } else {
                    changeBackgroundDrawable(birthday, correctFieldDrawable);
                    if (!fields[2].equals(""))
                        sessionData.setBirthDate(fields[2].replace("-,", ""));
                }
            }
            return flagIncorrectValue;


        }

        public void changeBackgroundDrawable(final View v, Drawable drawable) {
            final Drawable d = drawable.getConstantState().newDrawable();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    v.setBackgroundDrawable(d);
                }
            });
        }
    }

    /**
     * An {@link AsyncTask} to send to the server the new user preferences about the time interval
     * in which s/he wants to receive messages.
     * NOTE: if an error happen, the preferences are stored neither in local nor the server, and
     * alert to the user about this.
     */
    private class SaveWeekDaysPreferencesTask extends AsyncTask<Void, Void, Boolean> {

        String[] weekDaysPreferences;

        private final Context mContext;
        private Integer failCode;
        private ProgressDialog mProgressDialog;
        private final int CODE_NO_FAILS = 0;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;
        private final int CODE_ERROR_NOT_STORED = 6;


        SaveWeekDaysPreferencesTask(Context mContext, String[] weekDaysPreferences) {

            this.mContext = mContext;
            this.weekDaysPreferences = weekDaysPreferences;

            failCode = CODE_NO_FAILS;
        }


        @Override
        protected Boolean doInBackground(Void... voids) {

            Boolean everythingCorrect = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();
            String fileXMLRequest = file.setWeekDaysPreferences(weekDaysPreferences);

            if (XMLHttpPost.isConnectedToInternet(FormActivity.this)) {
                String responseXML = null;
                try {
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, getApplicationContext(),
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    getApplicationContext()).getUserCredentials()));
                } catch (CertificateException | NoSuchAlgorithmException | KeyManagementException | IOException | KeyStoreException e) {
                    e.printStackTrace();
                }


                everythingCorrect = responseXML == "created";
                if (!everythingCorrect)
                    failCode = CODE_ERROR_NOT_STORED;

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }

            return everythingCorrect;
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog = new ProgressDialog(mContext);
                mProgressDialog.setMessage(getString(R.string.checking_user));
                mProgressDialog.setCancelable(false);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mSaveWeekDaysPreferencesTask = null;
            super.onPostExecute(success);

            if (success) {

                SessionData.getSessionData(mContext).setWeekDaysPreferences(weekDaysPreferences);

                String alertTreatmentStarted = getString(R.string.changes_sent);
                Toast toast = Toast.makeText(mContext, alertTreatmentStarted, Toast.LENGTH_SHORT);
                toast.show();
                finish();
            } else {
                String errorMessage = getString(R.string.error);
                switch (failCode) {
                    case CODE_ERROR_NOT_STORED:
                        errorMessage = getString(R.string.error_data_not_stored);
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    case CODE_ERROR_INTERNET_CONNECTION:
                        errorMessage = getString(R.string.error_internet_connection);
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    default:
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                }

            }
            mProgressDialog.dismiss();

        }

        @Override
        protected void onCancelled() {
            mSaveWeekDaysPreferencesTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * An {@link AsyncTask} to send the new quitting attempt information to the server.
     * NOTE: if an error happen, the quitting attempt is stored neither in local nor the server, and
     * alert to the user about this.
     */
    private class AddQuittingAttemptTask extends AsyncTask<Void, Void, Boolean> {

        LocalDataBaseHelper db;

        // Attributes with the information to send to the server
        private Calendar cQuittingDate;
        private String sDailyCigarettes;
        private String sWeeklyExpenditure;
        private String sCurrency;
        private Integer[] fagerstromAnswers;
        private Integer[] richmondAnswers;
        private Integer fagerstromResult;
        private Integer richmondResult;

        private final Context mContext;

        // attribute to store a possible error trying to send the information
        private Integer failCode;

        // used to pause the app activity until the task finish, and alert to the user
        private ProgressDialog mProgressDialog;

        // possible fail codes
        private final int CODE_NO_FAILS = 0;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;
        private final int CODE_ERROR_NOT_STORED = 6;

        // Constructor
        AddQuittingAttemptTask(Context context) {

            cQuittingDate = new java.util.GregorianCalendar(startQuittingAttempt.getYear(),
                    startQuittingAttempt.getMonth(), startQuittingAttempt.getDayOfMonth());

            sDailyCigarettes = sessionData.getPreviousDailyCigarettes().toString();
            sWeeklyExpenditure = sessionData.getWeeklyTobaccoExpenditure().toString();
            sCurrency = sessionData.getCurrency();
            fagerstromAnswers = sessionData.getFagerstromAnswers();
            richmondAnswers = sessionData.getRichmondAnswers();
            fagerstromResult = sessionData.getFagerstromResult();
            richmondResult = sessionData.getRichmondResult();

            mContext = context;

            db = new LocalDataBaseHelper(mContext);

            failCode = CODE_NO_FAILS;
        }


        // The task part that is executed in different thread (The other parts are executed in the main thread)
        @Override
        protected Boolean doInBackground(Void... voids) {

            Boolean everythingCorrect = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();

            // Check if exists an internet connection
            if (XMLHttpPost.isConnectedToInternet(FormActivity.this)) {
                // SEND HTTP POST REQUEST
                String responseXML = null;
                // Create the xml request with the previous values
                String[] quittingAttemptData = {SFBDate.dateToString(cQuittingDate), sDailyCigarettes, sWeeklyExpenditure, SFBCurrencyConversions.currencySymbolToISOCode(sCurrency)};
                List<Integer> faux = new ArrayList<>(Arrays.asList(fagerstromAnswers));
                faux.add(fagerstromResult);
                List<Integer> raux = new ArrayList<>(Arrays.asList(richmondAnswers));
                raux.add(richmondResult);
                // Specific xml request using the values
                String fileXMLRequest = file.addQuittingAttempt(quittingAttemptData,
                        faux.toArray(new Integer[faux.size()]), raux.toArray(new Integer[raux.size()]));
                try {
                    //Introduce XML and catch server response
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, getApplicationContext(),
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    getApplicationContext()).getUserCredentials()));

                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }

                everythingCorrect = responseXML == "created";
                if (!everythingCorrect)
                    failCode = CODE_ERROR_NOT_STORED;

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }
            return everythingCorrect;
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog = new ProgressDialog(mContext);
                mProgressDialog.setMessage(getString(R.string.checking_user));
                mProgressDialog.setCancelable(false);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mAddQuitAttempt = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (success) { //Data saved in server: save information in local and alert to the user
                Float fDailyCigarettes = sessionData.getPreviousDailyCigarettes();
                Float fWeeklyExpenditure = sessionData.getWeeklyTobaccoExpenditure();

                sessionData.setQuittingDate(SFBDate.dateToString(cQuittingDate));

                Calendar d = Calendar.getInstance();

                SFBQuittingAttempt quittingAttempt = SFBQuittingAttempt.getInstance(
                        fDailyCigarettes, fWeeklyExpenditure, sCurrency,
                        cQuittingDate, null, fagerstromResult, richmondResult);

                // Save quitting attempt in local DB
                db.insertQuittingAttempt(quittingAttempt);

                SFBSmokingData smokingData = sessionData.getSmokingData(mContext);

                // Create a database table with the badges and the moment in which the user get each;
                // it depends of the previous smoking habits and the quitting date
                setInternalNotifications(smokingData);

                // Send a different text to the user depending on whether the quitting attempt has started or not
                String alertTreatmentStarted;
                if (d.before(smokingData.getQuittingAttempts().get(smokingData.getQuittingAttempts().size() - 1).getQuittingDate()))
                    alertTreatmentStarted = getString(R.string.quitting_attempt_will_start);
                else
                    alertTreatmentStarted = getString(R.string.quitting_attempt_has_started);

                // notification type key: SFBConstantsAndCodes.NOTIFICATION_TYPE_INFORMATION
                final String userId = sessionData.getUserId();
                final Calendar quittingDate = sessionData.getQuittingDate();

                SFBNotification quittingAttemptInfo = new SFBNotification(SFBConstantsAndCodes.NOTIFICATION_INTERNAL_BADGE,
                        userId,
                        String.format(getResources().getString(R.string.quitting_attempt_started_explanation),
                                sessionData.getUserNick()),
                        SFBConstantsAndCodes.NOTIFICATION_TYPE_INFORMATION, quittingDate);

                if(quittingDate.before(Calendar.getInstance())){

                    // if(!sessionData.hasIntroducedActiveQuittingAttempDateInThisSession())
                        db.insertMessageNotification(quittingAttemptInfo);

                    Intent intent = new Intent(mContext, MainActivity.class);
                    intent.putExtra(MainActivity.SUBSECTION_KEY, TabsInitFragment.TAB_MESSAGES);

                    PendingIntent resultPendingIntent = PendingIntent.getActivity(mContext, 2, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                    NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(mContext)
                            .setContentText(getResources().getString(R.string.quitting_attempt_has_started))
                            .setContentTitle(getString(R.string.sfb_notification))
                            .setTicker(mContext.getString(R.string.sfb_server_notification))
                            .setContentIntent(resultPendingIntent)
                            .setAutoCancel(true);

                    if(Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT)
                        notificationBuilder.setSmallIcon(R.drawable.logo)
                                .setLargeIcon(ImageConversions.getBitmapFromDrawable(getApplicationContext(), R.drawable.logo_min));
                    else
                        notificationBuilder.setSmallIcon(R.drawable.vector_logo)
                                .setLargeIcon(ImageConversions.getBitmapFromDrawable(getApplicationContext(), R.drawable.logo));

                    NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
                    notificationManager.notify(1, notificationBuilder.build());

                    sessionData.setHasIntroducedActiveQuittingAttempDateInThisSession(true);
                }else {
                    quittingAttemptInfo.setText(getResources().getString(R.string.quitting_attempt_has_started));
                    AlarmReceiver.setAlarmNotification(getApplicationContext(), quittingAttemptInfo, "0");
                }

                Toast toast = Toast.makeText(mContext, alertTreatmentStarted, Toast.LENGTH_SHORT);
                toast.show();

                finish();

            } else { //Data not saved in server: alter to the user.
                String errorMessage = getString(R.string.error);
                switch (failCode) {
                    case CODE_ERROR_NOT_STORED:
                        errorMessage = getString(R.string.error_data_not_stored);
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    case CODE_ERROR_INTERNET_CONNECTION:
                        errorMessage = getString(R.string.error_internet_connection);
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    default:
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                }
            }

        }

        /**
         * Create a database table with the badges and the moment in which the user get each.
         *
         * @param smokingData the previous smoking habits to the quitting attempt.
         */
        private void setInternalNotifications(SFBSmokingData smokingData) {

            // Calculate the time in wich the user will get the achievements
            ArrayList<SFBNotification> list = SFBNotification.createAchieveNotifications(smokingData, getApplicationContext());

            Calendar now = Calendar.getInstance();
            Integer index = 0;
            // Determines what achievements have been achieved
            for (SFBNotification item : list) {
                int achieved;
                if (item.getSentDate().before(now)) {
                    //to received notification list
                    achieved = SFBConstantsAndCodes.BADGE_ACHIEVED;
                } else {
                    //to alarmReceiver
                    achieved = SFBConstantsAndCodes.BADGE_NOT_ACHIEVED;
                    //AlarmReceiver.setAlarmNotification(getApplicationContext(), item, index);
                }
                // Store in the database
                db.createBadges(item.getType(), item.getText(), item.getIdDrawableCode(), achieved, item.getSentDate().getTimeInMillis());
                index++;
            }
        }

        @Override
        protected void onCancelled() {
            mAddQuitAttempt = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}