package com.salumedia.quitandreturn.model;

/**
 * Created by Francisco on 2/10/17.
 */

public class SFBMiniGameAnalytics {

    public static final String WHACK_A_MOLE_NAME = "WhackAMole";
    public static final String BLOW_BALLOON_NAME = "BlowBalloon";
    public static final String BLOW_BALLOON_QUICKLY_NAME = "BlowBalloonQuickly";
    public static final String PHYSICAL_EXERCISES_NAME = "PhysicalExercises";

    private String name, date, time;
    private Integer score, penalties, playingTime;

    public SFBMiniGameAnalytics(String name, String date, String time, Integer score, Integer playingTime) {
        this.name = name;
        this.date = date;
        this.time = time;
        this.score = score;
        this.playingTime = playingTime;
    }

    public SFBMiniGameAnalytics(String name, String date, String time, Integer score, Integer penalties, Integer playingTime) {
        this.name = name;
        this.date = date;
        this.time = time;
        this.score = score;
        this.penalties = penalties;
        this.playingTime = playingTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Integer getPenalties() {
        return penalties;
    }

    public void setPenalties(Integer penalties) {
        this.penalties = penalties;
    }

    public Integer getPlayingTime() {
        return playingTime;
    }

    public void setPlayingTime(Integer playingTime) {
        this.playingTime = playingTime;
    }

    @Override
    public String toString() {
        return "SFBMiniGameAnalytics{" +
                "name='" + name + '\'' +
                ", date='" + date + '\'' +
                ", time='" + time + '\'' +
                ", score=" + score +
                ", penalties=" + penalties +
                '}';
    }
}
