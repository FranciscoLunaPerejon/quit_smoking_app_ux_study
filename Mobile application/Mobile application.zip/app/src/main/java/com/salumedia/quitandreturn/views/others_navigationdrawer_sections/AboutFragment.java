package com.salumedia.quitandreturn.views.others_navigationdrawer_sections;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.SFBFragment;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;


/**
 * Class that shows the information about the app and the enterprise
 */
public class AboutFragment extends SFBFragment {

    // Auxiliary view to inflate the fragment. It is used in auxiliary methods, so it is set as an
    // attribute of the class
    View rootView;

    // Empty public constructor
    public AboutFragment(){
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Not View attributes instantiation
        section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_ABOUT; // Analysis purpose
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_about,container,false);

        // View attribute instantiation
        WebView webView = (WebView) rootView.findViewById(R.id.webViewAbout);
        webView.loadUrl("file:///android_asset/" + getString(R.string.about_file));

        return rootView;
    }


}
