package com.salumedia.quitandreturn.utils;

import android.util.Base64;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by joaquin on 23/6/16.
 */
public class SFBEncode {
    private static final char[] CONSTS_HEX = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    /* Modo de proceder de este metodo:
    * 1. Encripta usando MD5, obteniendo bytes
    * 2. Crea una secuencia mutable de caracteres (StringBuilder) vacia
    * 3. Como a cada byte le caben dos hexadecimales, extrae a nivel de byte los cuatro bits mas
    *    significativos y los cuatro menos, en definitiva bits que pueden representar numeros del
    *    0 al 15.
    * 4. Utiliza estos conjuntos de cuatro bits como indices para acceder a un array que lleva
    *    almacenado el numero en hexadecimal que le corresponde a cada conjunto de 4 bits y los va
    *    guardando en orden en la secuencia mutable de caracteres
    * 5. Convierte la secuenciencia en un string
    * */
    public static String encodeToMD5(String stringToEncode) {
        try {
            MessageDigest msgd = MessageDigest.getInstance("MD5");
            byte[] bytes = msgd.digest(stringToEncode.getBytes());
            StringBuilder stringBuilderMD5 = new StringBuilder(2 * bytes.length);
            for (int i = 0; i < bytes.length; i++) {
                int lower = bytes[i] & 0x0f;
                int upper = (bytes[i] & 0xf0) >> 4;
                stringBuilderMD5.append(CONSTS_HEX[upper]);
                stringBuilderMD5.append(CONSTS_HEX[lower]);
            }
            return stringBuilderMD5.toString();
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    public static String encodeStringBase64(String stringToEncode) {
        String out;
        byte[] decodeBytes = Base64.encode(stringToEncode.getBytes(), Base64.DEFAULT);
        out = new String(decodeBytes, Charset.forName("UTF-8"));

        return out.replaceAll("\n", "");
    }
    public static String decodeStringBase64(String stringToDecode) {
        String out;
        byte[] encodedBytes = Base64.decode(stringToDecode.getBytes(), Base64.DEFAULT);
        out = new String(encodedBytes, Charset.forName("UTF-8"));

        return out.replaceAll("\n", "");
    }
}
