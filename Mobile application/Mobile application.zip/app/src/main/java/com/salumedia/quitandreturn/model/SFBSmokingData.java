package com.salumedia.quitandreturn.model;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Created by joaquin on 16/5/16.
 */

/**
 * It contains the quitting period history and other smoking data
 */
public class SFBSmokingData {

    private Calendar dateStartingSmoking;
    private List<SFBQuittingAttempt> quittingAttempts = new ArrayList<>();

    public SFBSmokingData(Calendar dateStartingSmoking, List<SFBQuittingAttempt> quittingAttempts) {
        this.dateStartingSmoking = dateStartingSmoking;
        this.quittingAttempts = new ArrayList<>(quittingAttempts);
    }

    public SFBSmokingData(Calendar dateStartingSmoking){
        this.dateStartingSmoking = dateStartingSmoking;
    }

    public SFBSmokingData() {
    }

    public Calendar getDateStartingSmoking() {
        return dateStartingSmoking;
    }

    public List<SFBQuittingAttempt> getQuittingAttempts() {
        return quittingAttempts;
    }

    public void setDateStartingSmoking(Calendar dateStartingSmoking) {
        this.dateStartingSmoking = dateStartingSmoking;
    }

    public void setQuittingAttempts(List<SFBQuittingAttempt> quittingPeriods) {
        this.quittingAttempts = new ArrayList<>(quittingPeriods);
    }

    @Override
    public String toString() {
        return "SFBSmokingData{" +
                "dateStartingSmoking=" + dateStartingSmoking +
                ", quittingAttempts=" + quittingAttempts +
                '}';
    }

}
