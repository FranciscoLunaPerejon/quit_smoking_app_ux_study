package com.salumedia.quitandreturn.views.minigames_section;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBAppInteractionAnalytic;
import com.salumedia.quitandreturn.model.SFBMiniGameAnalytics;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.XMLHttpPost;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.SFBAnalytics;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBEncode;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class WhackingMolesActivity extends AppCompatActivity {

    public static final String section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_GAME_WHACK_MOLES;
    public String date;
    public String time;
    public Float init;

    boolean gameFinished = false;

    // Initialize variables

    TextView scoreTextView;
    TextView timeTextView;
    MoleImageView molesImageView;
    View finishContainerView;
    TextView finishTextView;
    View resultsLayoutView;
    TextView totalScoreTextView;
    View startContainerView;

    Button restartButton;
    Button backButton;
    RelativeLayout gameRelativeLayout;
    int totalTime = 60000;
    WhackMolesResults gameResults = new WhackMolesResults();
    private Context context;
    private SendWhackingMolesGameResultsTask mSendWhackingMolesGameResultsTask = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_whacking_moles);
        context = this;

        // Get widgets
        gameRelativeLayout = (RelativeLayout) findViewById(R.id.gameRelativeLayout);
        scoreTextView = (TextView) findViewById(R.id.scoretextView);
        timeTextView = (TextView) findViewById(R.id.timetextView);
        resultsLayoutView = findViewById(R.id.results_layout);
        totalScoreTextView = (TextView) findViewById(R.id.totalScoreTextView);
        finishContainerView = findViewById(R.id.finishContainerView);
        finishTextView = (TextView) findViewById(R.id.finishTextView);
        restartButton = (Button) findViewById(R.id.restartButton);
        backButton = (Button) findViewById(R.id.backButton);
        startContainerView = findViewById(R.id.startContainerView);

        startContainerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if (event.getAction() == MotionEvent.ACTION_DOWN) {

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            startContainerView.setVisibility(View.GONE);

                            // Initialize MolesImageView
                            molesImageView = new MoleImageView(context);
                            molesImageView.setOnMoleClickedListener(new MoleImageView.OnMoleClickedListener() {
                                public void OnMoleClicked(int molesClickedTimes) {
                                    gameResults.totalScore = molesClickedTimes;
                                    String scoreText = getString(R.string.crashing_cigarettes_score) + gameResults.totalScore;
                                    scoreTextView.setText(scoreText);
                                    String totalScoreText = getString(R.string.crashing_cigarettes_total_score) + gameResults.totalScore;
                                    totalScoreTextView.setText(totalScoreText);
                                }
                            });

                            // Show cigarette in the view
                            molesImageView.ShowMolesOnLayout(gameRelativeLayout);
                            molesImageView.onWindowFocusChanged(true);

                            // Initialize game miniGameActivity
                            gameResults.totalTime = totalTime;
                            gameResults.totalScore = 0;
                            Date date = new Date();
                            gameResults.datetime = date;
                            TimeZone tz = TimeZone.getTimeZone("UTC");
                            DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                            df.setTimeZone(tz);
                            gameResults.dateStr = df.format(date);

                            new CountDownTimer(totalTime, 1000) {

                                public void onTick(long millisUntilFinished) {
                                    String timeText = getString(R.string.crashing_cigarettes_time) + millisUntilFinished / 1000;
                                    timeTextView.setText(timeText);
                                }

                                public void onFinish() {
                                    // Set appropriate visibility
                                    scoreTextView.setVisibility(View.INVISIBLE);
                                    timeTextView.setVisibility(View.INVISIBLE);
                                    finishContainerView.setVisibility(View.VISIBLE);
                                    finishTextView.setVisibility(View.VISIBLE);
                                    resultsLayoutView.setVisibility(View.VISIBLE);
                                    restartButton.setVisibility(View.VISIBLE);
                                    backButton.setVisibility(View.VISIBLE);
                                    molesImageView.RemoveMolesFromLayout(gameRelativeLayout);

                                    gameFinished = true;

                                    // Send miniGameActivity
                                    sendWhackingMolesGameResults(gameResults);
                                }
                            }.start();
                        }
                    });
                }

                return true;
            }
        });

        // Add click listeners to buttons
        restartButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                recreate();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });


    }

    @Override
    public void onResume() {
        super.onResume();
        // Initialize time parameters
        init = Long.valueOf(System.nanoTime()/1000000).floatValue();
        Calendar currentTime = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        date = sdf.format(currentTime.getTime());
        SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss.SSS");
        time = sdf2.format(currentTime.getTime());

        try{
            SFBAnalytics.startLogTimeInSection(section_name +
                    "_author:" +  SessionData.getSessionData(this).getUserData(this).getUserId() +
                    "_date:" + date + " " +  time);
        }catch (Exception e){
            SFBAnalytics.startLogTimeInSection(section_name + "_author:NOT_AVALIABLE" +
                    "_date:" + date + " " +  time);
        }
        SFBAnalytics.startLogTimeInSection(section_name);
    }

    @Override
    public void onPause() {
        super.onPause();
        // Calculate duration and save information in local database
        Float fin = Long.valueOf(System.nanoTime()/1000000).floatValue();
        LocalDataBaseHelper db = new LocalDataBaseHelper(this);
        SFBAppInteractionAnalytic SFBAppInteractionAnalytic = new SFBAppInteractionAnalytic(section_name, date, time, (fin-init));
        db.insertAppInteraction(SFBAppInteractionAnalytic);
        try{
            SFBAnalytics.stopLogTimeInSection(section_name +
                    "_author:" + SessionData.getSessionData(this).getUserData(this).getUserId() +
                    "_date:" + date + " " +  time);

        }catch (Exception e){
            SFBAnalytics.stopLogTimeInSection(section_name + "_author:NOT_AVALIABLE" +
                    "_date:" + date + " " +  time);
        }
        SFBAnalytics.stopLogTimeInSection(section_name);

        sendWhackingMolesGameResults(gameResults);

    }

    public class WhackMolesResults {
        public int totalTime;
        public int restingTime;
        public int totalScore;
        public Date datetime;
        public String dateStr;
    }

    public void sendWhackingMolesGameResults(WhackMolesResults results) {
        if (mSendWhackingMolesGameResultsTask != null) {
            return;
        }
        mSendWhackingMolesGameResultsTask = new SendWhackingMolesGameResultsTask(WhackingMolesActivity.this, results);
        mSendWhackingMolesGameResultsTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
    }

    public class SendWhackingMolesGameResultsTask extends AsyncTask<Void, Void, Boolean> {

        private final int CODE_NO_FAILS = 0;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;
        private final int CODE_ERROR_NOT_STORED = 6;

        public Integer failCode;

        SFBMiniGameAnalytics miniGameActivity;
        Context context;

        public SendWhackingMolesGameResultsTask(Context context, WhackMolesResults results) {
            this.context = context;
            Integer playingTime = gameFinished ? results.totalTime : results.totalTime - results.restingTime;

            this.miniGameActivity = new SFBMiniGameAnalytics(SFBMiniGameAnalytics.WHACK_A_MOLE_NAME, date, time, results.totalScore, playingTime);

            failCode = CODE_NO_FAILS;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {

            Boolean everythingCorrect = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();



            if (XMLHttpPost.isConnectedToInternet(WhackingMolesActivity.this)) {

                String responseXML = null;

                ArrayList<SFBMiniGameAnalytics> list = new ArrayList<>();
                list.add(miniGameActivity);

                String fileXMLRequest = file.addMiniGameActivity(list);

                try {
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, context,
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    context).getUserCredentials()));
                } catch (CertificateException | NoSuchAlgorithmException | KeyManagementException | IOException | KeyStoreException e) {
                    e.printStackTrace();
                }

                everythingCorrect = responseXML == "created";
                if (!everythingCorrect)
                    failCode = CODE_ERROR_NOT_STORED;

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }


            return everythingCorrect;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mSendWhackingMolesGameResultsTask = null;
            //fragmentReference.refreshUI(0);
            super.onPostExecute(success);
            //goBack();
            if (success) {
                Log.d("SFBSENT", "Success ok onPostExecute");
                //SFBPreferences.getPreferences(context).setEncourageMessageResponseWithSuccess(SFBConstants.ENCOURAGE_MESSAGE_SENT);
            } else {
                LocalDataBaseHelper db = new LocalDataBaseHelper(context);
                db.insertMiniGameActivity(miniGameActivity);
            }
        }

        @Override
        protected void onCancelled() {
            mSendWhackingMolesGameResultsTask = null;
            super.onCancelled();
        }
    }

}