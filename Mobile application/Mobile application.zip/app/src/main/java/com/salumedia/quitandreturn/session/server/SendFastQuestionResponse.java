package com.salumedia.quitandreturn.session.server;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBMessageInteractionAnalytic;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.ImageConversions;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBDate;
import com.salumedia.quitandreturn.utils.SFBEncode;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static java.util.Calendar.getInstance;

/**
 * Created by Francisco on 24/5/17.
 */

public class SendFastQuestionResponse extends IntentService {


    Context appContext;

    // Question response information values
    // Extract the id of question in server
    private String idInServer;

    private String dateAccess;
    private String timeStartAccess;
    private Float millisStartAccess;
    private String timeToAccess;

    private Integer questionResponse;

    SFBMessageInteractionAnalytic messageInteractionAnalytic;

    public SendFastQuestionResponse(){
        super("sendFastQuestionResponse");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        appContext = getApplicationContext();
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

        // Cancel notification associated
        NotificationManager manager = (NotificationManager) getSystemService(Service.NOTIFICATION_SERVICE);
        manager.cancel(intent.getExtras().getInt(MyFirebaseMessagingService.idNotification));

        idInServer = intent.getExtras().getString(MyFirebaseMessagingService.idQuestionInServer);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        dateAccess = sdf.format(getInstance().getTime());
        SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss.SSS");
        timeStartAccess = sdf2.format(getInstance().getTime());
        millisStartAccess = Long.valueOf(System.nanoTime()/1000000).floatValue();

        Calendar receivedQuestionDate = SFBDate.stringToCalendar(intent.getExtras().getString(MyFirebaseMessagingService.receivedQuestionDate));

        if(intent.hasExtra(MyFirebaseMessagingService.questionResponse))
            questionResponse = intent.getExtras().getInt(MyFirebaseMessagingService.questionResponse);
        else
            questionResponse = 0;

        timeToAccess = ((Calendar.getInstance().getTimeInMillis() - receivedQuestionDate.getTimeInMillis()) / 1000) + "";;

        Float millisResponse = Long.valueOf(System.nanoTime()/1000000).floatValue();
        Float secondsToResponse = (millisResponse - millisStartAccess)/1000; // save seconds from access to question until response

        // Create the object used to manipulate the message lecture information
        messageInteractionAnalytic = new SFBMessageInteractionAnalytic(idInServer,
                dateAccess,
                timeStartAccess,
                secondsToResponse,
                timeToAccess, //In seconds
                String.valueOf(questionResponse),
                "0");

        boolean isHttpResponseCorrect = false;
        GenerateXMLFile file = GenerateXMLFile.getInstance();

        // Check if exists an internet connection
        if (XMLHttpPost.isConnectedToInternet(appContext)) {
            // SEND HTTP POST REQUEST
            String responseXML = null;

            // Create the xml request with the previous values
            List<SFBMessageInteractionAnalytic> list = new ArrayList<>();
            list.add(messageInteractionAnalytic);
            // Specific xml request using the values
            String fileXMLRequest = file.addMessageInteractions(list);

            try {
                //Introduce XML and catch server response
                responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, appContext,
                        SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                appContext).getUserCredentials()) );
            } catch (CertificateException | NoSuchAlgorithmException | KeyManagementException | IOException | KeyStoreException e) {
                e.printStackTrace();
            }
            isHttpResponseCorrect = responseXML.equals("created");
        }

        if(!isHttpResponseCorrect){
            LocalDataBaseHelper db = new LocalDataBaseHelper(appContext);
            db.insertMessageInteractionToSend(messageInteractionAnalytic);
        }

        int questionCode = intent.getExtras().getInt(MyFirebaseMessagingService.idQuestion);
        String responseNotificationContentText;
        int notificationCode;
        switch (questionCode){
            case SFBConstantsAndCodes.SMOKEFREE_QUESTION_ID:
                responseNotificationContentText = getString(R.string.notification_content_text_response_smokefree);
                notificationCode = SFBConstantsAndCodes.SMOKEFREE_QUESTION_NOTIFICATION_BOX_ID;
                SessionData.getSessionData(appContext).changeIfThereAreASmokeFreeQuestionWithoutResponse(false);
                break;
            case SFBConstantsAndCodes.MESSAGES_FREQUENCY_QUESTION_ID:
                responseNotificationContentText = getString(R.string.notification_content_text_response_messages_frequency);
                notificationCode = SFBConstantsAndCodes.MESSAGES_FREQUENCY_QUESTION_NOTIFICATION_BOX_ID;
                SessionData.getSessionData(appContext).changeIfThereAreAMessagesFrequencyQuestionWithoutResponse(false);
                break;
            default:
                notificationCode = 99;
                responseNotificationContentText = getString(R.string.notification_content_text_response_default);

        }


        createSimpleNotification(responseNotificationContentText, notificationCode);

    }

    /**
     * Create and show a simple notification.
     *
     * @param messageBody  message body selected.
     */
    private void createSimpleNotification(String messageBody, int notificationCode) {

        Uri defaultSoundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setContentTitle(getString(R.string.casual_smokefreebrain_question_title))
                .setPriority(Notification.PRIORITY_HIGH)
                .setContentText(messageBody)
                .setAutoCancel(true)
                .setSound(defaultSoundUri);

        if(Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT)
            notificationBuilder.setSmallIcon(R.drawable.logo)
                    .setLargeIcon(ImageConversions.getBitmapFromDrawable(getApplicationContext(), R.drawable.logo_min));
        else
            notificationBuilder.setSmallIcon(R.drawable.vector_logo)
                    .setLargeIcon(ImageConversions.getBitmapFromDrawable(getApplicationContext(), R.drawable.logo));

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(notificationCode, notificationBuilder.build());
    }
}
