package com.salumedia.quitandreturn.views.others_navigationdrawer_sections;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.design.widget.Snackbar;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.Toast;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.SFBFragment;
import com.salumedia.quitandreturn.model.SFBNotification;
import com.salumedia.quitandreturn.model.SFBSmokingData;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.XMLHttpPost;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBEncode;
import com.salumedia.quitandreturn.views.FormActivity;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;



/**
 * Created by Francisco on 16/12/16.
 */

/**
 * Class that show the language selection, not disturb-mode and access to week days preferences
 */

public class PreferencesFragment extends SFBFragment {

    // Personalized listener used to send information to container activity
    OnPreferencesFragmentInteractionListener mListener;

    // View attributes

    private RadioGroup languageRadioGroup;
    private Switch notificationSwitch;
    private RadioButton radioButton1;
    private RadioButton radioButton2;
    private RadioButton radioButton3;

    // To change the application language
    Locale myLocale;

    // Auxiliary view to inflate the fragment. It is used in auxiliary methods, so it is set as an
    // attribute of the class
    View rootView;

    // Access to shared preferences
    private SessionData sessionData;

    // An Async Task instance. It allows to do a background task
    UpdatePreferencesTask mUpdatePreferencesTask = null;

    // Necessary default constructor
    public PreferencesFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Not View attributes instantiation
        sessionData = SessionData.getSessionData(getContext());
        section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_PREFERENCES;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_preferences, container, false);

        // View attributes instantiation

        notificationSwitch = (Switch) rootView.findViewById(R.id.switchNotifications);
        Button preferencesButton = (Button) rootView.findViewById(R.id.buttonPreferences);
        radioButton1 = (RadioButton) rootView.findViewById(R.id.radioButton1);
        radioButton2 = (RadioButton) rootView.findViewById(R.id.radioButton2);
        radioButton3 = (RadioButton) rootView.findViewById(R.id.radioButton3);

        languageRadioGroup = (RadioGroup) rootView.findViewById(R.id.language_radio_group);

        checkLanguageOption(); // Set the current language selected in language radio group

        // Set the language when a radio group option is selected
        languageRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                switch ((String) rootView.findViewById(checkedId).getTag()) {
                    case "en":
                        setLocale("en");
                        break;
                    case "es":
                        setLocale("es");
                        break;
                    case "zh":
                        setLocale("zh");
                        break;
                    default:
                        break;
                }
            }
        });

        // Manage the not-disturb mode
        notificationSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean isChecked = notificationSwitch.isChecked();
                // Enable not-disturb radio group if switch is turned on and change text of TextViews
                enableRadioButtons(isChecked);
                notificationSwitch.setText(isChecked ? R.string.notifications_disabled_switch : R.string.notifications_enabled_switch);
                if (!isChecked) { // If switch is turned off, disable not-disturb mode
                    Calendar calendar = Calendar.getInstance();
                    calendar.add(Calendar.DAY_OF_YEAR, -1); // Change ta a past date
                    saveNotificationPreferences(SFBConstantsAndCodes.CODE_MUTE_NOTIFICATIONS_CANCELLED, calendar);
                } else { // If it is turned on, check the not-disturb-8-hours option by default
                    radioButton1.setChecked(true);
                    muteNotifications(SFBConstantsAndCodes.CODE_MUTE_NOTIFICATIONS_8_HOURS);
                }
            }
        });

        // Change to the correspondent not-disturb option if his radio button is selected
        radioButton1.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        muteNotifications(SFBConstantsAndCodes.CODE_MUTE_NOTIFICATIONS_8_HOURS);
                    }
                }
        );
        radioButton2.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        muteNotifications(SFBConstantsAndCodes.CODE_MUTE_NOTIFICATIONS_1_DAY);
                    }
                }
        );
        radioButton3.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        muteNotifications(SFBConstantsAndCodes.CODE_MUTE_NOTIFICATIONS_1_WEEK);
                    }
                }
        );

        updateUI(); // Set the previous not-disturb mode configuration

        // Access to week days preferences form
        preferencesButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view){
                        Intent intent = new Intent(getContext(), FormActivity.class);
                        intent.putExtra("idForm", SFBConstantsAndCodes.WEEK_DAYS_PREFERENCES_ID);
                        startActivity(intent);
                    }
                }
        );

        return rootView;
    }

    // Select the current language in radio group
    private void checkLanguageOption() {
        Resources res = getResources();
        Configuration conf = res.getConfiguration();
        String lang = conf.locale.getLanguage(); // Access to current application location
        switch (lang) {
            case "es":
                ((RadioButton) languageRadioGroup.getChildAt(2)).setChecked(true);
                break;
            case "en":
                ((RadioButton) languageRadioGroup.getChildAt(0)).setChecked(true);
                break;
            case "zh":
                ((RadioButton) languageRadioGroup.getChildAt(1)).setChecked(true);
            default:
                break;
        }
    }

    // Change the language
    private void setLocale(String lang) {
        myLocale = new Locale(lang); // Locale instanced with a correct Language ISO Code
        Resources res = getActivity().getApplicationContext().getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = myLocale; // Change the current location with the selected
        res.updateConfiguration(conf, dm); // Update changes
        sessionData.setLanguage(lang); // Save in shared preferences too (Is necessary in some moment in application flow)
        if (sessionData.isQuittingDateFilled()) // If user is in a quitting period
            resetInternalNotifications();  // Modify the text body of the badge notification (it's
            // required to calculate badges and show the progress text in correct language.)
        savePreferences(); // Call to Async Task to send information to the server
        mListener.refreshLanguage(); // Refresh view to set changes
    }


    // Modify the text body of the badge notification (it's
    // required to calculate badges and show the progress text in correct language.)
    private void resetInternalNotifications() {

        LocalDataBaseHelper db = new LocalDataBaseHelper(getContext());
        SFBSmokingData smokingData;
        smokingData = SessionData.getSessionData(getContext()).getSmokingData(getContext());
        ArrayList<SFBNotification> list = SFBNotification.createAchieveNotifications(smokingData, getContext());
        Calendar now = Calendar.getInstance();
        Integer index = 0;
        for (SFBNotification item : list) {
            /*int achieved;
            if (item.getSentDate().before(now)) {
                //to received notification list
                achieved = SFBConstantsAndCodes.BADGE_ACHIEVED;
            } else {
                //to alarmReceiver
                achieved = SFBConstantsAndCodes.BADGE_NOT_ACHIEVED;
                AlarmReceiver.setAlarmNotification(getContext(), item, index);
            }*/
            db.updateBadges(item.getText(), item.getIdDrawableCode());
            index++;

        }
    }

    // Save not-disturb configuration
    private void saveNotificationPreferences(Integer codeMuteNotifications, Calendar calendar) {
        sessionData.setMuteNotifications(codeMuteNotifications);
        sessionData.setMuteNotificationsUntil(calendar);
        savePreferences(); // Send the information to the server
    }

    // Send information to the server
    private void savePreferences() {
        mUpdatePreferencesTask = new UpdatePreferencesTask(getContext());
        mUpdatePreferencesTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
    }

    // Enable not-disturb radio group if switch button is turned on and change text of TextViews
    // depending on the switch button state
    private void enableRadioButtons(boolean isChecked) {

        // Set appearance, text and state of radio buttons
        radioButton1.setClickable(isChecked);
        radioButton2.setClickable(isChecked);
        radioButton3.setClickable(isChecked);
        radioButton1.setAlpha(isChecked ? 1 : 0.5f);
        radioButton2.setAlpha(isChecked ? 1 : 0.5f);
        radioButton3.setAlpha(isChecked ? 1 : 0.5f);

        radioButton1.setText(getString(R.string.notifications_radio_button_1));
        radioButton2.setText(getString(R.string.notifications_radio_button_2));
        radioButton3.setText(getString(R.string.notifications_radio_button_3));

        Integer muteCode = sessionData.getMuteNotifications();
        if (isChecked) { // Check the correct option depending of code stored in shared preferences
            if (muteCode == SFBConstantsAndCodes.CODE_MUTE_NOTIFICATIONS_8_HOURS) {
                radioButton1.setChecked(true);
            } else if (muteCode == SFBConstantsAndCodes.CODE_MUTE_NOTIFICATIONS_1_DAY) {
                radioButton2.setChecked(true);
            } else if (muteCode == SFBConstantsAndCodes.CODE_MUTE_NOTIFICATIONS_1_WEEK) {
                radioButton3.setChecked(true);
            } else if (muteCode == SFBConstantsAndCodes.CODE_MUTE_NOTIFICATIONS_CANCELLED) {
                radioButton1.setChecked(false);
                radioButton2.setChecked(false);
                radioButton3.setChecked(false);
                radioButton1.setText(getString(R.string.notifications_radio_button_1_disabled));
                radioButton2.setText(getString(R.string.notifications_radio_button_2_disabled));
                radioButton3.setText(getString(R.string.notifications_radio_button_3_disabled));
            }
        } else {
            radioButton1.setChecked(false);
            radioButton2.setChecked(false);
            radioButton3.setChecked(false);
        }
    }

    // Calcule the date until it is muted the notifications
    private void muteNotifications(int notificationsCode) {
        Calendar calendar = Calendar.getInstance();
        if (notificationsCode == SFBConstantsAndCodes.CODE_MUTE_NOTIFICATIONS_8_HOURS) {
            calendar.add(Calendar.HOUR, 8);
        } else if (notificationsCode == SFBConstantsAndCodes.CODE_MUTE_NOTIFICATIONS_1_DAY) {
            calendar.add(Calendar.DAY_OF_YEAR, 1);
        } else if (notificationsCode == SFBConstantsAndCodes.CODE_MUTE_NOTIFICATIONS_1_WEEK) {
            calendar.add(Calendar.DAY_OF_YEAR, 7);
        } else if (notificationsCode == SFBConstantsAndCodes.CODE_MUTE_NOTIFICATIONS_CANCELLED) {
            calendar.add(Calendar.DAY_OF_YEAR, -1);
        }
        saveNotificationPreferences(notificationsCode, calendar);
    }


    // Get data from the database and show it to the user
    private void updateUI() {

        Calendar calendar = sessionData.getMuteNotificationsUntil();

        if (calendar.after(Calendar.getInstance())) {
            notificationSwitch.setChecked(true);
            notificationSwitch.setText(R.string.notifications_disabled_switch);
            enableRadioButtons(true);
        } else {
            notificationSwitch.setChecked(false);
            notificationSwitch.setText(R.string.notifications_enabled_switch);
            enableRadioButtons(false);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnPreferencesFragmentInteractionListener) {
            mListener = (OnPreferencesFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnMeFragmentInteractionListener");
        }
        // Analytical purpose
        section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_PREFERENCES;
    }

    @Override
    public void onResume() {
        super.onResume();
        mListener.onPreferencesFragmentInteraction(null);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * That AsyncTask send the configuration changes to the server
     */
    private class UpdatePreferencesTask extends AsyncTask<Void, Void, Boolean> {

        private final Context mContext;
        private Integer failCode;
        private ProgressDialog mProgressDialog;
        private final int CODE_NO_FAILS = 0;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;
        private final int CODE_ERROR_NOT_STORED = 6;

        UpdatePreferencesTask(Context context) {
            this.mContext = context;
            failCode = CODE_NO_FAILS;
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog = new ProgressDialog(mContext);
                mProgressDialog.setMessage(getString(R.string.saving_notification_preferences));
                mProgressDialog.setCancelable(false);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            Boolean everythingCorrect = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();
            Integer code = sessionData.getMuteNotifications();
            Calendar notDusturbUntil = sessionData.getMuteNotificationsUntil();

            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            String timestampToSend = simpleDateFormat.format(notDusturbUntil.getTime());


            Resources res = getResources();
            Configuration conf = res.getConfiguration();
            String lang = conf.locale.getLanguage();

            String fileXMLRequest = file.setConfiguration(code, timestampToSend, lang);

            if (XMLHttpPost.isConnectedToInternet(mContext)) {
                String responseXML = null;
                try {
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, mContext,
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    mContext).getUserCredentials()));
                } catch (CertificateException | NoSuchAlgorithmException | KeyManagementException | IOException | KeyStoreException e) {
                    e.printStackTrace();
                }


                everythingCorrect = responseXML == "created";
                if (!everythingCorrect)
                    failCode = CODE_ERROR_NOT_STORED;

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }

            return everythingCorrect;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mUpdatePreferencesTask = null;
            if (success) { // Data stored in server database: aleert to the user
                String alertTreatmentStarted;
                try {
                    alertTreatmentStarted = getString(R.string.changes_sent);
                } catch (IllegalStateException e) {
                    alertTreatmentStarted = mContext.getString(R.string.changes_sent);
                }
                Toast toast = Toast.makeText(mContext, alertTreatmentStarted, Toast.LENGTH_SHORT);
                toast.show();
            } else {
                String errorMessage = "Error";
                switch (failCode) { // Data not stored in server database: changes only in local and alert to the user
                    case CODE_ERROR_NOT_STORED:
                        try {
                            errorMessage = getString(R.string.error_data_only_in_local);
                        } catch (IllegalStateException e) {
                            errorMessage = mContext.getString(R.string.error_data_only_in_local);
                        }
                        Snackbar.make(rootView, errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    case CODE_ERROR_INTERNET_CONNECTION:
                        try {
                            errorMessage = getString(R.string.error_internet_connection);
                        } catch (IllegalStateException e) {
                            errorMessage = mContext.getString(R.string.error_internet_connection);
                        }
                        Snackbar.make(rootView, errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    default:
                        Snackbar.make(rootView, errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                }
                sessionData.setIsConfigurationUpdated(false); // Try sent the information to the server later
            }
            mProgressDialog.dismiss();
        }

        @Override
        protected void onCancelled() {
            mUpdatePreferencesTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnPreferencesFragmentInteractionListener {
        void onPreferencesFragmentInteraction(Uri uri);
        void refreshLanguage();
    }

}
