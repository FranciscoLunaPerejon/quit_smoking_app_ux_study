package com.salumedia.quitandreturn;

/**
 * Created by victor on 9/02/17.
 */

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

/**
 * Created by victor on 21/11/16.
 */
public class BackgroundService extends Service {
//    private SendFitnessActivityTask mSendFitnessActivityTask = null;

    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("WALKIRIA", "SERVICE CALLED");

        if (isNetworkConnected()) {
            Log.d("WALKIRIA", "INTERNET");

//            mSendFitnessActivityTask = new SendFitnessActivityTask((Context)this);
//            mSendFitnessActivityTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);

        } else {
            Log.d("WALKIRIA", "NO INTERNET!");

        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }
}



