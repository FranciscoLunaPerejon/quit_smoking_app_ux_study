package com.salumedia.quitandreturn.utils;

/**
 * Created by victor on 7/02/17.
 */

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.util.Log;

import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;
import com.salumedia.quitandreturn.session.server.MyFirebaseMessagingService;


public class MyJobService extends JobService {

    @Override
    public boolean onStartJob(JobParameters job) {
        // Do some work here
        Log.d("WALKIRIA", "JOB STARTED");


        if (isNetworkConnected()) {
            Log.d("WALKIRIA", "INTERNET");


        } else {
            Log.d("WALKIRIA", "NO INTERNET!");

        }
        return false; // Answers the question: "Is there still work going on?"
    }

    @Override
    public boolean onStopJob(JobParameters job) {

        Log.d("WALKIRIA", "JOB STOPPED");

        return false; // Answers the question: "Should this job be retried?"
    }


    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }

}
