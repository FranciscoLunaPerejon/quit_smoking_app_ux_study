package com.salumedia.quitandreturn.views.forms;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.SFBFragment;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBDate;


/**
 * Created by Francisco on 12/1/17.
 */

/**
 * A fragment that shows the personal data form
 */
public class PersonalDataFormFragment extends SFBFragment {

    // Tag used to identify the fragment and for analytical purpose
    public static final String TAG = "PERSONAL_DATA_FORM";

    // Personalized listener used to send information to container activity
    private OnDemographicsDataFormInteractionListener mListener;

    // Form fields
    EditText name;
    RadioGroup gender;
    EditText birthdate;
    RadioGroup employment;
    EditText startSmokingDate;
    RadioGroup havePatientCode;
    EditText patientCode;
    TextView patientCodeTextView;

    // Access to shared preferences
    SessionData sessionData;

    // Auxiliary view to inflate the fragment. It is used in auxiliary methods, so it is set as an
    // attribute of the class
    View rootView;

    // Default necessary constructor
    public PersonalDataFormFragment(){
    }

    // Constructor that allow receive information from the invoking class
    public static PersonalDataFormFragment newInstance(Bundle arguments){

        PersonalDataFormFragment f =  new PersonalDataFormFragment();
        //Extract information if exists
        if(arguments != null){
            f.setArguments(arguments);
        }
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Not View attributes instantiation
        section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_PERSONAL_DATA_FORM; // Analysis purpose
        sessionData = SessionData.getSessionData(getContext()); // Shared preferences access
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){

        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.form_fragment_personal_data, container, false);

        final int correctDateStyle = R.drawable.text_field;

        // View attributes instantiation

        birthdate = (EditText)rootView.findViewById(R.id.change_birthdate_button);
        birthdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                birthdate.setBackgroundResource(correctDateStyle);

                // Inform which button was clicked. It is important because there are two buttons
                // in this class that are used to invoke a datePicker dialog. When this datePicker is dismiss,
                // the date selected must be showed on the correspondent button, so is necessary to know which
                // button was clicked
                mListener.setDateInDatePicker(birthdate.getId(), getString(R.string.birthday));
            }
        });

        startSmokingDate = (EditText)rootView.findViewById(R.id.change_start_smoking_date);
        startSmokingDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                birthdate.setBackgroundResource(correctDateStyle);
                if(sessionData.isQuittingDateFilled()){ // This field cannot be modified if user is in a quitting period
                    Toast.makeText(getContext(), R.string.cannot_edit_smoking, Toast.LENGTH_LONG).show();
                }else {
                    // Inform which button was clicked. It is important because there are two buttons
                    // in this class that are used to invoke a datePicker dialog. When this datePicker is dismiss,
                    // the date selected must be showed on the correspondent button, so is necessary to know which
                    // button was clicked
                    mListener.setDateInDatePicker(startSmokingDate.getId(), getString(R.string.start_smoking_date));
                }
            }
        });

        name = (EditText) rootView.findViewById(R.id.patient_name);
        name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setBackgroundResource(correctDateStyle);
            }
        });

        gender = (RadioGroup) rootView.findViewById(R.id.gender);
        employment = (RadioGroup) rootView.findViewById(R.id.employment_situation);

        // This allow hide the window keyboard when is touched other place of the screen
        rootView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                InputMethodManager inputMethodManager =(InputMethodManager)getActivity().getSystemService(getActivity().INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(v.getWindowToken(), 0);

                return true;
            }
        });

        havePatientCode = (RadioGroup) rootView.findViewById(R.id.patient_code_radio_group);
        patientCode = (EditText) rootView.findViewById(R.id.patient_code_edit_text);
        patientCodeTextView = (TextView) rootView.findViewById(R.id.patient_code_text_view);

        havePatientCode.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup havePatientCodeRadioGroup, @IdRes int i) {
                RadioButton havePatientCodeRadioButton = (RadioButton) rootView.findViewById(i);
                RadioButton noHavePatientCodeRadioButton = (RadioButton) rootView.findViewById(R.id.not_have_a_patient_code);

                if((havePatientCodeRadioButton.getTag()).equals(noHavePatientCodeRadioButton.getTag())){
                    patientCode.setEnabled(false);
                    patientCode.setBackgroundColor(getResources().getColor(R.color.colorDisable));
                    patientCode.setTextColor(getResources().getColor(R.color.colorDivider));
                    patientCodeTextView.setTextColor(getResources().getColor(R.color.colorDisable));

                }else{
                    patientCode.setEnabled(true);
                    patientCode.setBackgroundDrawable(getResources().getDrawable(R.drawable.text_field));
                    patientCode.setTextColor(getResources().getColor(android.R.color.black));
                    patientCodeTextView.setTextColor(getResources().getColor(android.R.color.black));
                }
            }
        });

        // Shows previous values if fields was filled in the past
        fillCompleteData();

        return rootView;
    }


    // Get the previous values and show it in corresponding field
    private void fillCompleteData(){
        if(sessionData.isFilledName()){
            EditText name = (EditText)rootView.findViewById(R.id.patient_name);
            name.setText(sessionData.getUserNick());
        }
        if(sessionData.isFilledGender()){
            //Gender values in sessionData are the tag-values, attribute defined in layout-xml
            RadioGroup gender = (RadioGroup) rootView.findViewById(R.id.gender);
            RadioButton select = sessionData.getGender().equals(gender.getChildAt(0).getTag())?
                    (RadioButton) gender.getChildAt(0) : (RadioButton) gender.getChildAt(1);
            select.setChecked(true);

        }
        if(sessionData.isFilledBirthDate()){
            EditText birthday = (EditText) rootView.findViewById(R.id.change_birthdate_button);
            birthday.setText(SFBDate.dateToString(sessionData.getBirthDate()));

        }
        if(sessionData.isFilledEmployment()){
            //Employment values in sessionData are the tag-values, attribute defined in layout-xml
            RadioGroup employment = (RadioGroup) rootView.findViewById(R.id.employment_situation);
            RadioButton select = sessionData.getEmploymentStatus().equals(employment.getChildAt(0).getTag())?
                    (RadioButton) employment.getChildAt(0) : (RadioButton) employment.getChildAt(1);
            select.setChecked(true);
        }
        if(sessionData.isFilledStartSmokingData()){
            startSmokingDate.setText(SFBDate.dateToString(sessionData.getStartedSmokingDate()));
        }
        if(sessionData.isFilledPatientCodeQuestion()){
            if(!sessionData.getPatientCode().equals(SessionData.NOT_HAVE_PATIENT_CODE)){
                for (int i = 0; i <havePatientCode.getChildCount(); i++)
                {
                    havePatientCode.getChildAt(i).setEnabled(false);
                }
                patientCode.setEnabled(false);
                this.patientCode.setBackgroundColor(getResources().getColor(R.color.colorDisable));
                patientCode.setTextColor(getResources().getColor(R.color.colorDivider));
                patientCodeTextView.setTextColor(getResources().getColor(R.color.colorDisable));
                patientCode.setText(sessionData.getPatientCode());
            }else {
                havePatientCode.check(R.id.not_have_a_patient_code);

            }
        }

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnDemographicsDataFormInteractionListener) {
            mListener = (OnDemographicsDataFormInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnPersonalDataInteractionListener");
        }

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        mListener.onDemographicsDataFormInteraction(null);
    }

    // Interface used to send information to container activity
    public interface OnDemographicsDataFormInteractionListener {
        void onDemographicsDataFormInteraction(Uri uri);
        void setDateInDatePicker(int id, String title);
    }

}

