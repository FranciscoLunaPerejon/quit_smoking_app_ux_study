package com.salumedia.quitandreturn.views.main_navigationdrawer_sections;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBAppInteractionAnalytic;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.utils.SFBAnalytics;
import com.salumedia.quitandreturn.views.main_navigationdrawer_sections.section_messages.MessageBoxFragment;
import com.salumedia.quitandreturn.views.main_navigationdrawer_sections.section_profile_data.UserProfileDataFragment;
import com.salumedia.quitandreturn.views.main_navigationdrawer_sections.section_user.UserStatisticsFragment;

import java.text.SimpleDateFormat;
import java.util.Calendar;



/**
 * Created by Francisco on 26/12/16.
 */

/**
 * This class manage the main section tabs, benefits and badges section, messages section and helping
 * tools section.
 */
public class TabsInitFragment extends Fragment {

    // This class manage the main section tabs and register the time that the user spent in each.
    // This "records" have an analytical purpose

    // key for bundle extra (section which must be shown first)
    private static final String tabSectionKey = "tabSection";

    // possible values for bundle key extra
    public static final String TAB_BENEFITS = "BENEFITSandBADGES";
    public static final String TAB_MESSAGES = "MESSAGES";
    public static final String TAB_PROFILE_DATA = "PROFILEDATA";


    LocalDataBaseHelper db;


    // View attributes

    // Tabs menu which manage the section to be shown
    TabLayout tabLayout;
    // Where is shown the section
    ViewPager mViewPager;

    // Attributes used for analytical purpose

    private String tabName;
    private String date = (new SimpleDateFormat("yyyy-MM-dd")).format(Calendar.getInstance().getTime());
    private String time = (new SimpleDateFormat("HH:mm:ss.SSS")).format(Calendar.getInstance().getTime());
    private Float init = Long.valueOf(System.nanoTime()/1000000).floatValue();

    // Default initial section
    private String initialSection = TAB_BENEFITS;

    private OnTabsInitFragmentInteractionListener mListener;

    // Constructor that allow indicate which tab section must be shown first
    public static TabsInitFragment newInstance(String tabSection){
        TabsInitFragment fragment = new TabsInitFragment();
        Bundle args = new Bundle();
        args.putString(tabSectionKey, tabSection);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        db = new LocalDataBaseHelper(getContext());

        //Extract information (first section to show) if exists
        if (getArguments() != null) {
            initialSection = getArguments().getString(tabSectionKey);
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_tabs_init,container,false);

        // Set adapter to viewpager.
        mViewPager = (ViewPager) rootView.findViewById(R.id.pager);
        mViewPager.setAdapter(new TabsInitFragment.SectionsPagerAdapter(getChildFragmentManager()));
        // Prepare tabs
        tabLayout = (TabLayout) rootView.findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.ic_assessment_white_24dp).setTag(TAB_BENEFITS);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_message_white_24dp).setTag(TAB_MESSAGES);
        tabLayout.getTabAt(2).setIcon(R.drawable.ic_profile_white_24dp).setTag(TAB_PROFILE_DATA);

        //System.out.println("The initialSection is: " + initialSection);

        // Select the first section to be shown
        switch (initialSection) {
            case TAB_BENEFITS:
                tabLayout.getTabAt(0).select();
                break;
            case TAB_MESSAGES:
                tabLayout.getTabAt(1).select();
                break;
            case TAB_PROFILE_DATA:
                tabLayout.getTabAt(2).select();
                break;
            default:
                tabLayout.getTabAt(2).select();
                break;
        }

        // This Listener is used to get analytical information.
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            // When a tab is selected (Enter in a section), catch the moment in which is selected
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                date = (new SimpleDateFormat("yyyy-MM-dd")).format(Calendar.getInstance().getTime());
                time = (new SimpleDateFormat("HH:mm:ss.SSS")).format(Calendar.getInstance().getTime());
                init = Long.valueOf(System.nanoTime()/1000000).floatValue();

                SessionData sessionData = SessionData.getSessionData(getContext());

                sessionData.setSectionAccessDate(date);
                sessionData.setSectionAccessTime(time);
                sessionData.setSectionAccessInit(init);

                mListener.changeSection((String) tab.getTag());
            }

            // When a tab is unselected (Go out of a section), the time spent in this section is saved
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

                tabName = (String) tab.getTag();
                Float fin = Long.valueOf(System.nanoTime() / 1000000).floatValue();

                SessionData sessionData = SessionData.getSessionData(getContext());

                if(tabName!=null && tabName.equals(TAB_MESSAGES)) {
                    tabName = sessionData.getLastSubsectionMessages();
                    init = sessionData.getSectionAccessInit();
                    time = sessionData.getSectionAccessTime();
                    date = sessionData.getSectionAccessDate();
                }else{
                    sessionData.setLastSection(tabName);
                }

                // Data is stored in a local DB. It is sent to server when there are some rows in table db
                SFBAppInteractionAnalytic SFBAppInteractionAnalytic = new SFBAppInteractionAnalytic(tabName, date, time, (fin-init));

                db.insertAppInteraction(SFBAppInteractionAnalytic);

                try{
                    SFBAnalytics.startLogTimeInSection(tab.getTag() +
                            "_author:" +  SessionData.getSessionData(getContext()).getUserData(getContext()).getUserId() +
                            "_date:" + date + " " +  time);
                    SFBAnalytics.stopLogTimeInSection(tab.getTag() +
                            "_author:" + SessionData.getSessionData(getContext()).getUserData(getContext()).getUserId() +
                            "_date:" + date + " " +  time);
                }catch (Exception e){
                    SFBAnalytics.startLogTimeInSection(tab.getTag() + "_author:NOT_AVALIABLE" +
                            "_date:" + date + " " +  time);
                    SFBAnalytics.stopLogTimeInSection(tab.getTag() + "_author:NOT_AVALIABLE" +
                            "_date:" + date + " " +  time);
                }

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        return rootView;
    }

    // This method must to save the analytical information about the last tab shown.
    @Override
    public void onPause() {
        super.onPause();
        tabName = (String) tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getTag();
        if(tabName!=null && tabName.equals(TAB_MESSAGES)){
            SessionData sessionData = SessionData.getSessionData(getContext());
            tabName = sessionData.getLastSubsectionMessages();
        }
        Float fin = Long.valueOf(System.nanoTime()/1000000).floatValue();
        SFBAppInteractionAnalytic SFBAppInteractionAnalytic = new SFBAppInteractionAnalytic(tabName, date, time, (fin-init));

        db.insertAppInteraction(SFBAppInteractionAnalytic);
    }

    /**
     * A {@link FragmentPagerAdapter} which manage sections, and tab titles
     */
    public class SectionsPagerAdapter extends FragmentStatePagerAdapter {

        private String mFragmentTitles[] = {getString(R.string.statistics_tab_title), getString(R.string.messages_tab_title), getString(R.string.helping_tab_title)};

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            switch(position) {
                case 0:
                    return new UserStatisticsFragment();
                case 1:
                    //return MessageNotificationBoxFragment.newInstance(initialSection);
                    return MessageBoxFragment.newInstance(new Bundle());
                default:
                    return new UserProfileDataFragment();
                    //return new SupportMenuFragment();
            }
        }

        @Override
        public int getCount() {
            return mFragmentTitles.length;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitles[position];
        }

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnTabsInitFragmentInteractionListener) {
            mListener = (OnTabsInitFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnTabsInitFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        mListener.onTabsInitFragmentInteraction(null);
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnTabsInitFragmentInteractionListener{
        void onTabsInitFragmentInteraction(Uri uri);
        void changeSection(String sectionTag);
    }
}
