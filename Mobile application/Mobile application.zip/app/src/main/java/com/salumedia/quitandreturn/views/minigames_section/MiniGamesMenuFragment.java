package com.salumedia.quitandreturn.views.minigames_section;


import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.SFBFragment;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;

public class MiniGamesMenuFragment extends SFBFragment {

    View rootView;

    Button buttonWhacking;
    Button buttonBalloon;
    Button blowRelaxButton;
    Button buttonPhExInstructs;


    // Default necessary constructor
    public MiniGamesMenuFragment() {
    }

    // Constructor that allow receive information from the invoking class
    public static MiniGamesMenuFragment newInstance(Bundle arguments){

        MiniGamesMenuFragment f =  new MiniGamesMenuFragment();
        //Extract information if exists
        if(arguments != null){
            f.setArguments(arguments);
        }
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Not View attributes instantiation
        section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_MINIGAMES;; // Analysis purpose
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        rootView = inflater.inflate(R.layout.fragment_minigames, null);
        buttonWhacking = (Button) rootView.findViewById(R.id.whacking_moles_button);
        buttonBalloon = (Button) rootView.findViewById(R.id.blow_balloon_quickly_button);
        blowRelaxButton = (Button) rootView.findViewById(R.id.blow_balloon_button);
        buttonPhExInstructs =  (Button) rootView.findViewById(R.id.ph_ex_instructs_button);

        buttonWhacking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(getActivity(), WhackingMolesActivity.class);
                //intent.putExtra(SFBConstantsAndCodes.SECTION_FRAGMENT_CODE, fragmentCode);
                startActivity(intent);
                //startActivity(intent);
            }
        });

        blowRelaxButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(checkRecordAudioPermission()) {
                    Intent intent;
                    intent = new Intent(getActivity(), BalloonActivity.class);
                    //intent.putExtra(SFBConstantsAndCodes.SECTION_FRAGMENT_CODE, fragmentCode);
                    Bundle b = new Bundle();
                    b.putInt("mode", 0); //0: relax, 1:fast
                    intent.putExtras(b); //Put your id to your next Intent
                    startActivity(intent);
                }
                //startActivity(intent);
            }
        });

        buttonBalloon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(checkRecordAudioPermission()) {
                    Intent intent;
                    intent = new Intent(getActivity(), BalloonActivity.class);
                    //intent.putExtra(SFBConstantsAndCodes.SECTION_FRAGMENT_CODE, fragmentCode);
                    Bundle b = new Bundle();
                    b.putInt("mode", 1); //0: relax, 1:fast
                    intent.putExtras(b); //Put your id to your next Intent
                    startActivity(intent);
                }
                //startActivity(intent);
            }
        });


        buttonPhExInstructs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(getActivity(), PhysicalExercisesActivity.class);
                //intent.putExtra(SFBConstantsAndCodes.SECTION_FRAGMENT_CODE, fragmentCode);
                startActivity(intent);
            }
        });

        return rootView;
    }

    boolean checkRecordAudioPermission(){
        boolean permissionGranted = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        if (permissionGranted) {
            //Log.i("GFAPI", "Permission Granted");
            return true;
        } else if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.RECORD_AUDIO)) {
            //Log.i("GFAPI", "Displaying prompt");
            new android.support.v7.app.AlertDialog.Builder(getContext())
                    .setMessage("You need to allow access to Audio Recording")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .create()
                    .show();
        } else {
            ActivityCompat.requestPermissions(
                    getActivity(),
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    0
            );
        }
        //Log.i("GFAPI", "Permission denied");
        return false;
    }

}