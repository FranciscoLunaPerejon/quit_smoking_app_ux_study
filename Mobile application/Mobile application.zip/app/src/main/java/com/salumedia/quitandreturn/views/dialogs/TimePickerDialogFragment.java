package com.salumedia.quitandreturn.views.dialogs;

import android.app.Activity;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.text.format.DateFormat;
import android.widget.TextView;
import android.widget.TimePicker;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;

import java.util.Calendar;



/**
 * Created by joaquin on 28/8/16.
 */
/**
 * This class shows a small window with a editable time field to the user
 */
public class TimePickerDialogFragment extends DialogFragment
        implements TimePickerDialog.OnTimeSetListener {

    public static final String VIEW_ID = "viewId";

    private boolean interval;
    private static String title;
    OnTimePickedListener mCallback;
    Integer mViewId = null;

    /**
     * An interface containing onTimePicked() method signature.
     * Container Activity must implement this interface.
     */
    public interface OnTimePickedListener {
        void onTimePicked(int textId, int hour, int minute, String title);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        try {
            mCallback = (OnTimePickedListener)activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement OnTimePickedListener.");
        }
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current time as the default values for the picker
        final Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);
        Bundle arguments = getArguments();
        interval = arguments.getBoolean(SFBConstantsAndCodes.INTERVAL);
        mViewId = arguments.getInt(VIEW_ID);
        title = interval == SFBConstantsAndCodes.BEGIN ? getString(R.string.start_time_range) : getString(R.string.end_time_range);
        TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(), this, hour, minute,
                DateFormat.is24HourFormat(getActivity()));

        TextView headerTextView = new TextView(getContext());
        headerTextView.setText("");

        timePickerDialog.setCustomTitle(headerTextView);
        // Create a new instance of TimePickerDialog and return it
        return timePickerDialog;
    }

    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        // Do something with the time chosen by the user
        if(mCallback != null)
        {
            mCallback.onTimePicked(mViewId, hourOfDay, minute, title);
        }
    }

}
