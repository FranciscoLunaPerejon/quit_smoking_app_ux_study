package com.salumedia.quitandreturn.views.forms;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;

import com.salumedia.quitandreturn.R;


/**
 * Created by Francisco on 29/12/16.
 */

/**
 * A fragment that shows the sign up form
 */
public class ConfirmationSignUpFormFragment extends Fragment {

    // Tag used to identify the fragment and for analytical purpose
    public static final String TAG = "CONFIRMATION_SIGN_UP_FORM";

    // NOTE: This fragment not need load previous data, and contained views don't need a special
    // behaviour, so these don't need be invoked

    // Default necessary constructor
    public ConfirmationSignUpFormFragment(){
    }

    // Constructor that allow receive information from the invoking class
    public static ConfirmationSignUpFormFragment newInstance(Bundle arguments){

        ConfirmationSignUpFormFragment f =  new ConfirmationSignUpFormFragment();
        //Extract information if exists
        if(arguments != null){
            f.setArguments(arguments);
        }
        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inflating the fragment
        View rootView = inflater.inflate(R.layout.form_fragment_confirmation_sign_up, container, false);

        // This allow hide the window keyboard when is touched other place of the screen
        rootView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                InputMethodManager inputMethodManager =(InputMethodManager)getActivity().getSystemService(getActivity().INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(v.getWindowToken(), 0);

                return true;
            }
        });

        return rootView;
    }



}
