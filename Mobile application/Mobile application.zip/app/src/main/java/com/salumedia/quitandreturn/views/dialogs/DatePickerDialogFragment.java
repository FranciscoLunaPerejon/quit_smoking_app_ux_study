package com.salumedia.quitandreturn.views.dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import com.salumedia.quitandreturn.R;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Created by Francisco on 16/1/17.
 */

/**
 * This class shows a small window with a editable date field to the user
 */
public class DatePickerDialogFragment extends DialogFragment {

    private static final String TITLE = "Title";

    private OnDatePickerFragmentInteractionListener mListener;

    private TextView title;
    private DatePicker datepicker;
    private Button cancelButton;
    private Button okButton;

    public DatePickerDialogFragment(){

    }

    public static DatePickerDialogFragment newInstance(String title){
        DatePickerDialogFragment datePickerDialogFragment = new DatePickerDialogFragment();

        Bundle args = new Bundle();
        args.putString(TITLE, title); //Message body

        datePickerDialogFragment.setArguments(args);

        return datePickerDialogFragment;
    }



    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        LayoutInflater inflater = getActivity().getLayoutInflater();
        final View rootView = inflater.inflate(R.layout.form_fragment_datepicker, null);

        title = (TextView) rootView.findViewById(R.id.generic_date_picker_dialog_title);

        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        datepicker = (DatePicker) rootView.findViewById(R.id.generic_date_picker_dialog);
        datepicker.updateDate(year, month, day);

        cancelButton = (Button) rootView.findViewById(R.id.generic_date_picker_cancel_button);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

        okButton = (Button) rootView.findViewById(R.id.generic_date_picker_ok_button);
        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = new GregorianCalendar(datepicker.getYear(), datepicker.getMonth(), datepicker.getDayOfMonth());
                mListener.setDate(cal);
                dismiss();
            }
        });

        // Builder used to manage the dialog fragment
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(rootView)
        /*.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Calendar cal = new GregorianCalendar(datepicker.getYear(), datepicker.getMonth(), datepicker.getDayOfMonth());
                mListener.setDate(cal);
            }
        })
        .setNegativeButton(R.string.cancel_form, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        })*/;

        Dialog dialog = builder.create();
        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        AlertDialog d = (AlertDialog)getDialog();
        if(d != null) {

            String titleSting = getArguments().getString(TITLE);

            title.setText(titleSting);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnDatePickerFragmentInteractionListener) {
            mListener = (OnDatePickerFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnDatePickerFragmentInteractionListener");
        }
    }

    /**
     * A simple listener interface which allow the communication of the fragment with its activity.
     *
     */
    public interface OnDatePickerFragmentInteractionListener{

        void setDate(Calendar calendar);
    }

}
