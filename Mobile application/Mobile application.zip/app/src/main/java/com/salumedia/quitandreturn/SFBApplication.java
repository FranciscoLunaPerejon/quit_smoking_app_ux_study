package com.salumedia.quitandreturn;

import android.app.Application;

import com.flurry.android.FlurryAgent;

import org.acra.ACRA;
import org.acra.ReportingInteractionMode;
import org.acra.annotation.ReportsCrashes;

/**
 * Created by fluna on 17/08/2017.
 */

@ReportsCrashes(mailTo = "flunaperejon@gmail.com",
        mode = ReportingInteractionMode.TOAST,
        resToastText = R.string.crash_toast_text)

public class SFBApplication extends Application {

    private static final String FLURRY_API_KEY = "SQZ83YQM3RM36H2CD2Z3";
    private static final String DEV_FLURRY_API_KEY = "K9VV5N7XMY6CTSF48XQF";

    @Override
    public void onCreate() {
        super.onCreate();
        new FlurryAgent.Builder()
                .withLogEnabled(false)
                .build(this, (!BuildConfig.DEBUG) ? FLURRY_API_KEY : DEV_FLURRY_API_KEY);

        ACRA.init(this);
    }
}
