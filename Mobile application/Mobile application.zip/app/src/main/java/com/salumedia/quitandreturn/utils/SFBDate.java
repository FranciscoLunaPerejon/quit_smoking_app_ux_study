package com.salumedia.quitandreturn.utils;

import android.util.Log;
import android.util.SparseIntArray;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by joaquin on 23/6/16.
 */

/**
 * Util methods to convert Strings in an specific format to Date or Calendar, and vice versa
 */
public class SFBDate {

    public final static String FORMAT_HOUR = "HH:mm";

    public final static String FORMAT_WEEK_WITH_YEAR = "w-yyyy";
    public final static String FORMAT_WEEK_GENERAL = "yyyy-MM-dd-EEEE";
    public final static String FORMAT_SPANISH_CAL = "DD-MM-yyyy";

    private SFBDate() {
    }


    // Suma los días recibidos a la fecha
    public static Date sumarRestarDiasFecha(Date fecha, int dias) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(fecha); // Configuramos la fecha que se recibe
        calendar.add(Calendar.DAY_OF_YEAR, dias);  // numero de días a añadir, o restar en caso de días<0
        return calendar.getTime(); // Devuelve el objeto Date con los nuevos días añadidos
    }

    //Parseo  date to calendar
    public static Calendar dateToCalendar(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }

    /**
     * NO USAR PARA FECHAS QUE SIGUEN EL ESTANDAR ISO 13.606
     * <p>
     * Get Day of Week (today)
     *
     * @param date Date Object
     * @return time in milliseconds
     */
    public static int getDayWeekOfDate(Date date) {
        int day;

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        day = calendar.get(Calendar.DAY_OF_WEEK) - 1;

        return day;
    }


    /**
     * NO USAR PARA FECHAS QUE SIGUEN EL ESTANDAR ISO 13.606
     * <p>
     * Get Day of Week (today)
     *
     * @param date Date Object
     * @return time in milliseconds
     */
    public static int getDayWeekOfDate2(Date date) {
        int day;

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        day = calendar.get(Calendar.DAY_OF_WEEK);

        return day;
    }


    /**
     * Mapea la conversión entre el día seleccionado (0,1,2,3,4,5,6) y el día de la semana según la clase Calendar (2,3,4,5,6,7,1)
     * Siendo la posición 0 el Lunes (2) La posición 1 el Martes (3) Y así sucesivamente.
     *
     * @param dayOfWeek dia de la semana seleccionado (0 - 6)
     * @return dia de la semana correspondiente al Calendar.DAY_OF_WEEK
     */
    public static int numDayOfWeekToCalendarDayOfWeek(int dayOfWeek) {
        SparseIntArray sparse = new SparseIntArray();
        sparse.put(0, 2);
        sparse.put(1, 3);
        sparse.put(2, 4);
        sparse.put(3, 5);
        sparse.put(4, 6);
        sparse.put(5, 7);
        sparse.put(6, 1);

        return sparse.get(dayOfWeek, -1);
    }

    /**
     * NO USAR PARA FECHAS QUE SIGUEN EL ESTANDAR ISO 13.606
     * <p>
     * Get the Day of this Week (yesterday)
     *
     * @param date Date Object
     * @return time in milliseconds
     */
    public static int getBeforeDayOfDate(Date date) {

        int day;

        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DAY_OF_WEEK, -1);

        day = cal.get(Calendar.DAY_OF_WEEK);

        return day;
    }

    /**
     * NO USE WITH THE STANDARD ISO 13,606
     * <p>
     * Formats a string to an object date in the format we introduce as the second parameter.
     * The formatter must match the structure of the text string.
     *
     * @param dateString   Date to format
     * @param typeOfFormat Format to Use in SimpleDateFormat
     * @return fecha   Fecha formateada.
     */
    public final static Date parseStringToDate(String dateString, String typeOfFormat) {
        Date fecha = null;
        SimpleDateFormat format = new SimpleDateFormat(typeOfFormat);
        if (dateString != null && dateString.length() > 0) {
            Calendar calendar = Calendar.getInstance();
            try {
                fecha = format.parse(dateString);
            } catch (ParseException e) {
                Log.i("FuncionesFecha", String.format("parseStringToDate: no ha podido parsear: %s, con formato: %s",
                        dateString, format.toPattern()));
                e.printStackTrace();
            }
        }
        return fecha;
    }

    /**
     * NO USE WITH THE STANDARD ISO 13,606
     * <p>
     * Formats a string to an object calendar in the format we introduce as the second parameter.
     * The formatter must match the structure of the text string.
     *
     * @param str          Time to format
     * @param typeOfFormat Format to Use in SimpleDateFormat
     * @return fecha   Fecha formateada.
     */
    public final static Calendar parseStringToCal(String str, String typeOfFormat) {
        Calendar time = null;
        Date fecha = parseStringToDate(str, typeOfFormat);
        if (fecha != null) {
            time = Calendar.getInstance();
            time.setTime(fecha);
        }
        return time;
    }

    /**
     * NO USE WITH THE STANDARD ISO 13,606
     * <p>
     * Formats a date to an object string in the format we introduce as the second parameter.
     * The formatter must match the structure of the date.
     *
     * @param date         Date to format
     * @param typeOfFormat Format to Use in SimpleDateFormat
     * @return fecha   Fecha formateada.
     */
    public final static String formatDateToString(Date date, String typeOfFormat) {
        String fecha = null;
        SimpleDateFormat format = new SimpleDateFormat(typeOfFormat);
        if (date != null) {
            Calendar calendar = Calendar.getInstance();
            fecha = format.format(date);
        }
        return fecha;
    }

    /**
     * Extraer las horas y minutos de un fecha.
     *
     * @param date
     * @return
     */
    public final static Date parseDateToHour(Date date) {
        Date fecha = null;
        SimpleDateFormat format = new SimpleDateFormat(FORMAT_HOUR);
        if (date != null) {
            Calendar calendar = Calendar.getInstance();
            try {
                fecha = format.parse(format.format(date));
            } catch (ParseException e) {
                Log.i("FuncionesFecha", String.format("parseDateToHour: no ha podido parsear: %s, con formato: %s",
                        date.toString(), format.toPattern()));
                e.printStackTrace();
            }
        }
        return fecha;
    }

    /**
     * (NO MODIFICAR. MÉTODO SIGUIENDO ISO 13.606)
     * <p>
     * Método Definido para el manejo de fechas según la ISO 13.606
     *
     * @param cadena Cadena que recoge la fecha a formatear.
     * @return cal     Objeto Calendar que recoge la fecha y horas concretas.
     */
    public static Calendar stringToCalendar(String cadena) {
        Calendar cal = null;
        if (cadena != null)
            if (cadena.length() > 0) {
                SimpleDateFormat ft1;

                if (cadena.length() == 8) {
                    ft1 = new SimpleDateFormat("yyyyMMdd");
                } else if (cadena.length() == 10) {
                    ft1 = new SimpleDateFormat("yyyy-MM-dd");
                } else if (cadena.length() == 12) {
                    ft1 = new SimpleDateFormat("yyyyMMddHHmm");
                } else {
                    ft1 = new SimpleDateFormat("yyyyMMddHHmmss");
                }

                Date fecha = null;
                try {
                    fecha = ft1.parse(cadena);
                    cal = Calendar.getInstance();
                    cal.setTime(fecha);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

            }
        return cal;
    }


    public static List<Calendar> convertirListaCadenaAFecha(List<String> list) {
        List<Calendar> listaCal = new ArrayList<>();
        for (String cad : list) {
            listaCal.add(stringToCalendar(cad));
        }
        return listaCal;
    }

    public static Date stringToDate(String string) throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return simpleDateFormat.parse(string);
    }



    public static String timestampToString(Calendar cal){
        String fecha = "";
        if (cal != null) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
            fecha = simpleDateFormat.format(cal.getTime());
        }
        return fecha;
    }

    /**
     * Definida ISO 13.606
     *
     * @param cal
     * @return
     */

    public static String dateToString(Calendar cal) {
        String fecha = "";
        if (cal != null) {
            return dateToString(cal.getTime());
        }
        return fecha;
    }
    public static String dateToString(long millis) {
        return dateToString(new Date(millis));
    }

    public static String dateToString(Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return simpleDateFormat.format(date);
    }

    public static String dateToStringFormatoVisual(Calendar cal) {
        String fecha = "";
        if (cal != null) {
            NumberFormat ftDosDigitos = NumberFormat.getIntegerInstance();

            ftDosDigitos.setMinimumIntegerDigits(2);
            fecha = ftDosDigitos.format(cal.get(Calendar.DAY_OF_MONTH)) + "-"
                    + ftDosDigitos.format(cal.get(Calendar.MONTH) + 1) + "-"
                    + cal.get(Calendar.YEAR);
        }
        return fecha;
    }


    public static List<String> turnDateListToString(List<Calendar> listaCal) {
        List<String> listaStr = new ArrayList<>();
        for (Calendar cal : listaCal) {
            listaStr.add(convertirFechaACadenaSinHora(cal));
        }
        return listaStr;
    }


    public static String convertirFechaACadenaSinHora(Calendar cal) {
        String fecha = "";
        if (cal != null) {
            NumberFormat ftDosDigitos = NumberFormat.getIntegerInstance();

            ftDosDigitos.setMinimumIntegerDigits(2);
            fecha = cal.get(Calendar.YEAR)
                    + "-" + ftDosDigitos.format(cal.get(Calendar.MONTH) + 1) + "-"
                    + ftDosDigitos.format(cal.get(Calendar.DAY_OF_MONTH));
        }
        return fecha;
    }

    public static String fechaFormateada(String fechaaf) {
        String fecha = "";
        NumberFormat ftDosDigitos = NumberFormat.getIntegerInstance();

        ftDosDigitos.setMinimumIntegerDigits(2);
        if (fechaaf.length() > 0) {
            fecha = ftDosDigitos.format(Integer.parseInt(fechaaf.substring(6, 8))) + "/" +
                    ftDosDigitos.format(Integer.parseInt(fechaaf.substring(4, 6)));
            fecha += "/" + fechaaf.substring(0, 4) + ", " +
                    ftDosDigitos.format(Integer.parseInt(fechaaf.substring(8, 10))) + ":" +
                    ftDosDigitos.format(Integer.parseInt(fechaaf.substring(10))) + ".";
        }
        return fecha;
    }

    public static String fechaFormateada(Calendar cal) {
        String fecha = "";
        NumberFormat ftDosDigitos = NumberFormat.getIntegerInstance();

        ftDosDigitos.setMinimumIntegerDigits(2);

        if (cal != null) {
            fecha = ftDosDigitos.format(cal.get(Calendar.DAY_OF_MONTH)) + "/" + ftDosDigitos.format((cal.get(Calendar.MONTH) +
                    1));
            fecha += "/" + cal.get(Calendar.YEAR) + ", " + ftDosDigitos.format(cal.get(Calendar.HOUR_OF_DAY)) +
                    ":" + ftDosDigitos.format(cal.get(Calendar.MINUTE)) + ".";
        }
        return fecha;
    }

    public static String timeMillisPrettyPrint(Integer millis) {
        String formattedTime = "";
        Integer minutes = millis / (60 * 1000);
        if (minutes < 60) {
            formattedTime = minutes + "m";
        } else {
            Integer hours = minutes / 60;
            minutes = minutes - (hours * 60);
            formattedTime = hours + "h" + minutes + "m";
        }
        return formattedTime;
    }

}
