package com.salumedia.quitandreturn.model;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Created by joaquin on 19/5/16.
 */

/**
 * It contains the user profile information
 */
public class SFBUser {
    private String userId;
    private String password;
    private SFBPersonalData personalData;
    private SFBSmokingData smokingData;

    public SFBUser(){

    }

    public SFBUser(String userId, String userName, Calendar quittingDate, String photoUrl){
        this.userId = userId;
        this.personalData = new SFBPersonalData(userName, photoUrl);
        this.smokingData = new SFBSmokingData();
    }
    public SFBUser(String userId, SFBPersonalData personalData, SFBSmokingData smokingData) {
        this.userId = userId;
        this.personalData = personalData;
        this.smokingData = smokingData;
    }
    public SFBUser(String userId) {
        this.userId = userId;
    }

    // For tests without use server
    public SFBUser(String userId, boolean fake) {
        this.userId = userId;
        if (fake){
            this.password = "fake";
            Calendar calendar = Calendar.getInstance();
            calendar.set(1984, Calendar.MARCH, 13);
            this.personalData = new SFBPersonalData("Joaquín", 'h', calendar, "empleado");
            calendar.set(2006, Calendar.MAY, 1);
            Calendar starting = (Calendar) calendar.clone();
            calendar.set(2016, Calendar.AUGUST, 1);
            Calendar quitting = (Calendar) calendar.clone();
            SFBQuittingAttempt quittingPeriod= SFBQuittingAttempt.getInstance(10f, 50f, "\\u20ac", quitting, null, 5, 5);
            List<SFBQuittingAttempt> quittingPeriods = new ArrayList<>();
            quittingPeriods.add(quittingPeriod);
            this.smokingData = new SFBSmokingData(starting, quittingPeriods);
        }
    }

    public void setPersonalData(SFBPersonalData personalData) {
        this.personalData = personalData;
    }

    public void setSmokingData(SFBSmokingData smokingData) {
        this.smokingData = smokingData;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public SFBPersonalData getPersonalData() {
        return personalData;
    }

    public SFBSmokingData getSmokingData() {
        return smokingData;
    }

}
