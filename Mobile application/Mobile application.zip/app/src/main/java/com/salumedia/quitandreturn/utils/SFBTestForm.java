package com.salumedia.quitandreturn.utils;

import android.widget.RadioGroup;

import com.salumedia.quitandreturn.R;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;


/**
 * Created by Francisco on 13/1/17.
 */
/**
 * It contains a Fagerstrom or Richmond test responses
 */
public class SFBTestForm {

    // Ids of radiogroups and radiobuttons Views in the respective layout
    private final Integer[][] fagerstromQuestionnaireViewsIds = {{R.id.fagerstrom_q1,R.id.fagerstrom_q1_a1, R.id.fagerstrom_q1_a2, R.id.fagerstrom_q1_a3, R.id.fagerstrom_q1_a4},
                    {R.id.fagerstrom_q2,R.id.fagerstrom_q2_a1, R.id.fagerstrom_q2_a2},
                    {R.id.fagerstrom_q3,R.id.fagerstrom_q3_a1, R.id.fagerstrom_q3_a2},
                    {R.id.fagerstrom_q4,R.id.fagerstrom_q4_a1, R.id.fagerstrom_q4_a2, R.id.fagerstrom_q4_a3, R.id.fagerstrom_q4_a4},
                    {R.id.fagerstrom_q5,R.id.fagerstrom_q5_a1, R.id.fagerstrom_q5_a2},
                    {R.id.fagerstrom_q6,R.id.fagerstrom_q6_a1, R.id.fagerstrom_q6_a2}};

    private final Integer[][] richmondQuestionnaireViewsIds = {{R.id.richmond_q1,R.id.richmond_q1_a1, R.id.richmond_q1_a2},
                    {R.id.richmond_q2,R.id.richmond_q2_a1, R.id.richmond_q2_a2, R.id.richmond_q2_a3, R.id.richmond_q2_a4},
                    {R.id.richmond_q3,R.id.richmond_q3_a1, R.id.richmond_q3_a2, R.id.richmond_q3_a3, R.id.richmond_q3_a4},
                    {R.id.richmond_q4,R.id.richmond_q4_a1, R.id.richmond_q4_a2, R.id.richmond_q4_a3, R.id.richmond_q4_a4}};

    private Type type;
    private List<RadioGroup> answers;

    public static SFBTestForm newInstance(Type type, List<RadioGroup> answers) {
        return new SFBTestForm(type, answers);
    }

    public enum Type{FAGERSTROM, RICHMOND};

    private SFBTestForm(Type type, List<RadioGroup> answers){

        this.type = type;
        this.answers = answers;
    }


    public Type getType() {
        return type;
    }

    public List<RadioGroup> getAnswers() {
        return answers;
    }

    public void setAnswers(List<RadioGroup> answers) {
        this.answers = answers;
    }

    // Used to calculate test results. Is a summation test. Search for Fagerstrom and Richmond tests
    // for more information
    public int getTestResults(){
        int res = 0;

        switch (type){
            case FAGERSTROM:
                for (int i = 0; i < fagerstromQuestionnaireViewsIds.length; i++) {
                    //This question sum points in opposite to responses option order
                    if (fagerstromQuestionnaireViewsIds[i][0] == R.id.fagerstrom_q4)
                        res = res + Arrays.asList(fagerstromQuestionnaireViewsIds[i]).indexOf(answers.get(i).getCheckedRadioButtonId()) - 1;
                    else {
                        List<Integer> aux = Arrays.asList(fagerstromQuestionnaireViewsIds[i]);
                        Collections.reverse(aux);
                        res = res + aux.indexOf(answers.get(i).getCheckedRadioButtonId());
                    }
                }
                break;
            case RICHMOND:

                for (int i = 0; i< richmondQuestionnaireViewsIds.length; i++) {
                    res = res + Arrays.asList(richmondQuestionnaireViewsIds[i]).indexOf(answers.get(i).getCheckedRadioButtonId()) - 1;
                }
                break;
        }
        return res;
    }

    public boolean isFilled(){
        boolean res = true;
        for(RadioGroup i: answers){
            if(i.getCheckedRadioButtonId()==-1){
                res = false;
                break;
            }
        }
        return res;
    }

    @Override
    public String toString() {
        return "SFBTestForm{" +
                "answers=" + answers +
                ", type='" + type + '\'' +
                '}';
    }
}
