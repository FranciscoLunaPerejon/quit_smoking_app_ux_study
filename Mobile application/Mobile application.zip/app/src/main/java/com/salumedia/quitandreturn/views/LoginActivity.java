package com.salumedia.quitandreturn.views;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBNotification;
import com.salumedia.quitandreturn.model.SFBPersonalData;
import com.salumedia.quitandreturn.model.SFBQuittingAttempt;
import com.salumedia.quitandreturn.model.SFBSmokingData;
import com.salumedia.quitandreturn.model.SFBUser;
import com.salumedia.quitandreturn.session.local.AlarmReceiver;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.XMLHttpPost;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.session.server.xml_operations.RequestXMLReader;
import com.salumedia.quitandreturn.utils.ImageConversions;
import com.salumedia.quitandreturn.utils.SFBChecks;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBDate;
import com.salumedia.quitandreturn.utils.SFBEncode;
import com.salumedia.quitandreturn.views.main_navigationdrawer_sections.TabsInitFragment;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


/**
 * Created by Francisco on 28/12/16.
 */

public class LoginActivity extends AppCompatActivity {

    private UserLoginTask mAuthTask = null;

    private ResetPasswordRequestTask mResetPassTask;

    Button loginButton;
    EditText userName;
    EditText userPass;
    TextView newUser;
    TextView missedPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        findViewById(R.id.login_layout).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                InputMethodManager inputMethodManager =(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(v.getWindowToken(), 0);

                return true;
            }
        });

        loginButton = (Button) findViewById(R.id.login_button);

        userName = (EditText) findViewById(R.id.login_user_name);
        userPass = (EditText) findViewById(R.id.login_user_password);
        newUser = (TextView) findViewById((R.id.login_new_user));
        missedPassword = (TextView) findViewById(R.id.missed_password);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager inputMethodManager =(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(v.getWindowToken(), 0);
                attemptLogin();
            }
        });

        newUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, FormActivity.class);
                intent.putExtra("idForm", SFBConstantsAndCodes.SIGN_UP_FORM_ID);
                startActivity(intent);
                finish();
            }
        });

        missedPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);

                final LayoutInflater inflater = LoginActivity.this.getLayoutInflater();
                final View dialogView = inflater.inflate(R.layout.dialog_username_to_change_password, null);
                builder.setView(dialogView);

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                final AlertDialog dialog = builder.create();
                dialog.show();

                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String userName = ((EditText)dialogView.findViewById(R.id.username_edittext)).getText().toString();

                        String text = "Se te ha enviado un correo con un enlace desde el que puedes cambiar tu contraseña.";

                        if(userName.isEmpty()) {
                            text = getString(R.string.error_username_empty_reset_password);
                            Toast toast = Toast.makeText(LoginActivity.this, text, Toast.LENGTH_LONG);
                            toast.show();
                        }else if(!SFBChecks.isValidEmail(userName)){
                            text = getString(R.string.error_username_incorrect_reset_password);
                            Toast toast = Toast.makeText(LoginActivity.this, text, Toast.LENGTH_LONG);
                            toast.show();
                        }else{
                            mResetPassTask = new ResetPasswordRequestTask(userName, LoginActivity.this);
                            mResetPassTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
                            dialog.dismiss();
                        }

                    }
                });
            }
        });
    }

    private void attemptLogin() {
        if (mAuthTask != null) {
            return;
        }
        View focusView = null;
        boolean cancel = false;


        String stringUsername = this.userName.getText().toString().trim();
        String pass = userPass.getText().toString().trim();

        if (stringUsername.length() <= 1) {
            if (stringUsername.isEmpty()) {
                this.userName.setError(getString(R.string.error_field_required));
            } else {
                this.userName.setError(getString(R.string.error_field_invalid));
            }
            focusView = this.userName;
            cancel = true;
        }

        else if(pass.length() <= 1){
            if (pass.isEmpty()) {
                userPass.setError(getString(R.string.error_field_required));
            } else {
                userPass.setError(getString(R.string.pass_too_short));
            }
            focusView = userPass;
            cancel = true;

        }
        if (cancel) {
            focusView.requestFocus();
        } else {
            mAuthTask = new UserLoginTask(stringUsername, pass, LoginActivity.this);
            mAuthTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
        }

    }


    public class UserLoginTask extends AsyncTask<Void, Void, Boolean> {

        LocalDataBaseHelper db;

        private final String mUserId;
        private final String mPassword;
        private final Context mContext;
        private Integer failCode;
        private ProgressDialog mProgressDialog;
        private final int CODE_NO_FAILS = 0;
        private final int CODE_INCORRECT_USER = 1;
        private final int CODE_ERROR_GETTING_USER = 3;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;

        UserLoginTask(String userId, String password, Context context) {
            mUserId = userId;
            mPassword = SFBEncode.encodeToMD5(password);
            mContext = context;
            failCode = CODE_NO_FAILS;

            db = new LocalDataBaseHelper(LoginActivity.this);

        }


        @Override
        protected Boolean doInBackground(Void... voids) {

            Boolean success = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();
            String fileXMLRequest = file.getAllDataRequest();//file.getAllDataRequest(mUserId); //SFBEncode.encodeToMD5(mUserId), token

            if (XMLHttpPost.isConnectedToInternet(LoginActivity.this)) {
                // SEND HTTP POST REQUEST
                String responseXML = null;

                try {
                    // INTRODUCE XML and return the server response
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, mContext,
                            SFBEncode.encodeStringBase64(mUserId + ":" + mPassword));

                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }

                try {
                    if(responseXML =="error"){
                        failCode = CODE_INCORRECT_USER;
                    }
                    else {
                        // Store user information received by the server in the app local files
                        saveUserDataInLocal(responseXML);
                        success = true;
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    failCode = CODE_ERROR_GETTING_USER;
                }

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }


            return success;
        }
        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog = new ProgressDialog(mContext);
                mProgressDialog.setMessage(getString(R.string.checking_user));
                mProgressDialog.setCancelable(false);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mAuthTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (success) {
                SessionData sessionData = SessionData.getSessionData(LoginActivity.this);
                String credentials = mUserId + ":" + mPassword;
                sessionData.setUserCredentials(credentials);
                Intent mainActivity = new Intent(mContext, MainActivity.class);
                startActivity(mainActivity);
                finish();
            } else {
                String errorMessage = "Error";
                switch (failCode) {
                    case CODE_ERROR_GETTING_USER:
                        errorMessage = getString(R.string.error_getting_user);
                        break;
                    case CODE_ERROR_INTERNET_CONNECTION:
                        errorMessage = getString(R.string.error_internet_connection);
                        break;
                    case CODE_INCORRECT_USER:
                        errorMessage = getString(R.string.error_user_not_exist);
                    default:
                        break;
                }
                Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                        .show();
            }
        }

        @Override
        protected void onCancelled() {
            mAuthTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void saveUserDataInLocal(String responseXML){

            RequestXMLReader readXMLRetrieveListDocumentSet = new RequestXMLReader(responseXML);

            SFBUser user = readXMLRetrieveListDocumentSet.getUserData();

            SFBPersonalData pd = user.getPersonalData();

            Integer clinicalGroupCode = readXMLRetrieveListDocumentSet.getClinicalGroup();
            String patientCode = readXMLRetrieveListDocumentSet.getPatientCode();

            SFBSmokingData sd = user.getSmokingData();


            SessionData sessionData = SessionData.getSessionData(LoginActivity.this);

            try {
                sessionData.setUserNick(pd.getName());
                sessionData.setGender(pd.getGender().toString());
                sessionData.setBirthDate(SFBDate.dateToString(pd.getBirthDate()));
                sessionData.setEmploymentStatus(pd.getEmploymentStatus());
                sessionData.setStartedSmokingDate(SFBDate.dateToString(sd.getDateStartingSmoking()));

                if(clinicalGroupCode == 1){ // Is a patient
                    sessionData.setPatientCode(patientCode);
                }else if(clinicalGroupCode == 2){ // Is not a patient
                    sessionData.setPatientCode(SessionData.NOT_HAVE_PATIENT_CODE);
                }
                // Else: unknown clinical group yet

            } catch (NullPointerException e) {
            }


            sessionData.setMuteNotifications(
                    Integer.parseInt(readXMLRetrieveListDocumentSet.getNotDisturbElection()));
            sessionData.setMuteNotificationsUntil(SFBDate.stringToCalendar(
                    readXMLRetrieveListDocumentSet.getDateNotDisturb().replaceAll(":","")
                            .replaceAll("-","").substring(0,12)));


            // TODO: Local language modification. Currently, it has bugs.
            /*
            String lang = readXMLRetrieveListDocumentSet.getLanguage();

            lang = lang.contains("Chinese")?"zh": "en";

            Locale myLocale = new Locale(lang);
            Resources res = getResources();
            DisplayMetrics dm = res.getDisplayMetrics();
            Configuration conf = res.getConfiguration();
            conf.locale = myLocale;
            res.updateConfiguration(conf, dm);
            sessionData.setLanguage(lang); */

            Calendar registerDate = SFBDate.stringToCalendar(
                    readXMLRetrieveListDocumentSet.getRegisterDate().replaceAll(":","")
                            .replaceAll("-","").substring(0,12));
            sessionData.setRegisterDate(SFBDate.dateToString(registerDate));
            db.insertMessageNotification(SFBNotification.getWelcomeNotification(registerDate, LoginActivity.this));


            try{
                List <SFBQuittingAttempt> quittingPeriodList = sd.getQuittingAttempts();
                if(!quittingPeriodList.isEmpty()){
                    for(SFBQuittingAttempt i : quittingPeriodList){
                        db.insertQuittingAttempt(i);
                    }
                    Boolean isInquittingPeriod = readXMLRetrieveListDocumentSet.getInQuittingAttempt();
                    if(isInquittingPeriod){

                        SFBQuittingAttempt quittingPeriod = db.selectLastQuittingAttempt();
                        sessionData.setFagerstromResult(quittingPeriod.getFagerstromTestResult());
                        sessionData.setRichmondResult(quittingPeriod.getRichmondTestResult());
                        sessionData.setPreviousDailyCigarettes(quittingPeriod.getPreviousDailyCigarettes());
                        sessionData.setWeeklyTobaccoExpenditure(quittingPeriod.getWeeklyTobaccoExpenditure());
                        sessionData.setCurrency(quittingPeriod.getCurrency());
                        sessionData.setQuittingDate(SFBDate.dateToString(quittingPeriod.getQuittingDate()));

                        SFBSmokingData smokingData;
                        smokingData = SessionData.getSessionData(mContext).getSmokingData(mContext);

                        ArrayList<SFBNotification> list = SFBNotification.createAchieveNotifications(smokingData, getApplicationContext());
                        Calendar now = Calendar.getInstance();
                        for (SFBNotification item : list) {
                            int achieved;
                            if (item.getSentDate().before(now)) {
                                //to received notification list
                                achieved = SFBConstantsAndCodes.BADGE_ACHIEVED;
                            } else {
                                //to alarmReceiver
                                achieved = SFBConstantsAndCodes.BADGE_NOT_ACHIEVED;
                                //AlarmReceiver.setAlarmNotification(getApplicationContext(), item, index);
                            }
                            db.createBadges(item.getType(), item.getText(), item.getIdDrawableCode(), achieved, item.getSentDate().getTimeInMillis());
                        }
                    }
                }

            }catch (NullPointerException e){
                e.printStackTrace();
            }

            if(sessionData.isQuittingDateFilled()){
                final String userId = sessionData.getUserId();
                final Calendar quittingDate = sessionData.getQuittingDate();

                SFBNotification quittingAttemptInfo = new SFBNotification(SFBConstantsAndCodes.NOTIFICATION_INTERNAL_BADGE,
                        userId,
                        String.format(getResources().getString(R.string.quitting_attempt_started_explanation),
                        sessionData.getUserNick()),
                        SFBConstantsAndCodes.NOTIFICATION_TYPE_INFORMATION, quittingDate);

                if(quittingDate.before(Calendar.getInstance())){

                    db.insertMessageNotification(quittingAttemptInfo);

                    Intent intent = new Intent(mContext, MainActivity.class);
                    intent.putExtra(MainActivity.SUBSECTION_KEY, TabsInitFragment.TAB_MESSAGES);


                    PendingIntent resultPendingIntent = PendingIntent.getActivity(mContext, 2, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                    NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(mContext)
                            .setContentText(getResources().getString(R.string.quitting_attempt_has_started))
                            .setContentTitle(getString(R.string.sfb_notification))
                            .setTicker(mContext.getString(R.string.sfb_server_notification))
                            .setContentIntent(resultPendingIntent)
                            .setAutoCancel(true);

                    if(Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT)
                        notificationBuilder.setSmallIcon(R.drawable.logo)
                                .setLargeIcon(ImageConversions.getBitmapFromDrawable(mContext, R.drawable.logo_min));
                    else
                        notificationBuilder.setSmallIcon(R.drawable.vector_logo)
                                .setLargeIcon(ImageConversions.getBitmapFromDrawable(mContext, R.drawable.logo));

                    NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
                    notificationManager.notify(1, notificationBuilder.build());

                    sessionData.setHasIntroducedActiveQuittingAttempDateInThisSession(true);
                }else {
                    quittingAttemptInfo.setText(getResources().getString(R.string.quitting_attempt_has_started));
                    AlarmReceiver.setAlarmNotification(getApplicationContext(), quittingAttemptInfo, "0");
                }
            }

            try{
                List<Boolean[]> extendedProfileFormQuestionResponseList =
                        readXMLRetrieveListDocumentSet.getExtendedProfileFormQuestionResponseList();
                createExtendedFormResponsesInDataBase(extendedProfileFormQuestionResponseList);
            }catch (NullPointerException e){
                e.printStackTrace();
            }

            String[] weekDaysPreferences = readXMLRetrieveListDocumentSet.getWeekDaysPreferences();

            sessionData.setWeekDaysPreferences(weekDaysPreferences);

            List<String[]> messages = readXMLRetrieveListDocumentSet.getMessages();

            try{
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                int messageTypeMotivational = SFBConstantsAndCodes.NOTIFICATION_TYPE_MOTIVATIONAL_MESSAGE_FROM_SERVER;

                for(String[] m : messages){
                    Date date = dateFormat.parse(m[4]);
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(date);
                    SFBNotification notification = new SFBNotification("SFBServer",
                            "SFBUser" , m[1], messageTypeMotivational, cal);

                    notification.setUserName(SessionData.getSessionData(getApplicationContext()).getUserNick());
                    notification.setPhotoUrl("none");
                    notification.setText(m[1]);
                    notification.setType(messageTypeMotivational);

                    db.insertMessageNotificationFromFCM(notification, m[0]);
                    if(!m[3].equals("null")) {
                        db.updateMessageNotification(m[0], m[2], m[3]);
                    }
                }
            }catch (NullPointerException | ArrayIndexOutOfBoundsException | ParseException e){
                e.printStackTrace();
            }
            sessionData.checkForPersonalDataComplete();
        }

        private void createExtendedFormResponsesInDataBase(List<Boolean[]> extendedProfileFormQuestionResponseList) {

            int tagReferenceID = 0;
            int numberOfAnswersReferencesID = 4;

            Resources resources = getResources();
            TypedArray extendedFormQuestionsReferences = resources.obtainTypedArray(R.array.extended_form_questions);

            int questionTagsID = extendedFormQuestionsReferences.getResourceId(tagReferenceID, 0);

            @SuppressWarnings("ResourceType") int questionNumberOfAnswersID = extendedFormQuestionsReferences.getResourceId(numberOfAnswersReferencesID, 0);
            if(questionTagsID > 0 && questionNumberOfAnswersID >0){
                String[] questionTags = resources.getStringArray(questionTagsID);
                final Boolean[] nullResponseFromServerDataBase = new Boolean[]{false, false,false, false};
                for(int i=0; i<questionTags.length; i++){
                    Boolean[] questionResponses = extendedProfileFormQuestionResponseList.get(i);
                    if(Arrays.equals(questionResponses, nullResponseFromServerDataBase)){
                        int[] questionNumberOfAnswers = resources.getIntArray(questionNumberOfAnswersID);
                        questionResponses = new Boolean[questionNumberOfAnswers[i]];
                        Arrays.fill(questionResponses, false);
                    }

                    db.insertExtendedFormQuestion(questionTags[i], questionResponses);
                }
            }
            extendedFormQuestionsReferences.recycle();
        }

    }

    /**
     * An {@link AsyncTask} to send to the server a recover-account request by reset the password.
     */
    public class ResetPasswordRequestTask extends AsyncTask<Void, Void, Boolean> {

        private final String mUsername;
        private final Context mContext;
        private Integer failCode;
        private ProgressDialog mProgressDialog;
        private final int CODE_NO_FAILS = 0;
        private final int CODE_ERROR_GETTING_USER = 3;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;

        ResetPasswordRequestTask(String userName, Context context) {
            mUsername = userName;
            mContext = context;
            failCode = CODE_NO_FAILS;
        }


        @Override
        protected Boolean doInBackground(Void... voids) {
            /**
             * create xml file
             * string xml request with user in md5
             *
             * check connectivity
             */

            Boolean userCreated = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();
            //String fileXMLRequest = file.getAllDataRequest(mUserId, SFBEncode.encodeToMD5(mPassword));//file.getAllDataRequest(mUserId); //SFBEncode.encodeToMD5(mUserId), token

            if (XMLHttpPost.isConnectedToInternet(LoginActivity.this)) {

                String fileXMLRequest = file.resetPasswordRequest(mUsername);

                // ENVIAR PETICIÓN HTTP POST
                String responseXML = null;

                try {
                    //Introduces XML y devuelve respuesta del servidor
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest,mContext, null);


                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }

                userCreated = responseXML == "created";
                if (!userCreated)
                    failCode = CODE_ERROR_GETTING_USER;

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }

            return userCreated;
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog = new ProgressDialog(mContext);
                mProgressDialog.setMessage(getString(R.string.checking_user));
                mProgressDialog.setCancelable(false);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mResetPassTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (success) {
                String text = getString(R.string.reset_password_email_sent);
                Toast toast = Toast.makeText(LoginActivity.this, text, Toast.LENGTH_LONG);
                toast.show();
            } else {
                String errorMessage = "Error";
                switch (failCode) {
                    case CODE_ERROR_GETTING_USER:
                        errorMessage = getString(R.string.error_email_not_is_an_username);
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    case CODE_ERROR_INTERNET_CONNECTION:
                        errorMessage = getString(R.string.error_internet_connection);
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    default:
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                }
            }
        }

        @Override
        protected void onCancelled() {
            mResetPassTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
