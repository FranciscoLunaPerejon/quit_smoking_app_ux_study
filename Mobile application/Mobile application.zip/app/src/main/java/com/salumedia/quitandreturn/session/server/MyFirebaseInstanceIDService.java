package com.salumedia.quitandreturn.session.server;

import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.SFBEncode;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;




public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {

    private static final String TAG = "MyFirebaseIIDService";

    /**
     * Called when the token ID is refreshed
     */
    @Override
    public void onTokenRefresh() {
        // Update InstanceID token.
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.d(TAG, "Refreshed token: " + refreshedToken);
        storeNewToken(refreshedToken);
    }

    /**
     * Save token in shared preferences
     *
     * Store token in shared preferences. It will be sent to server in future http communications
     *
     * @param token The new token.
     */
    private void storeNewToken(String token) {
        SessionData sessionData = SessionData.getSessionData(this);
        sessionData.setFCMToken(token);
        sessionData.setIsFirebaseTokenUpdatedInServer(false);

        boolean isHttpResponseCorrect = false;
        GenerateXMLFile file = GenerateXMLFile.getInstance();

        // Check if exists an internet connection
        if (XMLHttpPost.isConnectedToInternet(this)) {
            // SEND HTTP POST REQUEST
            String responseXML = null;

            // Specific xml request using the values
            String fileXMLRequest = file.updateToken();

            try {
                //Introduce XML and catch server response
                responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, this,
                        SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                this).getUserCredentials()) );
            } catch (CertificateException | NoSuchAlgorithmException | KeyManagementException | IOException | KeyStoreException e) {
                e.printStackTrace();
            }
            isHttpResponseCorrect = responseXML.equals("created");
        }

        if(isHttpResponseCorrect){
            sessionData.setIsFirebaseTokenUpdatedInServer(true);
        }
    }
}
