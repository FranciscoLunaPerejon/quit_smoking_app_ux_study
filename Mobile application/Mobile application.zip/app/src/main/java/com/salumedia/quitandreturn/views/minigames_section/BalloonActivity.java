package com.salumedia.quitandreturn.views.minigames_section;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBAppInteractionAnalytic;
import com.salumedia.quitandreturn.model.SFBMiniGameAnalytics;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.XMLHttpPost;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.SFBAnalytics;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBEncode;


import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

import ca.uol.aig.fftpack.RealDoubleFFT;

public class BalloonActivity extends AppCompatActivity {

    public String date;
    public String time;
    public Float init;

    public class BalloonResults {
        public int totalTime;
        public int restingTime;
        public int actionInterval;
        public int blownBalloon;
        public int poppedBalloon;
        public Date datetime;
        public String dateStr;
        public float bValue;
    }

    int mode;
    boolean gameFinished = false;

    // FFT process
    int frequency = 16000;
    int channelConfiguration = AudioFormat.CHANNEL_IN_MONO;
    int audioEncoding = AudioFormat.ENCODING_PCM_16BIT;
    int blockSize = 512;
    AudioRecord audioRecord = null;
    RecordAudio recordTask = null;
    private RealDoubleFFT transformer;
    ArrayList avgPowerArr = new ArrayList();
    double avgPowerArrSum = 0;
    boolean started = false;
    boolean CANCELLED_FLAG = false;
    boolean PAUSE_FLAG = true;

    // Balloon
    int BallonHeight = 100;
    int BallonWidth = 100;
    int ballonIntervalTime = 0;
    static android.view.ViewGroup.LayoutParams ballonLayoutParams;
    boolean nextShouldBlow = true;
    static boolean playedAudio = false;
    static boolean isBallonImg = true;

    // Game
    int totalTime = 60000;
    boolean debugMode = false;
    BalloonResults gameResults = new BalloonResults();
    RelativeLayout gameRelativeLayout;
    ImageView imageViewDisplaySpectrum;
    ImageView imageViewBallon;
    TextView magnitudetextView;
    TextView maxMagnitudetextView;
    TextView debugtextView;
    View finishContainerView;
    TextView finishTextView;
    TextView timeTextView;
    View resultsLayoutView;
    TextView popTextView;
    TextView blownTextView;
    Button backButton;
    View startContainerView;

    private sendBalloonGameResultsTask mSendBaloonGameResultsTask = null;

    public static final String section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_GAME_BLOW_BALLOONS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_balloon_blowing);

        // Get game parameter and adjust balloon interval time accordingly
        mode = 0; // 0: relax, 1:fast
        Bundle b = getIntent().getExtras();
        if(b != null) {
            mode = b.getInt("mode");
        }

        if (mode == 1) {
            ballonIntervalTime = 800;
        } else {
            ballonIntervalTime = 2000;
        }

        // Get widgets
        gameRelativeLayout = (RelativeLayout) findViewById(R.id.gameRelativeLayout);
        imageViewDisplaySpectrum = (ImageView) findViewById(R.id.imageViewDisplaySpectrum);
        imageViewBallon = (ImageView) findViewById(R.id.imageViewBallon);
        magnitudetextView = (TextView) findViewById(R.id.magnitudetextView);
        maxMagnitudetextView = (TextView) findViewById(R.id.maxMagnitudetextView);
        debugtextView = (TextView) findViewById(R.id.debugtextView);
        timeTextView = (TextView) findViewById(R.id.totalScoreTextView);
        finishContainerView = findViewById(R.id.finishContainerView);
        finishTextView = (TextView) findViewById(R.id.finishTextView);
        resultsLayoutView = findViewById(R.id.results_layout);
        popTextView = (TextView) findViewById(R.id.poppedTextView);
        blownTextView = (TextView) findViewById(R.id.blownTextView);
        backButton = (Button) findViewById(R.id.backButton);
        startContainerView = findViewById(R.id.startContainerView);

        startContainerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if (event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            startContainerView.setVisibility(View.GONE);

                            // Show debug text views
                            if (debugMode) {
                                imageViewDisplaySpectrum.setVisibility(View.VISIBLE);
                                magnitudetextView.setVisibility(View.VISIBLE);
                                maxMagnitudetextView.setVisibility(View.VISIBLE);
                                debugtextView.setVisibility(View.VISIBLE);
                            }

                            // Change balloon parameters
                            imageViewBallon.getLayoutParams().height = BallonHeight;
                            imageViewBallon.getLayoutParams().width  = BallonWidth;
                            imageViewBallon.requestLayout();

                            // Add click listeners to buttons
                            backButton.setOnClickListener(new View.OnClickListener() {
                                public void onClick(View v) {
                                    finish();
                                }
                            });

                            // Initialize game miniGameActivity
                            gameResults.totalTime = totalTime / 1000;
                            gameResults.restingTime = gameResults.totalTime;
                            gameResults.actionInterval = ballonIntervalTime;
                            gameResults.blownBalloon = 0;
                            gameResults.poppedBalloon = 0;
                            //SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                            Date date = new Date();
                            gameResults.datetime = date;
                            TimeZone tz = TimeZone.getTimeZone("UTC");
                            DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                            df.setTimeZone(tz);
                            gameResults.dateStr = df.format(date);

                            // Finish game after predefined time
                            new CountDownTimer(totalTime, 1000) {
                                public void onTick(long millisUntilFinished) {
                                    String timeText = getString(R.string.balloon_blowing_time) + millisUntilFinished / 1000;
                                    timeTextView.setText(timeText);
                                    totalTime = (int) (millisUntilFinished / 1000);
                                }

                                public void onFinish() {
                                    // Show game miniGameActivity
                                    String poppedStr = getString(R.string.balloon_blowing_exploited);
                                    String blownStr = getString(R.string.balloon_blowing_inflated);

                                    popTextView.setText(poppedStr + ": " + gameResults.poppedBalloon);
                                    blownTextView.setText(blownStr + ": " + gameResults.blownBalloon);

                                    // Set finish screen with appropriate visibility
                                    imageViewBallon.setVisibility(View.INVISIBLE);
                                    imageViewDisplaySpectrum.setVisibility(View.INVISIBLE);
                                    magnitudetextView.setVisibility(View.INVISIBLE);
                                    maxMagnitudetextView.setVisibility(View.INVISIBLE);
                                    debugtextView.setVisibility(View.INVISIBLE);
                                    timeTextView.setVisibility(View.INVISIBLE);
                                    finishContainerView.setVisibility(View.VISIBLE);
                                    finishTextView.setVisibility(View.VISIBLE);
                                    resultsLayoutView.setVisibility(View.VISIBLE);
                                    backButton.setVisibility(View.VISIBLE);

                                    gameFinished = true;

                                    // Send miniGameActivity
                                    sendBalloonGameResults(gameResults);
                                }

                            }.start();

                            /*
                            // Calculate total game time
                            new Timer().scheduleAtFixedRate(new TimerTask() {
                            @Override
                            public void run() {
                            totalTime++;
                            }
                            }, 0, 1000);
                            */

                            // Changing blowing to rest state at specified interval
                            new Timer().scheduleAtFixedRate(new TimerTask(){
                                @Override
                                public void run(){

                                    runOnUiThread(new Runnable() {
                                        public void run() {
                                            playedAudio = false;
                                            if (nextShouldBlow) {
                                                imageViewBallon.setImageResource(R.drawable.ballon_blowing_green);
                                                nextShouldBlow = false;
                                            } else {
                                                imageViewBallon.setImageResource(R.drawable.ballon_blowing);
                                                nextShouldBlow = true;
                                            }
                                        }
                                    });
                                }
                            },0 , ballonIntervalTime);

                            startAnalysis();

                        }
                    });
                }

                return true;
            }
        });


    }

    private class RecordAudio extends AsyncTask<Void, double[], Boolean> {

        @Override
        protected Boolean doInBackground(Void... params) {

            int bufferSize = AudioRecord.getMinBufferSize(frequency, channelConfiguration, audioEncoding);
            audioRecord = new AudioRecord(MediaRecorder.AudioSource.DEFAULT, frequency, channelConfiguration, audioEncoding, bufferSize);

            int bufferReadResult;
            short[] buffer = new short[blockSize];
            double[] toTransform = new double[blockSize];

            try {
                audioRecord.startRecording();
            } catch (IllegalStateException e) {
                Log.e("Recording failed", e.toString());
            }

            while (started) {

/*                if (!PAUSE_FLAG) {
                    bufferReadResult = audioRecord.read(buffer, 0, blockSize);
                    for (int i = 0; i < blockSize && i < bufferReadResult; i++) {
                        toTransform[i] = (double) buffer[i] / 32768.0; // signed 16 bit
                    }
                    transformer.ft(toTransform);
                    publishProgress(toTransform);
                }*/

               if (isCancelled() || (CANCELLED_FLAG)) {
                    started = false;
                    //publishProgress(cancelledResult);
                    Log.d("doInBackground", "Cancelling the RecordTask");
                    break;
                } else {
                    bufferReadResult = audioRecord.read(buffer, 0, blockSize);
                    for (int i = 0; i < blockSize && i < bufferReadResult; i++) {
                        toTransform[i] = (double) buffer[i] / 32768.0; // signed 16 bit
                    }
                    transformer.ft(toTransform);
                    publishProgress(toTransform);
                }
            }
            return true;
        }

        @Override
        protected void onProgressUpdate(double[]...progress) {

            double maxMagnitude = -999999;
            int maxMagnitudeIndex = -1;

            // First element of each array is frequency in Hz and the 2nd element is the amplitude
            double FFToutput[][] = new double [progress[0].length/2][2];
            int numberOfFrequenciesAboveThreshold = 0;

            for (int i = 0; i < progress[0].length; i+=2) {
                FFToutput[i/2][0] = ComputeFrequency(i/2);
                FFToutput[i/2][1] = Math.sqrt(progress[0][i]*progress[0][i] + progress[0][i+1]*progress[0][i+1]);

                if(FFToutput[i/2][1] > maxMagnitude) {
                    maxMagnitude = FFToutput[i/2][1];
                    maxMagnitudeIndex = i / 2;
                }

                if(FFToutput[i/2][1] > 1)
                    numberOfFrequenciesAboveThreshold++; // counts the number of frequencies that exceed a threshold
            }

            Bitmap tempBitmap = Bitmap.createBitmap(imageViewDisplaySpectrum.getWidth(), imageViewDisplaySpectrum.getHeight(), Bitmap.Config.ARGB_4444);
            tempBitmap.eraseColor(Color.TRANSPARENT);

            Canvas canvasDisplaySpectrum = new Canvas(tempBitmap);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setColor(Color.BLACK);

            int barwidth = imageViewDisplaySpectrum.getWidth() / FFToutput.length;

            ArrayList freqList = new ArrayList();
            double maxFreqList;
            double freqSum = 0;
            int freqSumFilter = 10;
            boolean isBlowing = false;

            for (int i = 0; i < FFToutput.length; i++) {
                int x = i * barwidth;
                int downy = (int) (150 - (FFToutput[i][1] * 10));
                int upy = 150;

                if (FFToutput[i][0] < 1000) {
                    freqList.add(FFToutput[i][1]);
                }

                canvasDisplaySpectrum.drawRect(x, downy, x + barwidth, upy, paint);
            }

            maxFreqList = (double) Collections.max(freqList);
            if (maxFreqList > 0) {
                for (int i = 0; i < freqList.size(); i++) {
                    freqList.set(i, (double) freqList.get(i) / maxFreqList);
                    freqSum = freqSum + (double) freqList.get(i);
                }
                freqSum = freqSum / freqList.size();

                // Construct and filter average power array
                avgPowerArr.add(freqSum);
                if (avgPowerArr.size() > freqSumFilter) {
                    avgPowerArr.remove(0);
                }
                for (int j = 0; j < avgPowerArr.size(); j++) {
                    avgPowerArrSum = avgPowerArrSum + (double) avgPowerArr.get(j);
                }
                avgPowerArrSum = avgPowerArrSum / avgPowerArr.size();

                debugtextView.setText("Av. power: " + new DecimalFormat("##.##").format(avgPowerArrSum));
            }

            imageViewDisplaySpectrum.setImageBitmap(tempBitmap);
            //imageViewDisplaySpectrum.draw(canvasDisplaySpectrum);

            /*
            for (int i = 0; i < progress[0].length; i+=2) {
                int x = i;
                int downy = (int) (150 - (progress[0][i] * 10));
                int upy = 150;

                if(progress[0][i]>maxMagnitude)
                {
                    maxMagnitude = progress[0][i];
                    maxMagnitudeIndex = i;
                }

                if(progress[0][i] > 1)
                    numberOfFrequenciesAboveThreshold++;    //counts the number of frequencies that exceed a threshold
                //canvasDisplaySpectrum.drawLine(x, downy, x, upy, paint);
            }
            */

            if((ComputeFrequency(maxMagnitudeIndex) > 0) && (maxMagnitude > 3)) {
                magnitudetextView.setText("Magnitude: " + ComputeFrequency(maxMagnitudeIndex) + " Hz");
                maxMagnitudetextView.setText("Max magnitude: " +  new DecimalFormat("##.##").format(maxMagnitude));
            }

            //if(numberOfFrequenciesAboveThreshold > 18)
            isBlowing = ((avgPowerArrSum > 0.4));

            ballonLayoutParams = imageViewBallon.getLayoutParams();

            if (!isBallonImg) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                imageViewBallon.setImageResource(R.drawable.ballon_blowing);
                ballonLayoutParams.width = 100;
                ballonLayoutParams.height = 100;
                imageViewBallon.setLayoutParams(ballonLayoutParams);
                isBallonImg = true;
            }

            if (isBlowing) {

                if (nextShouldBlow) {
                    ballonLayoutParams.width += 20;
                    ballonLayoutParams.height += 20;
                    imageViewBallon.setLayoutParams(ballonLayoutParams);
                    if ((ballonLayoutParams.width >= gameRelativeLayout.getWidth()) && (ballonLayoutParams.height >= gameRelativeLayout.getHeight())) {
                        if (!playedAudio) {
                            gameResults.poppedBalloon++;
                            MediaPlayer mPlayer = MediaPlayer.create(getApplicationContext(), R.raw.balloon_burst);
                            mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                            mPlayer.start();
                            imageViewBallon.setImageResource(R.drawable.pop_balloon_smoke);
                            isBallonImg = false;
                            //imageViewBallon.setImageResource(R.drawable.ballon_blowing);
                            playedAudio = true;
                            //cancel(true);
                        }
                    }
                } else {
                    ballonLayoutParams.width += 10;
                    ballonLayoutParams.height += 10;
                    imageViewBallon.setLayoutParams(ballonLayoutParams);
                    if ((ballonLayoutParams.width >= gameRelativeLayout.getWidth()) && (ballonLayoutParams.height >= gameRelativeLayout.getHeight())) {
                        gameResults.blownBalloon++;
                        imageViewBallon.setImageResource(R.drawable.ballon_success);
                        isBallonImg = false;
                    }
                }

            } else {
                if ((ballonLayoutParams.width >= BallonWidth) || (ballonLayoutParams.height >= BallonHeight)) {

                    if (!nextShouldBlow) {
                        ballonLayoutParams.width -= 9;
                        ballonLayoutParams.height -= 9;
                    } else {
                        ballonLayoutParams.width -= 3;
                        ballonLayoutParams.height -= 3;
                    }

                    imageViewBallon.setLayoutParams(ballonLayoutParams);
                }
            }
        }

        private double ComputeFrequency(double arrayIndex) {
            return arrayIndex * frequency / blockSize;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            super.onPostExecute(result);
            try {
                if (audioRecord != null) {
                    audioRecord.stop();
                }
            } catch(IllegalStateException e){
                Log.e("Stop failed", e.toString());
            }
        }

        @Override
        protected void onCancelled(Boolean result) {
            try {
                if (audioRecord != null) {
                    audioRecord.stop();
                }
            } catch(IllegalStateException e){
                Log.e("Stop failed", e.toString());
            }
        }

    }


    public void startAnalysis() {
        if (!started) {
            transformer = new RealDoubleFFT(blockSize);
            started = true;
            CANCELLED_FLAG = false;
            recordTask = new RecordAudio();
            recordTask.execute();
        }
    }

    public void stopAnalysis()
    {
        if (started) {
            //started = false;
            CANCELLED_FLAG = true;
            //recordTask.cancel(true);
            try{
                audioRecord.stop();
            }
            catch(IllegalStateException e){
                Log.e("Stop failed", e.toString());
            }
            //startStopButton.setText("Start");
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        // Initialize time parameters
        init = Long.valueOf(System.nanoTime()/1000000).floatValue();
        Calendar currentTime = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        date = sdf.format(currentTime.getTime());
        SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss.SSS");
        time = sdf2.format(currentTime.getTime());

        try{
            SFBAnalytics.startLogTimeInSection(section_name +
                    "_author:" +  SessionData.getSessionData(this).getUserData(this).getUserId() +
                    "_date:" + date + " " +  time);
        }catch (Exception e){
            SFBAnalytics.startLogTimeInSection(section_name + "_author:NOT_AVALIABLE" +
                    "_date:" + date + " " +  time);
        }
        SFBAnalytics.startLogTimeInSection(section_name);
    }
    @Override
    public void onPause() {
        super.onPause();
        Float fin = Long.valueOf(System.nanoTime()/1000000).floatValue();
        LocalDataBaseHelper db = new LocalDataBaseHelper(this);
        SFBAppInteractionAnalytic SFBAppInteractionAnalytic = new SFBAppInteractionAnalytic(section_name, date, time, (fin-init));
        db.insertAppInteraction(SFBAppInteractionAnalytic);
        try{
            SFBAnalytics.stopLogTimeInSection(section_name +
                    "_author:" + SessionData.getSessionData(this).getUserData(this).getUserId() +
                    "_date:" + date + " " +  time);

        }catch (Exception e){
            SFBAnalytics.stopLogTimeInSection(section_name + "_author:NOT_AVALIABLE" +
                    "_date:" + date + " " +  time);
        }        SFBAnalytics.stopLogTimeInSection(section_name);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (recordTask != null) {
            recordTask.cancel(true);
        }
        Float fin = Long.valueOf(System.nanoTime()/1000000).floatValue();
        LocalDataBaseHelper db = new LocalDataBaseHelper(this);
        SFBAppInteractionAnalytic SFBAppInteractionAnalytic = new SFBAppInteractionAnalytic(section_name, date, time, (fin-init));
        db.insertAppInteraction(SFBAppInteractionAnalytic);
        try{
            SFBAnalytics.stopLogTimeInSection(section_name +
                    "_author:" + SessionData.getSessionData(this).getUserData(this).getUserId() +
                    "_date:" + date + " " +  time);

        }catch (Exception e){
            SFBAnalytics.stopLogTimeInSection(section_name + "_author:NOT_AVALIABLE" +
                    "_date:" + date + " " +  time);
        }        SFBAnalytics.stopLogTimeInSection(section_name);
        SFBAnalytics.stopLogTimeInSection(section_name);

        sendBalloonGameResults(gameResults);
    }

    public void sendBalloonGameResults(BalloonResults results) {
        if (mSendBaloonGameResultsTask != null) {
            return;
        }
        mSendBaloonGameResultsTask = new sendBalloonGameResultsTask(BalloonActivity.this, results, mode);
        mSendBaloonGameResultsTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
    }

    public class sendBalloonGameResultsTask extends AsyncTask<Void, Void, Boolean>{

        private final int CODE_NO_FAILS = 0;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;
        private final int CODE_ERROR_NOT_STORED = 6;

        public Integer failCode;

        SFBMiniGameAnalytics miniGameActivity;
        Context context;

        public sendBalloonGameResultsTask(Context context, BalloonResults results, Integer mode) {
            this.context = context;

            String name = mode == 0 ? SFBMiniGameAnalytics.BLOW_BALLOON_NAME : SFBMiniGameAnalytics.BLOW_BALLOON_QUICKLY_NAME;
            Integer playingTime = gameFinished ? results.totalTime : results.totalTime - results.restingTime;

            this.miniGameActivity = new SFBMiniGameAnalytics(name, date, time, results.blownBalloon, results.poppedBalloon, playingTime);

            failCode = CODE_NO_FAILS;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {

            Boolean everythingCorrect = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();

            if (XMLHttpPost.isConnectedToInternet(BalloonActivity.this)) {

                String responseXML = null;

                ArrayList<SFBMiniGameAnalytics> list = new ArrayList<>();
                list.add(miniGameActivity);

                String fileXMLRequest = file.addMiniGameActivity(list);

                try {
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, context,
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    context).getUserCredentials()));
                } catch (CertificateException | NoSuchAlgorithmException | KeyManagementException | IOException | KeyStoreException e) {
                    e.printStackTrace();
                }
                everythingCorrect = responseXML == "created";
                if (!everythingCorrect)
                    failCode = CODE_ERROR_NOT_STORED;

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }


            return everythingCorrect;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mSendBaloonGameResultsTask = null;
            //fragmentReference.refreshUI(0);
            super.onPostExecute(success);
            //goBack();
            if (success) {
                Log.d("SFBSENT", "Success ok onPostExecute");
                //SFBPreferences.getPreferences(context).setEncourageMessageResponseWithSuccess(SFBConstants.ENCOURAGE_MESSAGE_SENT);
            } else {
                LocalDataBaseHelper db = new LocalDataBaseHelper(context);
                db.insertMiniGameActivity(miniGameActivity);
            }
        }

        @Override
        protected void onCancelled() {
            mSendBaloonGameResultsTask = null;
            super.onCancelled();
        }
    }


}
