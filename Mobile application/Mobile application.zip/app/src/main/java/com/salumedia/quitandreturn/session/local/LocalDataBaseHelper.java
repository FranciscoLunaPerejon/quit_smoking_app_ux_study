package com.salumedia.quitandreturn.session.local;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.salumedia.quitandreturn.model.SFBAppInteractionAnalytic;
import com.salumedia.quitandreturn.model.SFBMessageInteractionAnalytic;
import com.salumedia.quitandreturn.model.SFBMiniGameAnalytics;
import com.salumedia.quitandreturn.model.SFBNotification;
import com.salumedia.quitandreturn.model.SFBQuittingAttempt;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBDate;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by Francisco on 29/12/16.
 */

/**
 * Local database tables and methods to store and get information
 */

public class LocalDataBaseHelper extends SQLiteOpenHelper {

    //SQL RESOURCE

    private final String SELECT_ALL_FROM = "SELECT * FROM ";

    private Context context;

    //DataBase
    public static final int DATABASE_VERSION = 3;
    public static final String DATABASE_NAME = "TestDB.db";

    private static final String TABLE_QUITTING_ATTEMPTS = "QuittingPeriods";
    private static final String TABLE_MESSAGE_NOTIFICATIONS = "Notifications";
    private static final String TABLE_BADGES = "Badges";
    private static final String TABLE_MESSAGE_INTERACTIONS = "MessageInteractions";
    private static final String TABLE_USER_BEHAVIOUR = "UserBehaviour";
    private static final String TABLE_EXTENDED_FORM_QUESTIONS_RESPONSES = "ExtendedFormQuestionsResponses";
    private static final String TABLE_MINI_GAMES_ACTIVITY = "MiniGamesActivity";

    private static final String FIELD_ID_CODE = "idCode";

    private static final String FIELD_MESSAGE = "message";

    private static final String FIELD_START = "startDate";
    private static final String FIELD_END = "endDate";
    private static final String FIELD_DAILY_CIGARETTES = "dailyCigarettes";
    private static final String FIELD_WEEKLY_EXPENDITURE = "weeklyExpenditure";
    private static final String FIELD_CURRENCY = "currency";
    private static final String FIELD_FAGERSTROM_RESULT = "fagerstromResult";
    private static final String FIELD_RICHMOND_RESULT = "richmondResult";

    private static final String FIELD_DATE = "day";
    private static final String FIELD_USER_NAME = "userName";
    private static final String FIELD_PHOTO_URL = "photoUrl";
    private static final String FIELD_IS_READ = "isRead";
    private static final String FIELD_IS_FAVORITE = "isFavorite";
    private static final String FIELD_SERVER_ID = "serverId";
    private static final String FIELD_NOTIFICATION_SENDER_ID = "senderId";
    private static final String FIELD_NOTIFICATION_RECEIVER_ID = "receiverId";
    private static final String FIELD_NOTIFICATION_TYPE = "messageType";

    private static final String FIELD_BADGE_TYPE = "badgeType";
    private static final String FIELD_BADGE_ACHIEVED = "badgeAchieved";
    private static final String FIELD_BADGE_TIME_IN_MILLIS = "badgeTimeMillis";

    private static final String FIELD_TIME = "readTime";
    private static final String FIELD_SECONDS_LECTURE = "secondsLecture";
    private static final String FIELD_SECONDS_TO_READ = "minutesToRead";
    private static final String FIELD_RATING = "vote";

    private static final String FIELD_SECTION = "section";
    private static final String FIELD_MILLISECONDS_INSIDE = "millisecondsInside";

    private static final String FIELD_QUESTION_TAG = "questionTag";
    private static final String FIELD_QUESTION_RESPONSES = "questionResponses";

    private static final String FIELD_MINI_GAME_NAME = "miniGameName";
    private static final String FIELD_SCORE = "score";
    private static final String FIELD_PENALTIES = "penalties";
    private static final String FIELD_PLAYING_TIME = "playingTime";


    private static final String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS ";

    private String sqlCreateQuittingAttemptTable = CREATE_TABLE + TABLE_QUITTING_ATTEMPTS + " (" +
            FIELD_ID_CODE + " INTEGER, " +
            FIELD_START + " DATE, " +
            FIELD_END + " DATE, " +
            FIELD_DAILY_CIGARETTES + " REAL, " +
            FIELD_WEEKLY_EXPENDITURE + " REAL, " +
            FIELD_CURRENCY + " TEXT, " +
            FIELD_FAGERSTROM_RESULT + " INTEGER, " +
            FIELD_RICHMOND_RESULT + " INTEGER)";

    private String sqlCreateNotificationsTable = CREATE_TABLE + TABLE_MESSAGE_NOTIFICATIONS + " (" +
            FIELD_NOTIFICATION_SENDER_ID + " TEXT, " +
            FIELD_NOTIFICATION_RECEIVER_ID + " TEXT, " +
            FIELD_SERVER_ID + " TEXT, " +
            FIELD_MESSAGE + " TEXT, " +
            FIELD_NOTIFICATION_TYPE + " TEXT, " +
            FIELD_DATE + " DATE, " +
            FIELD_USER_NAME + " TEXT, " +
            FIELD_IS_READ + " INTEGER, " +
            FIELD_IS_FAVORITE + " INTEGER, " +
            FIELD_RATING + " TEXT,  " +
            FIELD_PHOTO_URL + " TEXT)";

    private String sqlCreateBadgesTable = CREATE_TABLE + TABLE_BADGES + " (" +
            FIELD_ID_CODE + " INTEGER, " +
            FIELD_BADGE_TYPE + " INTEGER, " +
            FIELD_BADGE_ACHIEVED + " INTEGER, " +
            FIELD_BADGE_TIME_IN_MILLIS + " TEXT, " +
            FIELD_MESSAGE + " TEXT)";


    private String sqlCreateMessagesInteractionsToSendTable = CREATE_TABLE + TABLE_MESSAGE_INTERACTIONS + " (" +
            FIELD_SERVER_ID + " TEXT, " +
            FIELD_NOTIFICATION_TYPE + " TEXT, " + //This column maybe can be useful in future implementations
            FIELD_DATE + " DATE, " +
            FIELD_TIME + " TEXT, " +
            FIELD_SECONDS_LECTURE + " INTEGER, " +
            FIELD_SECONDS_TO_READ + " INTEGER, " +
            FIELD_IS_READ + " INTEGER, " + //This column maybe can be useful in future implementations
            FIELD_IS_FAVORITE + " INTEGER, " +
            FIELD_RATING + " TEXT)";


    private String sqlCreateUserBehaviourTable = CREATE_TABLE + TABLE_USER_BEHAVIOUR + " (" +
            FIELD_SECTION + " TEXT, " +
            FIELD_DATE + " DATE, " +
            FIELD_TIME + " TEXT, " +
            FIELD_MILLISECONDS_INSIDE + " INTEGER)";

    private String sqlCreateExtendedFormResponsesTable = CREATE_TABLE + TABLE_EXTENDED_FORM_QUESTIONS_RESPONSES + " (" +
            FIELD_QUESTION_TAG + " TEXT, " +
            FIELD_QUESTION_RESPONSES + " TEXT)";

    private String sqlCreateMiniGameActivityTable = CREATE_TABLE + TABLE_MINI_GAMES_ACTIVITY + " (" +
            FIELD_MINI_GAME_NAME + " TEXT, " +
            FIELD_SCORE + " INTEGER, " +
            FIELD_PENALTIES + " INTEGER, " +
            FIELD_PLAYING_TIME + " INTEGER, " +
            FIELD_DATE + " DATE, " +
            FIELD_TIME + " TIME)";

    //Constructor
    public LocalDataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(sqlCreateQuittingAttemptTable);
        db.execSQL(sqlCreateNotificationsTable);
        db.execSQL(sqlCreateBadgesTable);
        db.execSQL(sqlCreateMessagesInteractionsToSendTable);
        db.execSQL(sqlCreateUserBehaviourTable);
        db.execSQL(sqlCreateExtendedFormResponsesTable);
        db.execSQL(sqlCreateMiniGameActivityTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        switch(oldVersion) {
            case 2:
                deleteMiniGamesActivity();
                break;
            case 1:
                db.execSQL(sqlCreateMiniGameActivityTable);
            default:
                break;
        }

    }


    // QUITTING ATTEMPT TABLE OPERATIONS

    public void insertQuittingAttempt(SFBQuittingAttempt quittingAttempt){
        ContentValues values = new ContentValues();
        //TODO for future versions, it may possible add the quitting attempt end date
        values.put(FIELD_ID_CODE, nextQuittingAttemptId());
        values.put(FIELD_START, SFBDate.dateToString(quittingAttempt.getQuittingDate()));
        values.put(FIELD_DAILY_CIGARETTES, quittingAttempt.getPreviousDailyCigarettes());
        values.put(FIELD_WEEKLY_EXPENDITURE, quittingAttempt.getWeeklyTobaccoExpenditure());
        values.put(FIELD_CURRENCY, quittingAttempt.getCurrency());
        values.put(FIELD_FAGERSTROM_RESULT, quittingAttempt.getFagerstromTestResult());
        values.put(FIELD_RICHMOND_RESULT, quittingAttempt.getRichmondTestResult());
        insertData(TABLE_QUITTING_ATTEMPTS, values);

    }

    public SFBQuittingAttempt selectLastQuittingAttempt() {
        Cursor cursor;
        SFBQuittingAttempt qp = null;

        SQLiteDatabase database = getReadableDatabase();
        String query = SELECT_ALL_FROM + TABLE_QUITTING_ATTEMPTS + " ORDER BY " + FIELD_ID_CODE + " DESC LIMIT 1";

        cursor = database.rawQuery(query, null);

        try {

            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                Calendar startQuittingAttempt = SFBDate.stringToCalendar(cursor.getString(1));
                Calendar endQuittingAttempt = SFBDate.stringToCalendar(cursor.getString(2));
                Float dailyCigarettes = cursor.getFloat(3);
                Float weeklyExpenditure = cursor.getFloat(4);
                String currency = cursor.getString(5);
                Integer fagerstromResult = cursor.getInt(6);
                Integer richmondResult = cursor.getInt(7);
                qp = SFBQuittingAttempt.getInstance(dailyCigarettes, weeklyExpenditure, currency,
                        startQuittingAttempt, endQuittingAttempt, fagerstromResult, richmondResult);
            }
        }finally {
            if (cursor != null && !cursor.isClosed())
                cursor.close();
        }
            return qp;
    }

    private int nextQuittingAttemptId(){
        Cursor cursor = getCursorSelectAll(TABLE_QUITTING_ATTEMPTS);
        int res;
        try {
            res = cursor.getCount();
        }finally {
            if (cursor != null && !cursor.isClosed())
                cursor.close();
        }
        return res;
    }


    // MESSAGE NOTIFICATION TABLE OPERATIONS

    public void insertMessageNotification(SFBNotification notification) {
        ContentValues values = new ContentValues();

        values.put(FIELD_NOTIFICATION_SENDER_ID, notification.getSenderId());
        values.put(FIELD_NOTIFICATION_RECEIVER_ID, notification.getReceivedId());
        values.put(FIELD_MESSAGE, notification.getText());
        values.put(FIELD_NOTIFICATION_TYPE, notification.getType());
        values.put(FIELD_DATE, SFBDate.dateToString(notification.getSentDate()));
        values.put(FIELD_USER_NAME, notification.getUserName());
        //values.put(FIELD_PHOTO_URL, notification.getPhotoUrl());

        values.put(FIELD_SERVER_ID, "0");
        values.put(FIELD_RATING, "0");
        values.put(FIELD_IS_FAVORITE, "0");
        values.put(FIELD_IS_READ, "0");
        insertData(TABLE_MESSAGE_NOTIFICATIONS, values);
    }

    public void insertMessageNotificationFromFCM(SFBNotification notification, String serverId){
        ContentValues values = new ContentValues();

        values.put(FIELD_NOTIFICATION_SENDER_ID, notification.getSenderId());
        values.put(FIELD_NOTIFICATION_RECEIVER_ID, notification.getReceivedId());
        values.put(FIELD_MESSAGE, notification.getText());
        values.put(FIELD_NOTIFICATION_TYPE, notification.getType());
        values.put(FIELD_DATE, SFBDate.timestampToString(notification.getSentDate()));
        values.put(FIELD_USER_NAME, notification.getUserName());
        values.put(FIELD_SERVER_ID, serverId);
        values.put(FIELD_RATING, "0");
        values.put(FIELD_IS_FAVORITE, "0");
        values.put(FIELD_IS_READ, "0");
        insertData(TABLE_MESSAGE_NOTIFICATIONS, values);
    }

    public ArrayList<SFBNotification> selectMessageNotifications() {
        Cursor cursor = getCursorSelectAll(TABLE_MESSAGE_NOTIFICATIONS);

        return getMessageNotificationWithCursor(cursor);
    }


    public String getMessageNotificationRating(String idServer){
        SQLiteDatabase database = getReadableDatabase();
        String query = "SELECT " + FIELD_RATING +" FROM " + TABLE_MESSAGE_NOTIFICATIONS + " WHERE " + FIELD_SERVER_ID + " = " + idServer;
        Cursor cursor = database.rawQuery(query, null);

        String res = "-1";

        try{
            if(cursor.moveToNext()){
                res = cursor.getString(0);
            }
        }finally {
            if (cursor != null && !cursor.isClosed())
                cursor.close();
        }
        return res;
    }

    public void updateMessageNotification(String serverId, String read, String vote){
        SQLiteDatabase database = getWritableDatabase();

        try {
            ContentValues values = new ContentValues();
            values.put(FIELD_IS_FAVORITE, "0");
            values.put(FIELD_IS_READ, read != null ? read : "0");
            values.put(FIELD_RATING, vote);
            database.update(TABLE_MESSAGE_NOTIFICATIONS, values, FIELD_SERVER_ID + "=?", new String[]{serverId});

        }finally {
            if(database !=null && database.isOpen())
                database.close();

        }
    }

    public void markMessageNotificationUnread(String serverId){
        SQLiteDatabase database = getWritableDatabase();
        try{
            ContentValues values = new ContentValues();
            values.put(FIELD_IS_READ, "0");
            database.update(TABLE_MESSAGE_NOTIFICATIONS, values, FIELD_SERVER_ID + "=?", new String[]{serverId});
        }finally {
            if(database !=null && database.isOpen())
                database.close();
        }
    }

    // Auxiliary methods for message notifications table

    private ArrayList<SFBNotification> getMessageNotificationWithCursor(Cursor cursor){
        ArrayList<SFBNotification> list = new ArrayList<>();

        try {
            while (cursor.moveToNext()) {
                String senderID = cursor.getString(0);
                String receiverID = cursor.getString(1);
                String serverID = cursor.getString(2);
                String text = cursor.getString(3);
                Integer type = cursor.getInt(4);
                Calendar sentDate = SFBDate.stringToCalendar(cursor.getString(5));
                String userName = cursor.getString(6);
                String photoUrl = cursor.getString(9);

                SFBNotification notification = new SFBNotification(
                        senderID,
                        receiverID,
                        text,
                        type,
                        sentDate);

                notification.setIdServer(serverID);
                notification.setUserName(userName);
                notification.setPhotoUrl(photoUrl);
                int isRead;
                int isFavorite;
                try {
                    isRead = cursor.getInt(7);
                } catch (Exception e) {
                    isRead = 0;
                }
                notification.setRead(isRead != 0);
                try {
                    isFavorite = cursor.getInt(8);
                } catch (Exception e) {
                    isFavorite = 0;
                }
                notification.setFavorite(isFavorite != 0);
                notification.setId(cursor.getPosition() + "");
                list.add(notification);
            }
            Collections.reverse(list);
        }finally {
            if(cursor!= null && !cursor.isClosed())
                cursor.close();
        }

        return list;
    }


    // BADGES TABLE OPERATIONS

    public void createBadges(int badgeType, String message, int drawableCode, int achieved, long timeInMillis) {
        ContentValues values = new ContentValues();
        values.put(FIELD_ID_CODE, drawableCode);
        values.put(FIELD_BADGE_TYPE, badgeType);
        values.put(FIELD_MESSAGE, message);
        values.put(FIELD_BADGE_ACHIEVED, achieved);
        values.put(FIELD_BADGE_TIME_IN_MILLIS, String.valueOf(timeInMillis));
        String[] args = new String[]{String.valueOf(badgeType)};
        updateData(TABLE_BADGES, values, FIELD_ID_CODE, args);
    }

    public ArrayList<SFBNotification> selectBadgesByType(int badgeTye) {
        SQLiteDatabase database = getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_BADGES + " WHERE " + FIELD_BADGE_TYPE + " = " + String.valueOf(badgeTye);

        ArrayList<SFBNotification> list = new ArrayList<>();

        Cursor cursor = database.rawQuery(query, null);

        try {
            while (cursor.moveToNext()) {
                long timeInMillis = Long.parseLong(cursor.getString(3));
                Calendar calendar = Calendar.getInstance();
                calendar.setTimeInMillis(timeInMillis);
                String text = cursor.getString(4);
                Integer type = cursor.getInt(1);
                SFBNotification notification = new SFBNotification(SFBConstantsAndCodes.NOTIFICATION_INTERNAL_BADGE, "user", text, type, calendar);
                notification.setAchieved(cursor.getInt(2));
                notification.setIdDrawableCode(cursor.getInt(0));
                list.add(notification);
            }
        }finally {
            if(cursor != null && !cursor.isClosed())
                cursor.close();
        }
        return list;
    }

    public void updateBadges(String message, int drawableCode){
        ContentValues values = new ContentValues();
        values.put(FIELD_ID_CODE, drawableCode);
        values.put(FIELD_MESSAGE, message);
        String[] args = new String[]{String.valueOf(drawableCode)};
        SQLiteDatabase database = getWritableDatabase();

        try {
            database.update(TABLE_BADGES, values, FIELD_ID_CODE + "=?", args);
        }finally {
            if(database != null && database.isOpen())
                database.close();
        }
    }

    public void deleteBadges() {
        deleteTable(TABLE_BADGES);
        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sqlCreateBadgesTable);
    }




    // MESSAGE INTERACTION TABLE OPERATIONS

    public void insertMessageInteractionToSend(SFBMessageInteractionAnalytic SFBMessageInteractionAnalytic){
        ContentValues values = new ContentValues();
        values.put(FIELD_SERVER_ID, SFBMessageInteractionAnalytic.getIdServer());
        values.put(FIELD_NOTIFICATION_TYPE, "Vote"); //This column maybe can be useful in future implementations
        values.put(FIELD_DATE, SFBMessageInteractionAnalytic.getDate());
        values.put(FIELD_TIME, SFBMessageInteractionAnalytic.getTimeStartRead());
        values.put(FIELD_SECONDS_LECTURE, SFBMessageInteractionAnalytic.getSecondsLecture());
        values.put(FIELD_SECONDS_TO_READ, SFBMessageInteractionAnalytic.getSecondsToRead());
        values.put(FIELD_IS_READ, "1"); //This column maybe can be useful in future implementations
        values.put(FIELD_IS_FAVORITE, SFBMessageInteractionAnalytic.getFavorite());
        values.put(FIELD_RATING, SFBMessageInteractionAnalytic.getVote());
        insertData(TABLE_MESSAGE_INTERACTIONS, values);
    }

    public ArrayList<SFBMessageInteractionAnalytic> selectMessagesInteractionsToSend(){
        ArrayList<SFBMessageInteractionAnalytic> res = new ArrayList<>();
        Cursor cursor = getCursorSelectAll(TABLE_MESSAGE_INTERACTIONS);
        try {
            while (cursor.moveToNext()) {
                String idServer = cursor.getString(0);
                String date = cursor.getString(2);
                String timeStart = cursor.getString(3);
                Float secondsLecture = cursor.getFloat(4);
                String timeToStart = cursor.getString(5);
                String favorite = cursor.getString(7);
                String vote = cursor.getString(8);

                SFBMessageInteractionAnalytic SFBMessageInteractionAnalytic = new SFBMessageInteractionAnalytic(
                        idServer,
                        date,
                        timeStart,
                        secondsLecture,
                        timeToStart,
                        vote,
                        favorite);

                res.add(SFBMessageInteractionAnalytic);

                Collections.reverse(res);
            }
        }finally {
            if(cursor != null && !cursor.isClosed())
                cursor.close();
        }

        return res;
    }

    public void deleteMessageInteractionsToSend(){
        deleteTable(TABLE_MESSAGE_INTERACTIONS);
        SQLiteDatabase database = getWritableDatabase();
        try {
            database.execSQL(sqlCreateMessagesInteractionsToSendTable);
        }finally {
            if(database != null && database.isOpen())
                database.close();
        }
    }


    // APP INTERACTION TABLE OPERATIONS

    public void insertAppInteraction(SFBAppInteractionAnalytic SFBAppInteractionAnalytic){
        ContentValues values = new ContentValues();
        values.put(FIELD_SECTION, SFBAppInteractionAnalytic.getTagName());
        values.put(FIELD_DATE, SFBAppInteractionAnalytic.getDate());
        values.put(FIELD_TIME, SFBAppInteractionAnalytic.getTime());
        values.put(FIELD_MILLISECONDS_INSIDE, SFBAppInteractionAnalytic.getMilliSecondsDuration());
        insertData(TABLE_USER_BEHAVIOUR, values);
    }

    public ArrayList<SFBAppInteractionAnalytic> selectAppInteractions(){

        ArrayList<SFBAppInteractionAnalytic> SFBAppInteractionAnalytics = new ArrayList<>();
        Cursor cursor = getCursorSelectAll(TABLE_USER_BEHAVIOUR);
        try {

            while (cursor.moveToNext()){
                String tagName = cursor.getString(0);
                String date = cursor.getString(1);
                String time = cursor.getString(2);
                Float duration = cursor.getFloat(3);
                SFBAppInteractionAnalytic SFBAppInteractionAnalytic = new SFBAppInteractionAnalytic(tagName, date, time, duration);
                SFBAppInteractionAnalytics.add(SFBAppInteractionAnalytic);
                Collections.reverse(SFBAppInteractionAnalytics);
            }
        }finally {
            if(cursor != null && !cursor.isClosed())
                cursor.close();
        }
        return SFBAppInteractionAnalytics;
    }

    public void deleteAppInteractions(){
        deleteTable(TABLE_USER_BEHAVIOUR);
        SQLiteDatabase database = getWritableDatabase();
        try {
            database.execSQL(sqlCreateUserBehaviourTable);
        }finally {
           if(database!= null && database.isOpen())
                database.close();
        }
    }

    // EXTENDED FORM TABLE OPERATIONS

    public void insertExtendedFormQuestion(String tag, Boolean[] questionResponses){
        ContentValues values = new ContentValues();
        values.put(FIELD_QUESTION_TAG, tag);
        String stringQuestionResponses = "";
        for(Boolean questionResponse : questionResponses){
            stringQuestionResponses += questionResponse?"1":"0"; // concat 1 (true) and 0 (false)
        }

        values.put(FIELD_QUESTION_RESPONSES, stringQuestionResponses);
        insertData(TABLE_EXTENDED_FORM_QUESTIONS_RESPONSES, values);
    }

    public Map<String, Boolean[]> getAllExtendedFormResponses(){
        Map<String, Boolean[]> extendedFormResponses = new HashMap<>();
        Cursor cursor = getCursorSelectAll(TABLE_EXTENDED_FORM_QUESTIONS_RESPONSES);

        try {
            while (cursor.moveToNext()){
                String tagQuestion = cursor.getString(0);
                String stringQuestionResponses = cursor.getString(1);
                Boolean[] questionResponses = new Boolean[stringQuestionResponses.length()];
                for(int i = 0; i<stringQuestionResponses.length();i++){
                    questionResponses[i] = stringQuestionResponses.charAt(i) == '1';
                }
                extendedFormResponses.put(tagQuestion,questionResponses);
            }
        } finally {
            if(cursor != null && !cursor.isClosed())
                cursor.close();
        }
        return extendedFormResponses;
    }

    public void updateExtendedFormQuestionAnswer(String tag, Boolean[] questionResponses){
        ContentValues values = new ContentValues();
        String stringQuestionResponses = "";
        for(Boolean questionResponse : questionResponses){
            stringQuestionResponses += questionResponse?"1":"0"; // concat 1 (true) and 0 (false)
        }

        values.put(FIELD_QUESTION_RESPONSES, stringQuestionResponses);
        String[] args = new String[]{tag};

        SQLiteDatabase database = getWritableDatabase();
        try {
            database.update(TABLE_EXTENDED_FORM_QUESTIONS_RESPONSES, values, FIELD_QUESTION_TAG + "=?", args);
        }finally {
            if(database != null && database.isOpen())
                database.close();
        }
    }

    // MINI GAMES ACTIVITY TABLE OPERATIONS

    public void insertMiniGameActivity(SFBMiniGameAnalytics miniGameActivity){
        ContentValues values = new ContentValues();
        values.put(FIELD_MINI_GAME_NAME, miniGameActivity.getName());
        values.put(FIELD_SCORE, miniGameActivity.getScore());
        if(!miniGameActivity.getName().equals(SFBMiniGameAnalytics.WHACK_A_MOLE_NAME)){
            values.put(FIELD_PENALTIES, miniGameActivity.getPenalties());
        }
        values.put(FIELD_DATE, miniGameActivity.getDate());
        values.put(FIELD_TIME, miniGameActivity.getTime());
        values.put(FIELD_PLAYING_TIME, miniGameActivity.getPlayingTime());

        insertData(TABLE_MINI_GAMES_ACTIVITY, values);
    }

    public ArrayList<SFBMiniGameAnalytics> selectMiniGameActivities(){

        ArrayList<SFBMiniGameAnalytics> miniGameActivities = new ArrayList<>();
        Cursor cursor = getCursorSelectAll(TABLE_MINI_GAMES_ACTIVITY);
        while (cursor.moveToNext()){
            String name = cursor.getString(0);
            Integer score = cursor.getInt(1);
            String date = cursor.getString(3);
            String time = cursor.getString(4);
            Integer playingTime = cursor.getInt(5);

            SFBMiniGameAnalytics miniGameActivity;
            if(name.equals(SFBMiniGameAnalytics.WHACK_A_MOLE_NAME)){
                miniGameActivity = new SFBMiniGameAnalytics(name, date, time, score, playingTime);

            }else{
                Integer penalties = cursor.getInt(2);
                miniGameActivity = new SFBMiniGameAnalytics(name, date, time, score, penalties, playingTime);
            }
            miniGameActivities.add(miniGameActivity);
        }

        cursor.close();
        Collections.reverse(miniGameActivities);
        return miniGameActivities;
    }

    public void deleteMiniGamesActivity(){
        deleteTable(TABLE_MINI_GAMES_ACTIVITY);
        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sqlCreateMiniGameActivityTable);
    }

    // GENERIC AUXILIARY OPERATIONS

    private void insertData(String table, ContentValues values) {
        SQLiteDatabase database = getWritableDatabase();
        try {
            database.insert(table, null, values);

        }finally {
            if(database != null && database.isOpen())
                database.close();
        }
    }

    private Cursor getCursorSelectAll(String table) {
        SQLiteDatabase database = getReadableDatabase();
        String query = SELECT_ALL_FROM + table;

        return database.rawQuery(query, null);
    }

    private void updateData(String table, ContentValues values, String whereClause, String args[]) {
        SQLiteDatabase database = getWritableDatabase();
        try {
            database.insert(table, null, values);
            database.update(table, values, whereClause + "=?", args);
        } finally {
            if(database != null && database.isOpen())
                database.close();
        }

    }

    private void deleteTable(String tableName) {
        SQLiteDatabase database = getWritableDatabase();

        try {
            database.execSQL("DROP TABLE " + tableName);

        }finally {
            if(database != null && database.isOpen())
                database.close();
        }
    }


}
