package com.salumedia.quitandreturn.views.minigames_section;

import android.content.Context;
import android.os.Handler;
import android.support.v7.widget.AppCompatImageView;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.RelativeLayout;


import com.salumedia.quitandreturn.R;

import java.util.Random;

/**
 * Created by evdokimosk on 6/28/2016.
 */
public class MoleImageView extends AppCompatImageView {
    public enum MoleStatus {
        OFF,
        ON,
        PUSHED
    }

    MoleStatus moleStatus = MoleStatus.ON;
    RelativeLayout gameRelativeLayout;
    Handler handler = new Handler();

    int ShowMoleTime = 2000;

    int molesClickedTimes = 0;


    public interface OnMoleClickedListener {
        public void OnMoleClicked(int molesClickedTimes);
    }

    private OnMoleClickedListener listenerMoleClicked = null;

    public void setOnMoleClickedListener(OnMoleClickedListener listener) {
        this.listenerMoleClicked = listener;
    }


    /**
     * @param context
     */
    public MoleImageView(Context context)
    {
        super(context);
        // TODO Auto-generated constructor stub
        InitialTasks();

    }

    /**
     * @param context
     * @param attrs
     */
    public MoleImageView(Context context, AttributeSet attrs)
    {
        super(context, attrs);
        // TODO Auto-generated constructor stub
        InitialTasks();
    }

    /**
     * @param context
     * @param attrs
     * @param defStyle
     */
    public MoleImageView(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
        // TODO Auto-generated constructor stub
        InitialTasks();
    }


    @Override
    public boolean onTouchEvent(final MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN){
            if(moleStatus == MoleStatus.ON) {
                moleStatus = MoleStatus.PUSHED;
                SetImage();
                molesClickedTimes++;
                listenerMoleClicked.OnMoleClicked(molesClickedTimes);
            }
        }
        else if(event.getAction() == MotionEvent.ACTION_UP){
            //moleStatus = MoleStatus.OFF;
            //SetImage();
            if(moleStatus == MoleStatus.PUSHED) {
                moleStatus = MoleStatus.OFF;
                handler.removeCallbacks(setMoleOnRunnable);
                handler.postDelayed(setMoleOnRunnable, 200);
            }
            //SetRandomMole();
        }
        return true;
    }

    private void InitialTasks()
    {
        SetImage();
    }

    Runnable setMoleOnRunnable = new Runnable() {
        public void run() {
            SetRandomMole();
        }
    };


    private void SetImage()
    {
        if(moleStatus == MoleStatus.ON)
            this.setImageResource(R.drawable.cigon);
        else if((moleStatus == MoleStatus.PUSHED) || (moleStatus == MoleStatus.OFF))
            this.setImageResource(R.drawable.cigoff);
    }


    public void ShowMolesOnLayout(RelativeLayout gameRelativeLayout_)
    {
        gameRelativeLayout = gameRelativeLayout_;
        gameRelativeLayout.addView(this);
    }

    public void RemoveMolesFromLayout(RelativeLayout gameRelativeLayout_)
    {
        gameRelativeLayout = gameRelativeLayout_;
        gameRelativeLayout.removeView(this);
    }

    private void SetRandomMole()
    {
        Random r = new Random();
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(30, 40);
        params.width = gameRelativeLayout.getWidth() / 5;
        params.height = gameRelativeLayout.getHeight() / 5;
        params.leftMargin = r.nextInt(gameRelativeLayout.getWidth() - params.width);
        params.topMargin = r.nextInt(gameRelativeLayout.getHeight() - params.height);

        this.setLayoutParams(params);
        moleStatus = MoleStatus.ON;
        SetImage();

        if(ShowMoleTime > 400)
            ShowMoleTime -=30;
        else
            ShowMoleTime = 400;
        handler.removeCallbacks(setMoleOnRunnable);
        handler.postDelayed(setMoleOnRunnable, ShowMoleTime);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        // TODO Auto-generated method stub
        super.onWindowFocusChanged(hasFocus);
        //updateSizeInfo();
        int w = gameRelativeLayout.getWidth();
        int h = gameRelativeLayout.getHeight();

        SetRandomMole();
    }

    /*
    @Override
    protected void onDraw(Canvas canvas)
    {
        // TODO Auto-generated method stub
        super.onDraw(canvas);
        System.out.println("Painting content");
        Paint paint  = new Paint(Paint.LINEAR_TEXT_FLAG);
        paint.setColor(0x0);
        paint.setTextSize(12.0F);
        System.out.println("Drawing text");
        canvas.drawText("Hello World in custom view", 100, 100, paint);
    }
    */
    /*
    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        // TODO Auto-generated method stub
        Log.d("Hello Android", "Got a touch event: " + event.getAction());
        return super.onTouchEvent(event);

    }
    */
}
