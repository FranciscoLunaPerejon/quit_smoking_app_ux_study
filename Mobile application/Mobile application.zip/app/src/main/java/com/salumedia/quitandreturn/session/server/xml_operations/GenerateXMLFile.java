package com.salumedia.quitandreturn.session.server.xml_operations;

import android.util.Xml;

import com.salumedia.quitandreturn.model.SFBAppInteractionAnalytic;
import com.salumedia.quitandreturn.model.SFBExtendedProfileFormQuestion;
import com.salumedia.quitandreturn.model.SFBMessageInteractionAnalytic;
import com.salumedia.quitandreturn.model.SFBMiniGameAnalytics;

import org.xmlpull.v1.XmlSerializer;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;



/**
 * Created by joaquin on 24/6/16.
 */
public class GenerateXMLFile {
    private static GenerateXMLFile INSTANCE = null;
    private final String GET_ALL_DATA = "GetAllData";

    private GenerateXMLFile() {
    }

    // Creador sincronizado para protegerse de posibles problemas  multi-hilo
    // otra prueba para evitar instanciacion múltiple
    private static void newInstance() {
        if (INSTANCE == null) {
            // Solo se accede a la zona sincronizada
            // cuando la instancia no está creada
            synchronized (GenerateXMLFile.class) {
                // En la zona sincronizada seria necesario volver
                // a comprobar que no se ha creado la instancia
                if (INSTANCE == null)
                    INSTANCE = new GenerateXMLFile();
            }
        }
    }

    public static GenerateXMLFile getInstance() {
        if (INSTANCE == null)
            newInstance();
        return INSTANCE;
    }

    //El método "clone" es sobreescrito por el siguiente que arroja una excepcion:
    public Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException();
    }

    ///////////////////////////////////////////////////////////

    // CREATE REQUESTS

    public String registration(String username, String termsAccepted){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            s.setOutput(writer);

            //******* First level (Start Document) *******
            s.startDocument("latin1", true);

            //****** XML header (meta-data) **********
            //TODO Consider if it is necessary add metadata

            s.startTag(null, "RegistrationRequest");
            createSingleTag(s, "AppID", "SFB");
            s.startTag(null, "Resources");
            createSingleTag(s, "username", username);
            createSingleTag(s, "language", Locale.getDefault().toString());
            createSingleTag(s, "termsAccepted", termsAccepted);
            s.endTag(null, "Resources");
            s.endTag(null, "RegistrationRequest");
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }
        return outputXML;
    }

    public String verifyUserRegistrationRequest(String username, String token){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            s.setOutput(writer);

            //******* First level (Start Document) *******
            s.startDocument("latin1", true);

            //****** XML header (meta-data) **********
            //TODO Consider if it is necessary add metadata

            s.startTag(null, "VerifyUserRegistrationRequest");
            createSingleTag(s, "AppID", "SFB");
            s.startTag(null, "Resources");
            createSingleTag(s, "username", username);
            createSingleTag(s, "token", token);
            s.endTag(null, "Resources");
            s.endTag(null, "VerifyUserRegistrationRequest");
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }
        return outputXML;
    }

    public String confirmUserRegistration(String username, String token, String password, String FCMToken){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            s.setOutput(writer);

            //******* First level (Start Document) *******
            s.startDocument("latin1", true);

            //****** XML header (meta-data) **********
            //TODO Consider if it is necessary add metadata

            s.startTag(null, "ConfirmRegistration");
            createSingleTag(s, "AppID", "SFB");
            s.startTag(null, "Resources");
            createSingleTag(s, "username", username);
            createSingleTag(s, "hashPass", password);
            createSingleTag(s, "token", token);
            createSingleTag(s, "language", Locale.getDefault().toString());
            createSingleTag(s, "fcmToken", FCMToken);
            createSingleTag(s, "timeZone", TimeZone.getDefault().getID());
            s.endTag(null, "Resources");
            s.endTag(null, "ConfirmRegistration");
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }
        return outputXML;
    }

    public String resetPasswordRequest(String username){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            s.setOutput(writer);

            //******* First level (Start Document) *******
            s.startDocument("latin1", true);

            //****** XML header (meta-data) **********
            //TODO Consider if it is necessary add metadata

            s.startTag(null, "GetLinkToChangePassword");
            createSingleTag(s, "AppID", "SFB");
            s.startTag(null, "Resources");
            createSingleTag(s, "username", username);
            createSingleTag(s, "language", Locale.getDefault().toString());
            s.endTag(null, "Resources");
            s.endTag(null, "GetLinkToChangePassword");
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }
        return outputXML;
    }

    public String addQuittingAttempt(String[] periodData, Integer[] fagerstrom, Integer[] richmond){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            beginAddRequestXML(s, writer, "AddQuittingPeriod");
            createQuittingAttemptData(s, periodData, fagerstrom, richmond);
            endAddRequestXML(s);
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }

        return outputXML;
    }

    public String addMessageInteractions(List<SFBMessageInteractionAnalytic> list) {

        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            beginAddRequestXML(s, writer, "AddMessageInteraction");
            for( SFBMessageInteractionAnalytic i : list) {

                createBodyMessageInteraction(s, i);
            }
            endAddRequestXML(s);
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }

        return outputXML;
    }

    public String addAppInteraction(List<SFBAppInteractionAnalytic> list){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            beginAddRequestXML(s, writer, "AddAppInteraction");
            for( SFBAppInteractionAnalytic i : list) {
                createBodyAppInteractions(s, i);
            }
            endAddRequestXML(s);
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }

        return outputXML;
    }

    public String addFitnessActivity(List<String> dailyFitnessActivityLastDays, List<String> activityDates) {
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try {
            beginAddRequestXML(s, writer, "AddFitnessActivity");
            for (int i=0; i<dailyFitnessActivityLastDays.size(); i++){
                createBodyDailyFitnessActivity(s, dailyFitnessActivityLastDays.get(i), activityDates.get(i));
            }
            endAddRequestXML(s);
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return outputXML;
    }

    public String addMiniGameActivity(List<SFBMiniGameAnalytics> list){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            beginAddRequestXML(s, writer, "AddMiniGamesActivity");
            for( SFBMiniGameAnalytics i : list) {
                createBodyMiniGameActivity(s, i);
            }
            endAddRequestXML(s);
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }

        return outputXML;
    }

    private void createBodyMiniGameActivity(XmlSerializer s, SFBMiniGameAnalytics a) throws  IOException{
        s.startTag(null, "item");
        createSingleTag(s, "name",a.getName());
        createSingleTag(s, "score",String.valueOf(a.getScore()));
        createSingleTag(s,"date", a.getDate());
        createSingleTag(s,"time", a.getTime());
        createSingleTag(s,"timePlaying", String.valueOf(a.getPlayingTime()));
        if(a.getName() != "WhackAMole"){
            createSingleTag(s, "penalties",String.valueOf(a.getPenalties()));
        }
        s.endTag(null, "item");
    }

    // Auxiliary methods

    private void createDemographicData(XmlSerializer s, String name, String gender, String birthDate, String employment)throws IOException{
        s.startTag(null, "DemographicData");

        createSingleTag(s,"name",name);
        createSingleTag(s,"gender", gender);
        createSingleTag(s,"birthDate", birthDate);
        createSingleTag(s,"employmentSituation", employment);
        s.endTag(null, "DemographicData");
    }

    private void createSmokingData(XmlSerializer s, String start_smoking_date)throws IOException{
        s.startTag(null, "SmokingData");
        createSingleTag(s, "startSmokingDate",start_smoking_date);
        s.endTag(null, "SmokingData");
    }

    private void createQuittingAttemptData(XmlSerializer s, String[] periodData,
                                           Integer[] fagerstrom, Integer[] richmond)throws IOException{
        createSingleTag(s, "startQuittingPeriodDate",periodData[0]);
        createSingleTag(s,"dailyCigarettes", periodData[1]);
        createSingleTag(s,"weeklyExpenditure", periodData[2]);
        createSingleTag(s, "currency", periodData[3]);
        createSmokingTestData(s, fagerstrom, richmond);
    }

    private void createSmokingTestData(XmlSerializer s, Integer[] fagerstrom, Integer[] richmond) throws IOException{
        s.startTag(null, "TestResults");
        createFagerstromResults(s, fagerstrom);
        createRichmondResults(s, richmond);
        s.endTag(null, "TestResults");
    }

    private void createFagerstromResults(XmlSerializer s, Integer[] results) throws IOException{
        s.startTag(null, "FagerstromTest");
        createTestResults(s, results);
        s.endTag(null, "FagerstromTest");
    }

    private void createRichmondResults(XmlSerializer s, Integer[] results) throws IOException{
        s.startTag(null, "RichmondTest");
        createTestResults(s, results);
        s.endTag(null, "RichmondTest");
    }

    private void createTestResults(XmlSerializer s, Integer[] results) throws IOException{

        for(int i = 1; i<results.length; i++){
            createSingleTag(s, "question" + String.valueOf(i), results[i-1].toString());
        }
        createSingleTag(s, "punctuation", results[results.length-1].toString());
    }

    private void createBodyMessageInteraction(XmlSerializer s, SFBMessageInteractionAnalytic m) throws IOException{
        s.startTag(null, "item");
        createSingleTag(s, "idMessage",m.getIdServer());
        createSingleTag(s,"readDate", m.getDate());
        createSingleTag(s,"readTime", m.getTimeStartRead());
        createSingleTag(s, "secondsLecture", String.valueOf(Math.round(m.getSecondsLecture())));
        createSingleTag(s,"secondsBeforeLecture", m.getSecondsToRead()); //in seconds
        createSingleTag(s,"vote", m.getVote());
        createSingleTag(s,"favorite", m.getFavorite());
        s.endTag(null, "item");
    }

    private void createBodyAppInteractions(XmlSerializer s, SFBAppInteractionAnalytic a) throws  IOException{
        s.startTag(null, "item");
        createSingleTag(s, "section",a.getTagName());
        createSingleTag(s,"date", a.getDate());
        createSingleTag(s,"time", a.getTime());
        createSingleTag(s, "millisecondsDuration", String.valueOf(Math.round(a.getMilliSecondsDuration())));
        s.endTag(null, "item");
    }

    private void createBodyDailyFitnessActivity(XmlSerializer s, String dailyFitnessActivity, String activityDate) throws  IOException{
        s.startTag(null, "item");
        createSingleTag(s, "fitnessValue",String.valueOf(dailyFitnessActivity));
        createSingleTag(s, "activityDate", activityDate);
        s.endTag(null, "item");
    }

    // READ REQUESTS

    public String getAllDataRequest(){
        return getRequest(GET_ALL_DATA);
    }


    // UPDATE REQUESTS


    public String updateToken(){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            beginModifyRequestXML(s, writer, "SetToken");
            endModifyRequestXML(s);
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }
        return outputXML;
    }
    public String setPersonalData(String[] fields, String patientCode){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            beginModifyRequestXML(s, writer, "SetPersonalData");
            createDemographicData(s, fields[0], fields[1], fields[2], fields[3]); //name, gender, birthdate, employment situation
            createSmokingData(s,fields[4]); //start smoking date, daily cigarettes, weekly expenditure
            createPatientData(s, patientCode);
            endModifyRequestXML(s);
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }
        return outputXML;
    }

    private void createPatientData(XmlSerializer s, String patientCode)throws IOException{
        s.startTag(null, "PatientData");
        createSingleTag(s, "is_patient", patientCode.equals("") ? "false" : "true");
        createSingleTag(s, "patient_code", patientCode);
        s.endTag(null, "PatientData");
    }

    public String setConfiguration(Integer notDisturbCode, String notDisturbUntil, String language) {
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try {
            beginModifyRequestXML(s, writer, "SetConfiguration");
            createSingleTag(s, "notDisturb",String.valueOf(notDisturbCode));
            createSingleTag(s, "notDisturbUntil",notDisturbUntil);
            createSingleTag(s, "language", language);
            endModifyRequestXML(s);
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return outputXML;
    }

    public String finishQuittingAttempt(String date){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            beginModifyRequestXML(s, writer, "FinishQuittingPeriod");
            createSingleTag(s, "endDate",date);
            endModifyRequestXML(s);
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }
        return outputXML;
    }

    public String setMessageReceived(String id){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            beginModifyRequestXML(s, writer, "SentMessageReceived");
            createSingleTag(s, "messageId",id);
            endModifyRequestXML(s);
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }
        return outputXML;
    }

    public String setMessageUnread(String id){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            beginModifyRequestXML(s, writer, "MarkMessageUnread");
            createSingleTag(s, "messageId",id);
            endModifyRequestXML(s);
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }
        return outputXML;
    }

    public String setWeekDaysPreferences(String[] weekDaysPreferences){

        String[] days = new String[]{"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
        String[] prefix = new String[]{"allowOn","beginTime","endTime"};

        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            beginModifyRequestXML(s, writer, "SetWeekDaysPreferences");

            // Concat all combinations of days and prefix elements to use them like XML tags and
            // assign them the correspondent weekDaysPreferences element
            int lDays = days.length;
            for(int i = 0; i <lDays; i++){
                int lPrefix = prefix.length;
                for(int j = 0; j<lPrefix; j++){
                    createSingleTag(s, prefix[j]+days[i], weekDaysPreferences[i +(j*lDays)]);
                }
            }

            endModifyRequestXML(s);
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();

        }
        return outputXML;
    }

    public String setExtendedProfile(ArrayList<SFBExtendedProfileFormQuestion> listOfQuestions){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        String outputXML = "";
        try{
            beginModifyRequestXML(s, writer, "SetExtendedProfile");
            for(SFBExtendedProfileFormQuestion question: listOfQuestions) {
                String stringQuestionResponses = "";
                for(Boolean questionResponse : question.getAnswerResponses()){
                    stringQuestionResponses += questionResponse?"1":"0"; // concat 1 (true) and 0 (false)
                }
                createSingleTag(s, question.getQuestionTag(), stringQuestionResponses);
            }
            endModifyRequestXML(s);
            s.flush();
            outputXML = writer.toString();
            s.endDocument();
        }catch (IOException e){
            e.printStackTrace();
        }
        return outputXML;
    }



    //------EJEMPLO dejado a drede para recordar como crear un xml con atributos ---------//
    //----- usando los métodos:-----------------------------------------------------------//

    // s.startTag(null, "committer");
    // s.attribute(null, "xsi:type", "II");
    // createRootTag(s, "2.16.724.4.1.4.1.2003.11"); // Este metodo
    // createExtensionTag(s, "OpenClinica");         // y este son metodos creados en la clase
    // s.endTag(null, "committer");

    // El fragmento de xml generado queda:

    //<committer xsi:type="II">
    //<root>2.16.724.4.1.4.1.2003.11</root>
    //<extension>OpenClinica</extension>
    //</committer>

    //------------------------------------------------------------------------------------//


    // AUXILIARY METHODS

    // ABOUT CREATE REQUESTS

    private void beginAddRequestXML(XmlSerializer s, StringWriter writer, String fileId) {
        try {
            s.setOutput(writer);

            //******* First level (Start Document) *******
            s.startDocument("latin1", true);

            //****** XML header (meta-data) **********
            //TODO Consider if it is necessary add metadata

            s.startTag(null, "AddUserInformation");
            createSingleTag(s, "AppID", "SFB");
            createAddIDTag(s,fileId);
            s.startTag(null, "Resources");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void endAddRequestXML(XmlSerializer s) {
        try {
            s.endTag(null, "Resources");
            s.endTag(null, "AddUserInformation");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void createAddIDTag(XmlSerializer s, String value)throws IOException{
        createSingleTag(s,"AddID",value);
    }


    // ABOUT READ REQUESTS

    private String getRequest(String request){
        StringWriter writer = new StringWriter();
        XmlSerializer s = Xml.newSerializer();
        try {
            s.setOutput(writer);
            s.startDocument("UTF-8", true);
            s.startTag(null, "RetrieveUserInformation");
            createSingleTag(s, "AppID", "SFB");
            createSingleTag(s, "RetrieveID", request);
            s.endTag(null, "RetrieveUserInformation");
            s.endDocument();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return writer.toString();
    }


    // ABOUT UPDATE REQUESTS

    private void beginModifyRequestXML(XmlSerializer s, StringWriter writer, String fileId) {
        try {
            s.setOutput(writer);

            //******* First level (Start Document) *******
            s.startDocument("latin1", true);

            //****** XML header (meta-data) **********
            //TODO Consider if it is necessary add metadata

            s.startTag(null, "ModifyUserInformation");
            createSingleTag(s, "AppID", "SFB");
            createModifyIDTag(s,fileId);
            s.startTag(null, "Resources");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void endModifyRequestXML(XmlSerializer s) {
        try {
            s.endTag(null, "Resources");
            s.endTag(null, "ModifyUserInformation");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void createModifyIDTag(XmlSerializer s, String value) throws IOException{
        createSingleTag(s,"ModifyID",value);
    }

    // GENERIC AUXILIARY METHODS

    private void createSingleTag(XmlSerializer s, String tag, String text) throws IOException {
        s.startTag(null, tag);
        s.text(text);
        s.endTag(null, tag);
    }


}