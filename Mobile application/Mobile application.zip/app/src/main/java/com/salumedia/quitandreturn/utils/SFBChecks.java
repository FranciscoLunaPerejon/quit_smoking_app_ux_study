package com.salumedia.quitandreturn.utils;

import android.text.TextUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Francisco on 6/4/17.
 */

/**
 * Util class which contains method to validate that a variable has a correct value
 */
public class SFBChecks {

    private static final String USERNAME_PATTERN = "^[-_\\p{Alnum}]+(\\s+[-_\\p{Alnum}]+)*$";
    private static final String NUMBER_PATERN = "\\d+(?:\\.\\d+)?";

    public static boolean isValidEmail(CharSequence target) {
        return !TextUtils.isEmpty(target) && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    public static boolean validateNickName(CharSequence username){
        Pattern pattern = Pattern.compile(USERNAME_PATTERN);
        Matcher matcher = pattern.matcher(username);
        return matcher.matches();
    }

    public static boolean stringIsANumber(String string){
        return string.matches(NUMBER_PATERN);
    }
}
