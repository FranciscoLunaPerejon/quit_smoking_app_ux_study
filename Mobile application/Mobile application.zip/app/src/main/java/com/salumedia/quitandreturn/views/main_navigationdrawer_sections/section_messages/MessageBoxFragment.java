package com.salumedia.quitandreturn.views.main_navigationdrawer_sections.section_messages;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.adapters.MotivationalMessageAdapter;
import com.salumedia.quitandreturn.model.SFBNotification;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;

import java.util.ArrayList;


/**
 * Created by Francisco on 1/6/17.
 */

public class MessageBoxFragment extends Fragment {

    View rootView;

    LocalDataBaseHelper database;

    public MessageBoxFragment() {
        // Required empty public constructor
    }

    // Constructor that allow receive information from the invoking class
    public static MessageBoxFragment newInstance(Bundle arguments){
        MessageBoxFragment f =  new MessageBoxFragment();
        //Extract information if exists
        if(arguments != null){
            f.setArguments(arguments);
        }
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_message_box, container, false);

        database = new LocalDataBaseHelper(rootView.getContext());
        ArrayList<SFBNotification> messageNotifications = database.selectMessageNotifications();

        RecyclerView recyclerView = (RecyclerView) rootView.findViewById(R.id.message_box_recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemViewCacheSize(messageNotifications.size());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(rootView.getContext());
        recyclerView.setLayoutManager(layoutManager);

        MotivationalMessageAdapter adapter = new MotivationalMessageAdapter(rootView.getContext(), messageNotifications);
        recyclerView.setAdapter(adapter);

        return rootView;
    }


}
