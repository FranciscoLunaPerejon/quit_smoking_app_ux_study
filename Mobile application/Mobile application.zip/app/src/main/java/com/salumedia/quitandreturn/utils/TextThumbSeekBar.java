package com.salumedia.quitandreturn.utils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.TextView;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBNotification;
import com.salumedia.quitandreturn.session.local.SessionData;

import java.util.ArrayList;
import java.util.Calendar;



/**
 * Created by joaquin on 4/8/16.
 */
public class TextThumbSeekBar extends android.support.v7.widget.AppCompatSeekBar {

    private int mThumbSize;
    private TextPaint mTextPaint;
    private String mProgressValue = null;

    public TextThumbSeekBar(Context context) {
        this(context, null);
    }

    public TextThumbSeekBar(Context context, AttributeSet attrs) {
        this(context, attrs, android.R.attr.seekBarStyle);
    }

    public TextThumbSeekBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        mThumbSize = getResources().getDimensionPixelSize(R.dimen.thumb_size);

        mTextPaint = new TextPaint();
        //mTextPaint.setColor(Color.WHITE);
        mTextPaint.setColor(0x0039C4b6);
        mTextPaint.setTextSize(getResources().getDimensionPixelSize(R.dimen.thumb_text_size));
        mTextPaint.setTypeface(Typeface.DEFAULT_BOLD);
        mTextPaint.setTextAlign(Paint.Align.CENTER);
    }

    public String getmProgressValue() {
        return mProgressValue;
    }

    public void setmProgressValue(String mProgressValue) {
        this.mProgressValue = mProgressValue;
    }

    @Override
    protected synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        String progressText = mProgressValue == null ? String.valueOf(getProgress()) : mProgressValue;
        Rect bounds = new Rect();
        mTextPaint.getTextBounds(progressText, 0, progressText.length(), bounds);

        int leftPadding = getPaddingLeft() - getThumbOffset();
        int rightPadding = getPaddingRight() - getThumbOffset();
        int width = getWidth() - leftPadding - rightPadding;
        float progressRatio = (float) getProgress() / getMax();
        float thumbOffset = mThumbSize * (.5f - progressRatio);
        float thumbX = progressRatio * width + leftPadding + thumbOffset;
        float thumbY = getHeight() / 2f + bounds.height() / 2f;
        canvas.drawText(progressText, thumbX, thumbY, mTextPaint);
    }


    public static void configureWidget(TextThumbSeekBar seekBar, TextView title, TextView initialState, TextView endState, Context context, ArrayList<SFBNotification> list) {
        /**
         * consultar badges en bbdd en un arraylist
         *     Todos para la sección me
         *     De uno en uno para la sección benefits
         *
         * Con el arraylist consulto el más cercano a la fecha de hoy
         *     para los textviews start tengo que consultar el anterior de su categoria
         *
         * Tengo que establecer el valor actual y el valor a conseguir
         * Escribir el título del badge
         */

        // Initial and final views
        SFBNotification[] notifications = SFBNotification.getLastAndNextAchieveNotification(list, context);
        if(notifications[SFBConstantsAndCodes.SELECTED_NOTIFICATION].getSentDate().equals(SessionData.getSessionData(context).getQuittingDate())){
            initialState.setText("");
            endState.setText("");
            switch (notifications[SFBConstantsAndCodes.SELECTED_NOTIFICATION].getType()){
                case SFBConstantsAndCodes.NOTIFICATION_TYPE_CIGARETTES_NOT_SMOKED:
                    title.setText(R.string.not_smoking_all_badges_complete);
                    break;
                case SFBConstantsAndCodes.NOTIFICATION_TYPE_SMOKEFREE:
                    title.setText(R.string.smoke_free_all_badges_complete);
                    break;
                case SFBConstantsAndCodes.NOTIFICATION_TYPE_SAVINGS:
                    title.setText(R.string.savings_all_badges_complete);
                    break;
                case SFBConstantsAndCodes.NOTIFICATION_TYPE_HOURS_REGAINED:
                    title.setText(R.string.hours_regained_all_badges_complete);
                    break;
                default:
                    title.setText(R.string.generic_all_badges_complete);
                    break;
            }
            seekBar.setmProgressValue(String.valueOf(100) + "%");
            seekBar.setProgress(100);
        }else {

            if (notifications[SFBConstantsAndCodes.PREVIOUS_NOTIFICATION].getSentDate() == null) {
                initialState.setText("0");
            } else {
                int startValue = getIndexValue(notifications[SFBConstantsAndCodes.PREVIOUS_NOTIFICATION].getText(),
                        notifications[SFBConstantsAndCodes.PREVIOUS_NOTIFICATION].getType(),
                        SessionData.getSessionData(context).getCurrency(),context);
                initialState.setText(String.valueOf(startValue));
            }
            int endValue = getIndexValue(notifications[SFBConstantsAndCodes.SELECTED_NOTIFICATION].getText(),
                    notifications[SFBConstantsAndCodes.SELECTED_NOTIFICATION].getType(),
                    SessionData.getSessionData(context).getCurrency(), context);
            endState.setText(String.valueOf(endValue));

            // Title
            String formattedTitle = getFormattedTitle(endState, notifications[SFBConstantsAndCodes.SELECTED_NOTIFICATION].getType(), context);
            title.setText(formattedTitle);

            // Initial and final views in regained hours case
            if (notifications[SFBConstantsAndCodes.SELECTED_NOTIFICATION].getType() == SFBConstantsAndCodes.NOTIFICATION_TYPE_HOURS_REGAINED) {
                initialState.setText(formattedViewsHoursRegained(initialState, context));
                endState.setText(formattedViewsHoursRegained(endState, context));
            }

            // Setting SeekBar value
            Calendar calendar = Calendar.getInstance();

            long seekbarMaxValue;
            long seekbarActualValue;
            if (notifications[SFBConstantsAndCodes.PREVIOUS_NOTIFICATION].getSentDate() == null) {

                seekbarMaxValue = notifications[SFBConstantsAndCodes.SELECTED_NOTIFICATION].getSentDate().getTimeInMillis()
                        - SessionData.getSessionData(context).getQuittingDate().getTimeInMillis();
                seekbarActualValue = calendar.getTimeInMillis() -
                        SessionData.getSessionData(context).getQuittingDate().getTimeInMillis();
            } else {
                seekbarMaxValue = notifications[SFBConstantsAndCodes.SELECTED_NOTIFICATION].getSentDate().getTimeInMillis()
                        - notifications[SFBConstantsAndCodes.PREVIOUS_NOTIFICATION].getSentDate().getTimeInMillis();
                seekbarActualValue = calendar.getTimeInMillis()
                        - notifications[SFBConstantsAndCodes.PREVIOUS_NOTIFICATION].getSentDate().getTimeInMillis();
            }

            seekbarActualValue = seekbarMaxValue < seekbarActualValue ? seekbarMaxValue : seekbarActualValue;
            int percentageProgress = Math.round(seekbarActualValue * 100 / seekbarMaxValue);
            seekBar.setmProgressValue(String.valueOf(percentageProgress) + "%");
            seekBar.setProgress(percentageProgress);
        }
    }

    private static String getFormattedTitle(TextView endState, Integer type, Context context) {
        String formattedTitle = "";
        Log.d("RECOVERY", endState.getText() + "");
        switch (type) {
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_CIGARETTES_NOT_SMOKED:
                formattedTitle = context.getString(R.string.achieve_cigarettes_p1) + endState.getText() + context.getString(R.string.achieve_cigarettes_p2);
                break;
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_SMOKEFREE:
                formattedTitle = context.getString(R.string.achieve_smokefree_p1) + endState.getText() + context.getString(R.string.achieve_smokefree_p2);
                break;
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_SAVINGS:
                formattedTitle = context.getString(R.string.achieve_savings_p1) + endState.getText()
                        + " " + SessionData.getSessionData(context).getCurrency() + " " + context.getString(R.string.achieve_savings_p2);
                break;
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_HOURS_REGAINED:
                formattedTitle = context.getString(R.string.achieve_hours_regained_p1) + formattedTitleHoursRegained(endState, context) + context.getString(R.string.achieve_hours_regained_p2);
                break;
            default:
                break;
        }
        return formattedTitle;
    }

    private static String formattedTitleHoursRegained(TextView endState, Context context) {
        String[] messages = context.getResources().getStringArray(R.array.hours_regained_badges_seek_bar_end_text_view_index);
        String[] values = context.getResources().getStringArray(R.array.hours_regained_badges_seek_bar_end_text_view);
        int index;
        for (index = 0; index < messages.length; index++) {
            String text = endState.getText().toString();
            if (text.equalsIgnoreCase(messages[index])) {
                return values[index];
            }
        }
        return "";
    }

    private static String formattedViewsHoursRegained(TextView endState, Context context) {
        String[] messages = context.getResources().getStringArray(R.array.hours_regained_badges_seek_bar_end_text_view_index);
        String[] values = context.getResources().getStringArray(R.array.hours_regained_badges);
        int index;
        for (index = 0; index < messages.length; index++) {
            String text = endState.getText().toString();
            if (text.equalsIgnoreCase(messages[index])) {
                return values[index];
            }
        }
        return "";
    }

    private static int getIndexValue(String text, int type, String currency, Context context) {
        int arrayMessageResource = 0;
        int arrayValueResource = 0;
        switch (type) {
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_CIGARETTES_NOT_SMOKED:
                arrayMessageResource = R.array.cigarettes_not_smoked_badges_message;
                arrayValueResource = R.array.cigarettes_not_smoked_badges;
                break;
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_HOURS_REGAINED:
                arrayMessageResource = R.array.hours_regained_badges_message;
                arrayValueResource = R.array.hours_regained_badges_seek_bar_end_text_view_index;
                break;
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_SAVINGS:
                switch (currency) {
                    case SFBCurrencyConversions.symbolTaiwaneseDollar:
                        arrayValueResource = R.array.saving_badges_twd;
                        arrayMessageResource = R.array.saving_badges_message_twd;
                        break;
                    case SFBCurrencyConversions.symbolDollar:
                        arrayValueResource = R.array.saving_badges_dollars;
                        arrayMessageResource = R.array.saving_badges_message_dollars;
                        break;
                    case SFBCurrencyConversions.symbolYuan:
                        arrayValueResource = R.array.saving_badges_yuan;
                        arrayMessageResource = R.array.saving_badges_message_yuan;
                        break;
                    case SFBCurrencyConversions.symbolBritishPound:
                        arrayValueResource = R.array.saving_badges_british_pound;
                        arrayMessageResource = R.array.saving_badges_message_british_pound;
                        break;
                    default:
                        arrayValueResource = R.array.saving_badges_euros;
                        arrayMessageResource = R.array.saving_badges_message_euros;
                        break;
                }
                break;
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_SMOKEFREE:
                arrayMessageResource = R.array.smoke_free_badges_message;
                arrayValueResource = R.array.smoke_free_badges;
                break;
            default:
                break;
        }
        String[] messages = context.getResources().getStringArray(arrayMessageResource);
        String[] values = context.getResources().getStringArray(arrayValueResource);
        int index;
        for (index = 0; index < messages.length; index++) {
            if (text.equalsIgnoreCase(messages[index])) {
                return Integer.parseInt(values[index]);
            }
        }
        return 0;
    }

}