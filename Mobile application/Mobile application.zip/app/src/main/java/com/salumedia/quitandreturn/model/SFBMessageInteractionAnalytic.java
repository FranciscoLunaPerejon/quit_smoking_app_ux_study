package com.salumedia.quitandreturn.model;

/**
 * Created by Francisco on 25/3/17.
 */

/**
 * Used to create message interaction instances, for analytical purpose, that contains information
 * like the message assessment for the user, time spend reading it, and others.
 */
public class SFBMessageInteractionAnalytic {

    private float secondsLecture;
    private String idServer, date, timeStartRead, vote, secondsToRead, favorite;

    public SFBMessageInteractionAnalytic(String idServer, String date, String timeStartRead,
                                         float secondsLecture, String secondsToRead, String vote, String favorite) {
        this.secondsLecture = secondsLecture;
        this.idServer = idServer;
        this.date = date;
        this.timeStartRead = timeStartRead;
        this.vote = vote;
        this.secondsToRead = secondsToRead;
        this.favorite = favorite;
    }

    public float getSecondsLecture() {
        return secondsLecture;
    }

    public void setSecondsLecture(float secondsLecture) {
        this.secondsLecture = secondsLecture;
    }

    public String getIdServer() {
        return idServer;
    }

    public void setIdServer(String idServer) {
        this.idServer = idServer;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTimeStartRead() {
        return timeStartRead;
    }

    public void setTimeStartRead(String timeStartRead) {
        this.timeStartRead = timeStartRead;
    }

    public String getVote() {
        return vote;
    }

    public void setVote(String vote) {
        this.vote = vote;
    }

    public String getSecondsToRead() {
        return secondsToRead;
    }

    public void setSecondsToRead(String secondsToRead) {
        this.secondsToRead = secondsToRead;
    }

    public String getFavorite() {
        return favorite;
    }

    public void setFavorite(String favorite) {
        this.favorite = favorite;
    }

    @Override
    public String toString() {
        return "SFBMessageInteractionAnalytic{" +
                "secondsLecture=" + secondsLecture +
                ", idServer='" + idServer + '\'' +
                ", date='" + date + '\'' +
                ", timeStartRead='" + timeStartRead + '\'' +
                ", vote='" + vote + '\'' +
                ", secondsToRead='" + secondsToRead + '\'' +
                ", favorite='" + favorite + '\'' +
                '}';
    }
}
