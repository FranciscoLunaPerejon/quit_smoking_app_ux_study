package com.salumedia.quitandreturn.utils;

import com.flurry.android.FlurryAgent;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by joaquin on 20/6/16.
 */
public final class SFBAnalytics {

    /**
     * Time spent in each section/subsection
     *
     * @param section
     */
    public static void startLogTimeInSection(String section) {
        Map<String, String> sectionParams = new HashMap<String, String>();
        sectionParams.put(SFBConstantsAndCodes.ANALYTIC_SECTION, section);
        FlurryAgent.logEvent(SFBConstantsAndCodes.ANALYTIC_SECTION_LOG_TIME, sectionParams, true);
    }

    public static void stopLogTimeInSection(String section) {
        FlurryAgent.endTimedEvent(section);
    }


}
