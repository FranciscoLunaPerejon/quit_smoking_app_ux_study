package com.salumedia.quitandreturn.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBAppInteractionAnalytic;
import com.salumedia.quitandreturn.model.SFBNotification;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.XMLHttpPost;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.SFBAnalytics;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBDate;
import com.salumedia.quitandreturn.utils.SFBEncode;
import com.salumedia.quitandreturn.views.dialogs.RateMessageDialogFragment;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;


/**
 * Created by Francisco on 1/6/17.
 */

public class MotivationalMessageAdapter extends RecyclerView.Adapter<MotivationalMessageAdapter.MessageViewHolder> {

    private MessageUnreadTask mUnreadTask;

    LocalDataBaseHelper db;

    private List<SFBNotification> messages;
    private Context mContext;

    public MotivationalMessageAdapter(Context context, List<SFBNotification> messages) {
        db = new LocalDataBaseHelper(context);
        this.messages = db.selectMessageNotifications();
        this.mContext = context;
    }

    public static class MessageViewHolder extends RecyclerView.ViewHolder {

        TextView textViewSentDate, messageStart;
        public LinearLayout layout;
        ImageView imageUser;
        RatingBar messageRatingBar;

        public MessageViewHolder(View v) {
            super(v);

            textViewSentDate = (TextView) v.findViewById(R.id.textViewSentDate);
            messageStart = (TextView) v.findViewById(R.id.introMessage);
            layout = (LinearLayout) v.findViewById(R.id.messageLayout);
            imageUser = (ImageView) v.findViewById(R.id.imageViewUser);
            messageRatingBar = (RatingBar) v.findViewById(R.id.messageRatingIndicatorBar);

        }

    }

    @Override
    public MessageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_motivational_message, parent, false);
        MessageViewHolder vh = new MessageViewHolder(v);

        return vh;
    }

    @Override
    public void onBindViewHolder(final MessageViewHolder holder, final int position) {

        messages = db.selectMessageNotifications();
        final SFBNotification notification = messages.get(position);

        String messageText = notification.getText();
        if(messageText.contains("//"))
            messageText = messageText.split("//")[0];
        holder.messageStart.setText(messageText);
        holder.textViewSentDate.setText(SFBDate.dateToStringFormatoVisual(notification.getSentDate()));
        // Motivational messages not read have a diferent icon and the text is bold
        if (notification.getType() == SFBConstantsAndCodes.NOTIFICATION_TYPE_MESSAGE_FROM_SERVER ||
                notification.getType() == SFBConstantsAndCodes.NOTIFICATION_TYPE_MOTIVATIONAL_MESSAGE_FROM_SERVER) {
            holder.imageUser.setImageResource(R.drawable.close_email);
            holder.messageStart.setTypeface(Typeface.DEFAULT_BOLD);
            holder.textViewSentDate.setTypeface(Typeface.DEFAULT_BOLD);
            holder.messageRatingBar.setVisibility(View.VISIBLE);
            holder.messageRatingBar.setRating(0f);

        }
        // Information messages, like the welcome message, have a different icon
        else if (notification.getType() == SFBConstantsAndCodes.NOTIFICATION_TYPE_INFORMATION) {
            holder.imageUser.setImageResource(R.drawable.about);
            holder.messageStart.setTypeface(Typeface.DEFAULT);
            holder.textViewSentDate.setTypeface(Typeface.DEFAULT_BOLD);
            holder.messageRatingBar.setVisibility(View.GONE);
        } else if (notification.getType() == SFBConstantsAndCodes.NOTIFICATION_TYPE_CRAVING) {
            holder.imageUser.setImageResource(R.drawable.helping);
            holder.messageStart.setTypeface(Typeface.DEFAULT);
            holder.textViewSentDate.setTypeface(Typeface.DEFAULT_BOLD);
            holder.messageRatingBar.setVisibility(View.GONE);
        }
        // If message is read, change the icon and set text in normal style
        if (notification.getRead()) {
            holder.imageUser.setImageResource(R.drawable.email);
            holder.messageStart.setTypeface(Typeface.DEFAULT);
            holder.textViewSentDate.setTypeface(Typeface.DEFAULT);
            Float messagerating = Float.valueOf(db.getMessageNotificationRating(notification.getIdServer()));
            holder.messageRatingBar.setRating(messagerating);
        }


        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dialogMessage = new AlertDialog.Builder(mContext);
                configureDialog(notification, holder.getAdapterPosition());
                final float start = Long.valueOf(System.nanoTime() / 1000000).floatValue();
                dialogMessage
                        .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                            }})
                        .setMessage(notification.getText())
                        .setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                String date = (new SimpleDateFormat("yyyy-MM-dd")).format(Calendar.getInstance().getTime());
                                String time = (new SimpleDateFormat("HH:mm:ss.SSS")).format(Calendar.getInstance().getTime());
                                // Data is stored in a local DB. It is sent to server when there are some rows in table db
                                SFBAppInteractionAnalytic SFBAppInteractionAnalytic = new SFBAppInteractionAnalytic("INFORMATION_MESSAGE_READING",
                                       date, time, Long.valueOf(System.nanoTime() / 1000000).floatValue() - start);
                                db.insertAppInteraction(SFBAppInteractionAnalytic);

                                try{
                                    SFBAnalytics.startLogTimeInSection("INFORMATION_MESSAGE_READING" +
                                            "_author:" +  SessionData.getSessionData(mContext).getUserData(mContext).getUserId() +
                                            "_date:" + date + " " +  time);
                                    SFBAnalytics.stopLogTimeInSection("INFORMATION_MESSAGE_READING" +
                                            "_author:" + SessionData.getSessionData(mContext).getUserData(mContext).getUserId() +
                                            "_date:" + date + " " +  time);
                                }catch (Exception e){
                                    SFBAnalytics.startLogTimeInSection("INFORMATION_MESSAGE_READING" + "_author:NOT_AVALIABLE" +
                                            "_date:" + date + " " +  time);
                                    SFBAnalytics.stopLogTimeInSection("INFORMATION_MESSAGE_READING" + "_author:NOT_AVALIABLE" +
                                            "_date:" + date + " " +  time);
                                }

                            }
                        });
                boolean showDialog = true;

                if (notification.getType() == SFBConstantsAndCodes.NOTIFICATION_TYPE_MOTIVATIONAL_MESSAGE_FROM_SERVER) {
                    showDialog = false;
                }

                SharedPreferences settings = mContext.getSharedPreferences("ReadMessages", Context.MODE_PRIVATE);
                SharedPreferences.Editor edit = settings.edit();
                edit.putString(notification.getId(), "1");
                edit.apply();

                if (showDialog) {
                    AlertDialog nonMotivationalMessage = dialogMessage.create();
                    nonMotivationalMessage.show();
                }
            }
        });

        holder.layout.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                final SharedPreferences settings = mContext.getSharedPreferences("ReadMessages", Context.MODE_PRIVATE);

                new android.app.AlertDialog.Builder(mContext)
                        .setMessage(R.string.check_not_read_message)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                SharedPreferences.Editor edit = settings.edit();
                                edit.putString(notification.getId(), "");
                                edit.apply();
                                db.markMessageNotificationUnread(notification.getIdServer());
                                mUnreadTask = new MessageUnreadTask(notification.getIdServer(), mContext);
                                mUnreadTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
                                notifyItemChanged(holder.getAdapterPosition());

                            }
                        })
                        .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        })
                        .show();
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }


    private void configureDialog(final SFBNotification notification, int recyclerViewItemPosition) {
        if (notification.getType() == SFBConstantsAndCodes.NOTIFICATION_TYPE_MOTIVATIONAL_MESSAGE_FROM_SERVER) {

            //INFORMATION TO SEND TO SERVER

            // Message id in server
            String serverId = notification.getIdServer();

            Calendar currentTimeStamp = Calendar.getInstance();

            //Time to read in seconds
            String timeToRead = ((Calendar.getInstance().getTimeInMillis() - notification.getSentDate().getTimeInMillis()) / 1000) + "";
            rateMessage(notification.getText(), serverId, currentTimeStamp, timeToRead, recyclerViewItemPosition);
        }
    }

    private void rateMessage(String text, String serverId, final Calendar currentTimeStamp, String timeToRead, final int recyclerViewItemPosition) {
        //time to read in seconds
        RateMessageDialogFragment rateMessageDialogFragment = RateMessageDialogFragment.newInstance(text, serverId, currentTimeStamp, timeToRead);
        rateMessageDialogFragment.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                notifyItemChanged(recyclerViewItemPosition);
            }
        });
        rateMessageDialogFragment.show(((AppCompatActivity) mContext).getSupportFragmentManager(), "Valorar");
    }

    public class MessageUnreadTask extends AsyncTask<Void, Void, Boolean> {

        Context context;

        private String id;

        private Integer failCode;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;

        public MessageUnreadTask(String id, Context context){
            this.context = context;
            this.id = id;
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected Boolean doInBackground(Void... voids) {

            GenerateXMLFile file = GenerateXMLFile.getInstance();

            String fileXMLRequest = file.setMessageUnread(id);
            if (XMLHttpPost.isConnectedToInternet(context)) {
                String responseXML = null;
                try {
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, context,
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    context).getUserCredentials()) );
                } catch (CertificateException | NoSuchAlgorithmException | KeyManagementException | IOException | KeyStoreException e) {
                    e.printStackTrace();
                }
                return true;
            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
                return false;
            }

        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mUnreadTask = null;

            if(!success) {
                //fragmentReference.refreshUI();
                if (failCode == CODE_ERROR_INTERNET_CONNECTION) {
                    Toast.makeText(context, R.string.error_internet_2,Toast.LENGTH_SHORT).show();
                }else {
                    db.markMessageNotificationUnread(id);

                }
            }else {
                db.markMessageNotificationUnread(id);

            }
        }
        @Override
        protected void onCancelled() {
            mUnreadTask = null;

            super.onCancelled();
        }

    }

}
