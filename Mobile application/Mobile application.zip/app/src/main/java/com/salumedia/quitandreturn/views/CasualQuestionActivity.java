package com.salumedia.quitandreturn.views;

import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBMessageInteractionAnalytic;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.MyFirebaseMessagingService;
import com.salumedia.quitandreturn.session.server.XMLHttpPost;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBDate;
import com.salumedia.quitandreturn.utils.SFBEncode;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static java.util.Calendar.getInstance;

/**
 * Created by Francisco on 22/5/17.
 */

public class CasualQuestionActivity extends AppCompatActivity{

    // An Async Task instance. It allows to do a background task
    QuestionResponseTask mQuestionResponseTask;

    FragmentManager mFragmentManager = getSupportFragmentManager();

    Button saveResponseButton;
    Button goOutButton;

    // Extract the type of question that have been requested
    int id;

    // Question response information values
    // Extract the id of question in server
    private String idInServer;

    private String dateAccess;
    private String timeStartAccess;
    private Float millisStartAccess;
    private String timeToAccess;


    // Cigarettes consumed RadioGroup View
    RadioGroup consumedCigarettesRadioGroup;

    // Messages frequency RadioGroup View
    RadioGroup messageFrequencyRadioGroup;

    Fragment fragment;

    @Override
    protected void onCreate(@Nullable final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_casual_question);

        initializeQuestionResponseInformation();

        id = getIntent().getExtras().getInt(MyFirebaseMessagingService.idQuestion);

        saveResponseButton = (Button) findViewById(R.id.save_question_response);
        goOutButton = (Button) findViewById(R.id.question_go_out_button);

        loadQuestion(id, savedInstanceState);

        saveResponseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (id){
                    case SFBConstantsAndCodes.SMOKEFREE_QUESTION_ID:
                        consumedCigarettesRadioGroup = (RadioGroup) findViewById(R.id.cigarettes_consumed_radiogroup);
                        if(isQuestionFilled(consumedCigarettesRadioGroup)){

                            // Cancel notification associated
                            NotificationManager manager = (NotificationManager) getSystemService(Service.NOTIFICATION_SERVICE);
                            manager.cancel(getIntent().getExtras().getInt(MyFirebaseMessagingService.idNotification));

                            SFBMessageInteractionAnalytic questionResponseInformation = getQuestionResponseInformation(getResponseId(consumedCigarettesRadioGroup), idInServer);
                            sendResponseToServer(questionResponseInformation);

                            SessionData.getSessionData(CasualQuestionActivity.this).changeIfThereAreASmokeFreeQuestionWithoutResponse(false);

                            showAvoidAboutCigarettesConsumed(consumedCigarettesRadioGroup.getCheckedRadioButtonId());
                            findViewById(R.id.form_cigarettes_consumed_box).setVisibility(View.GONE);
                            saveResponseButton.setVisibility(View.GONE);
                            goOutButton.setVisibility(View.VISIBLE);

                        }else{
                            Toast.makeText(getApplicationContext(), R.string.please_choice_an_option, Toast.LENGTH_SHORT).show();
                        }

                        break;
                    case SFBConstantsAndCodes.MESSAGES_FREQUENCY_QUESTION_ID:
                        messageFrequencyRadioGroup = (RadioGroup) findViewById(R.id.messages_frequency_radiogroup);
                        if(isQuestionFilled(messageFrequencyRadioGroup)){

                            // Cancel notification associated
                            NotificationManager manager = (NotificationManager) getSystemService(Service.NOTIFICATION_SERVICE);
                            manager.cancel(getIntent().getExtras().getInt(MyFirebaseMessagingService.idNotification));

                            SFBMessageInteractionAnalytic questionResponseInformation = getQuestionResponseInformation(getResponseId(messageFrequencyRadioGroup), idInServer);
                            sendResponseToServer(questionResponseInformation);

                            SessionData.getSessionData(CasualQuestionActivity.this).changeIfThereAreAMessagesFrequencyQuestionWithoutResponse(false);

                            findViewById(R.id.form_messages_frequency_box).setVisibility(View.GONE);
                            findViewById(R.id.form_messages_frequency_response_box).setVisibility(View.VISIBLE);
                            saveResponseButton.setVisibility(View.GONE);
                            goOutButton.setVisibility(View.VISIBLE);

                        }else{
                            Toast.makeText(getApplicationContext(), R.string.please_choice_an_option, Toast.LENGTH_SHORT).show();
                        }

                        break;
                    default:

                }
            }
        });
        goOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LauncherActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void initializeQuestionResponseInformation(){

        idInServer = getIntent().getExtras().getString("idQuestionInServer");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        dateAccess = sdf.format(getInstance().getTime());
        SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss.SSS");
        timeStartAccess = sdf2.format(getInstance().getTime());
        millisStartAccess = Long.valueOf(System.nanoTime()/1000000).floatValue();

        Calendar receivedQuestionDate = SFBDate.stringToCalendar(getIntent().getExtras().getString("receivedQuestionDate"));

        timeToAccess = ((Calendar.getInstance().getTimeInMillis() - receivedQuestionDate.getTimeInMillis()) / 1000) + "";;
    }

    private SFBMessageInteractionAnalytic getQuestionResponseInformation(int responseIndex, String idInServer){

        Float millisResponse = Long.valueOf(System.nanoTime()/1000000).floatValue();
        Float secondsToResponse = (millisResponse - millisStartAccess)/1000; // save seconds from access to question until response

        // Create the object used to manipulate the message lecture information
        SFBMessageInteractionAnalytic messageInteractionAnalytic = new SFBMessageInteractionAnalytic(idInServer,
                dateAccess,
                timeStartAccess,
                secondsToResponse,
                timeToAccess, //In seconds
                String.valueOf(responseIndex),
                "0");
        return messageInteractionAnalytic;
    }



    private void sendResponseToServer(SFBMessageInteractionAnalytic questionResponseInformation){
        mQuestionResponseTask = new QuestionResponseTask(CasualQuestionActivity.this, questionResponseInformation);
        mQuestionResponseTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
    }

    private void loadQuestion(int idQuestionFragment, Bundle savedInstanceState){
        String tag;
        switch (idQuestionFragment){
            case SFBConstantsAndCodes.SMOKEFREE_QUESTION_ID:
                fragment = ConsumedCigarettesFragment.newInstance(savedInstanceState);
                tag = ConsumedCigarettesFragment.TAG;
                break;
            case SFBConstantsAndCodes.MESSAGES_FREQUENCY_QUESTION_ID:
                fragment = MessagesFrequencyFragment.newInstance(savedInstanceState);
                tag = MessagesFrequencyFragment.TAG;
                break;
            default:
                tag = null;
        }
        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        transaction.replace(R.id.question_content, fragment, tag);
        transaction.commit();
    }

    private boolean isQuestionFilled(RadioGroup radioGroup){
        return radioGroup.getCheckedRadioButtonId() != -1;
    }

    private int getResponseId(RadioGroup radioGroup){
        return radioGroup.indexOfChild(findViewById(radioGroup.getCheckedRadioButtonId()));
    }

    private void showAvoidAboutCigarettesConsumed(int radioButtonId){
        int avoidStringResource;
        switch (radioButtonId){
            case R.id.cigarettes_consumed_option_none:
                avoidStringResource = R.string.notification_content_text_response_smokefree;
                break;
            case R.id.cigarettes_consumed_option_one:
//                avoidStringResource = R.string.cigarettes_consumed_avoid_one;
//                break;
            case R.id.cigarettes_consumed_option_few:
//                avoidStringResource = R.string.cigarettes_consumed_avoid_few;
//                break;
            case R.id.cigarettes_consumed_option_various:
                avoidStringResource = R.string.cigarettes_consumed_option_various;
                break;
            default:
                avoidStringResource = R.string.blank;
                break;
        }
        ((TextView) findViewById(R.id.cigarettes_consumed_avoid_body)).setText(avoidStringResource);
        findViewById(R.id.form_cigarettes_consumed_avoid_box).setVisibility(View.VISIBLE);

    }

    private class QuestionResponseTask extends AsyncTask<Void, Void, Boolean> {

        Context context;

        // Attribute with the information to send to the server
        private SFBMessageInteractionAnalytic SFBMessageInteractionAnalytic;

        // used to pause the app activity until the task finish, and alert to the user
        private ProgressDialog mProgressDialog;

        // attribute to store a possible error trying to send the information
        private Integer failCode;

        // possible fail codes

        private final int CODE_ERROR_INTERNET_CONNECTION = 4;


        // Constructor
        QuestionResponseTask(Context context, SFBMessageInteractionAnalytic SFBMessageInteractionAnalytic){
            this.context = context;
            this.SFBMessageInteractionAnalytic = SFBMessageInteractionAnalytic;
        }

        // The task part that is executed in different thread (The other parts are executed in the main thread)
        @Override
        protected Boolean doInBackground(Void... voids) {

            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            GenerateXMLFile file = GenerateXMLFile.getInstance();

            // Check if exists an internet connection
            if (XMLHttpPost.isConnectedToInternet(context)) {
                // SEND HTTP POST REQUEST
                String responseXML = null;

                // Create the xml request with the previous values
                List<SFBMessageInteractionAnalytic> list = new ArrayList<>();
                list.add(SFBMessageInteractionAnalytic);
                // Specific xml request using the values
                String fileXMLRequest = file.addMessageInteractions(list);

                try {
                    //Introduce XML and catch server response
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, context,
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    context).getUserCredentials()) );
                } catch (CertificateException | NoSuchAlgorithmException | KeyManagementException | IOException | KeyStoreException e) {
                    e.printStackTrace();
                }
                return responseXML.equals("created");
            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
                return false;
            }
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog = new ProgressDialog(context);
                mProgressDialog.setMessage(getString(R.string.checking_user));
                mProgressDialog.setCancelable(false);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(final Boolean success) {

            mQuestionResponseTask = null;
            LocalDataBaseHelper db = new LocalDataBaseHelper(context);

            if(!success) { //Data not saved in server: store in local db temporally
                db.insertMessageInteractionToSend(SFBMessageInteractionAnalytic);
            }

        }
        @Override
        protected void onCancelled() {
            mQuestionResponseTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}
