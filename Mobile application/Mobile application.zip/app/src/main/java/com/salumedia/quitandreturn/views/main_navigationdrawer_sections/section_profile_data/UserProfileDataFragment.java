package com.salumedia.quitandreturn.views.main_navigationdrawer_sections.section_profile_data;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.SFBFragment;
import com.salumedia.quitandreturn.model.SFBAppInteractionAnalytic;
import com.salumedia.quitandreturn.model.SFBPersonalData;
import com.salumedia.quitandreturn.model.SFBQuittingAttempt;
import com.salumedia.quitandreturn.model.SFBSmokingData;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.XMLHttpPost;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBDate;
import com.salumedia.quitandreturn.utils.SFBEncode;
import com.salumedia.quitandreturn.views.forms.ExtendedProfileFormActivity;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;



/**
 * Created by Francisco on 16/12/16.
 */

public class UserProfileDataFragment extends SFBFragment {

    // Personalized listener used to send information to container activity
    OnPersonalDataFragmentInteractionListener mListener;

    // Form information TAG
    private final String personalDataFormInformationTAG = "PersonalData";
    private final String fagerstromFormInformationTAG = "fagerstrom";
    private final String richmondFormInformationTAG = "richmond";
    private final String previousSmokingHabitsFormInformationTAG = "previousSmokingHabits";

    // View attributes

    FloatingActionButton selectPersonalDataFormInformation;
    FloatingActionButton selectFagerstromFormInformation;
    FloatingActionButton selectRichmondFormInformation;
    FloatingActionButton selectPreviousSmokingHabitsFormInformation;

    Button goToForm;
    Button buttonStartQuittingAttempt;
    RelativeLayout buttonEndQuittingAttempt;
    RelativeLayout layoutGoToEditProfileDataDuringQuittingAttempt;

    TextView resumeName;
    TextView resumeBirthday;
    TextView resumeEmployment;
    TextView resumeDateStartSmoking;
    TextView genderAndAgeTexView;
    TextView cigarettesTextView;
    TextView expensesTextView;
    TextView quittingDateTextView;

    // Form Information Selected
    private String formInformationSelected = personalDataFormInformationTAG;

    // To show text messages to the user
    Toast toast;

    // Access to shared preferences
    SessionData sessionData;
    // Access to local DB
    LocalDataBaseHelper db;

    // Auxiliary view to inflate the fragment. It is used in auxiliary methods, so it is set as an
    // attribute of the class
    View rootView;

    // An Async Task instance. It allows to do a background task
    FinishQuittingAttemptTask mFinQuitAttempt;

    // Necessary default constructor
    public UserProfileDataFragment() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Not View attributes instantiation
        section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_PERSONAL_DATA; // Analysis purpose
        sessionData = SessionData.getSessionData(getContext()); // Shared preferences access
        db = new LocalDataBaseHelper(getContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // Inflating the layout with the fragment
        rootView = inflater.inflate(R.layout.fragment_user_profile_data, container, false);

        selectFagerstromFormInformation = (FloatingActionButton) rootView.findViewById(R.id.access_information_test_fagerstrom);
        selectRichmondFormInformation = (FloatingActionButton) rootView.findViewById(R.id.access_information_test_richmond);
        selectPersonalDataFormInformation = (FloatingActionButton) rootView.findViewById(R.id.access_information_personal_data);
        selectPreviousSmokingHabitsFormInformation = (FloatingActionButton) rootView.findViewById(R.id.access_information_previous_smoking_habits);

        goToForm = (Button) rootView.findViewById(R.id.go_to_form_button);
        buttonStartQuittingAttempt = (Button) rootView.findViewById(R.id.start_quitting_attempt_button);
        buttonEndQuittingAttempt = (RelativeLayout) rootView.findViewById(R.id.finish_quitting_attempt_layout);
        layoutGoToEditProfileDataDuringQuittingAttempt = (RelativeLayout)rootView.findViewById(R.id.edit_profile_in_quitting_attempt_access_layout);

        int colorFormFilled = getResources().getColor(R.color.colorAccent);
        int colorFormIncomplete = getResources().getColor(R.color.colorIncompleteForm);
        int colorFormDisabled = getResources().getColor(R.color.colorDivider);

        if(sessionData.isFilledPersonalData())
            selectPersonalDataFormInformation.setBackgroundTintList(ColorStateList.valueOf(colorFormFilled));
        else if(sessionData.isIncompletePersonalData())
            selectPersonalDataFormInformation.setBackgroundTintList(ColorStateList.valueOf(colorFormIncomplete));
        if(sessionData.isQuittingDateFilled()){
            selectFagerstromFormInformation.setBackgroundTintList(ColorStateList.valueOf(colorFormDisabled));
            selectRichmondFormInformation.setBackgroundTintList(ColorStateList.valueOf(colorFormDisabled));
            selectPreviousSmokingHabitsFormInformation.setBackgroundTintList(ColorStateList.valueOf(colorFormDisabled));
            (rootView.findViewById(R.id.edit_profile_cardview)).setVisibility(View.GONE);
            //(rootView.findViewById(R.id.end_quitting_attempt_layout)).setVisibility(View.VISIBLE);
        }else {
            (rootView.findViewById(R.id.start_quitting_attempt_layout)).setVisibility(View.VISIBLE);
            if (sessionData.isFilledFagerstromTest())
                selectFagerstromFormInformation.setBackgroundTintList(ColorStateList.valueOf(colorFormFilled));
            if (sessionData.isFilledRichmondTest())
                selectRichmondFormInformation.setBackgroundTintList(ColorStateList.valueOf(colorFormFilled));
            if(sessionData.isFilledPreviousSmokingHabits()){
                selectPreviousSmokingHabitsFormInformation.setBackgroundTintList(ColorStateList.valueOf(colorFormFilled));
            }
            if(!(sessionData.isFilledPersonalData() && sessionData.isFilledFagerstromTest() && sessionData.isFilledRichmondTest()))
                buttonStartQuittingAttempt.setBackgroundColor(colorFormDisabled);
        }

        if (sessionData.isQuittingDateFilled()){

            resumeName = (TextView) rootView.findViewById(R.id.text_view_name);
            genderAndAgeTexView = (TextView) rootView.findViewById(R.id.text_view_gender_and_age);
            resumeBirthday = (TextView) rootView.findViewById(R.id.text_view_birthdate);
            resumeEmployment = (TextView) rootView.findViewById(R.id.text_view_employment);
            resumeDateStartSmoking = (TextView) rootView.findViewById(R.id.text_view_date_start_smoking);
            cigarettesTextView = (TextView) rootView.findViewById(R.id.text_view_cigarettes);
            quittingDateTextView = (TextView) rootView.findViewById(R.id.text_view_quitting_date);

            Button buttonAccessToProfileExtendedData = (Button) rootView.findViewById(R.id.access_extended_profile_form_button);

            SFBPersonalData personalData;
            SFBSmokingData smokingData;

            try {
                CardView profileResume = (CardView) rootView.findViewById(R.id.profile_resume_cardview);
                profileResume.setVisibility(View.VISIBLE);

                personalData = sessionData.getPersonalData();
                smokingData = sessionData.getSmokingData(getContext());

                String name = personalData.getName();
                resumeName.setText(String.format(getString(R.string.single_field), name));
                String gender = personalData.getGender() == 'm' ? getString(R.string.gender_profile_resume_male) : getString(R.string.gender_profile_resume_female);

                genderAndAgeTexView.setText(String.format(getString(R.string.gender_age_formatted), gender, personalData.getCurrentAge()));

                resumeEmployment.setText(sessionData.getEmploymentStatus().equals("employed")? R.string.employed : R.string.unemployed);

                SimpleDateFormat dateFormat = new SimpleDateFormat();
                dateFormat.applyPattern("dd/MM");
                String birthday = dateFormat.format(personalData.getBirthDate().getTime());
                resumeBirthday.setText(String.format(getString(R.string.birthday_value), birthday));

                SimpleDateFormat dateFormat2 = new SimpleDateFormat();
                dateFormat2.applyPattern("dd/MM/yyyy");
                String dateStartSmoking = dateFormat2.format(smokingData.getDateStartingSmoking().getTime());
                resumeDateStartSmoking.setText(String.format(getString(R.string.start_smoking_date_value), dateStartSmoking));

                long end = sessionData.isQuittingDateFilled() ?
                        smokingData.getQuittingAttempts().get(smokingData.getQuittingAttempts().size()-1).getQuittingDate().getTimeInMillis() : Calendar.getInstance().getTimeInMillis();


                // EXTENDED FORM ACCESS BUTTON COLOR
                Drawable colorExtendedFormIncomplete = getResources().getDrawable(R.color.colorIncompleteForm);
                Drawable colorExtendedFormComplete = getResources().getDrawable(R.color.colorAccent);

                int extendedProfileFormCompletionState = sessionData.getExtendedProfileFormCompletionState();
                if(sessionData.getExtendedProfileFormCompletionState() == SessionData.extended_profile_form_completion_state_not_updated) {

                    Map<String, Boolean[]> responsesInDataBase = db.getAllExtendedFormResponses();
                    Boolean anyExtendedFormQuestionsWithAnswer = false;
                    Boolean allExtendedFormQuestionsWithAnswer = true;
                    for (Boolean[] e : responsesInDataBase.values()) {
                        anyExtendedFormQuestionsWithAnswer |= Arrays.asList(e).contains(true);
                        allExtendedFormQuestionsWithAnswer &= Arrays.asList(e).contains(true);
                    }
                    if (allExtendedFormQuestionsWithAnswer) {
                        buttonAccessToProfileExtendedData.setBackground(colorExtendedFormComplete);
                        sessionData.setExtendedProfileFormCompletionState(3);
                    } else if (anyExtendedFormQuestionsWithAnswer) {
                        buttonAccessToProfileExtendedData.setBackground(colorExtendedFormIncomplete);
                        sessionData.setExtendedProfileFormCompletionState(2);
                    } else {
                        sessionData.setExtendedProfileFormCompletionState(1);
                    }
                }else{
                    switch (extendedProfileFormCompletionState){
                        case 2:
                            buttonAccessToProfileExtendedData.setBackground(colorExtendedFormIncomplete);
                            break;
                        case 3:
                            buttonAccessToProfileExtendedData.setBackground(colorExtendedFormComplete);
                            break;
                        default:
                            break;
                    }
                }
                //// EXTENDED FORM ACCESS BUTTON COLOR END

                if (sessionData.isQuittingDateFilled()) {
                    expensesTextView = (TextView) rootView.findViewById(R.id.text_view_expenses);

                    List<SFBQuittingAttempt> quittingAttempts = smokingData.getQuittingAttempts();
                    int quittingAttemptsQuantity = quittingAttempts.size();
                    long start = smokingData.getDateStartingSmoking().getTimeInMillis();
                    long days = TimeUnit.MILLISECONDS.toDays(Math.abs(end - start));
                    long years = Math.abs(days / 365);

                    cigarettesTextView.setText(String.format(getString(R.string.daily_cigarettes_value),
                            Math.round(quittingAttempts.get(quittingAttemptsQuantity-1).getPreviousDailyCigarettes())));
                    expensesTextView.setText(String.format(getString(R.string.weekly_tobacco_expenditure_value),
                            Math.round(quittingAttempts.get(quittingAttemptsQuantity-1).getWeeklyTobaccoExpenditure()))
                            + " " + sessionData.getCurrency() + ".");
                    Float accumulatedCigarettes = days * quittingAttempts.get(quittingAttemptsQuantity-1).getPreviousDailyCigarettes();
                    Float accumulatedExpenses = (days / 7) * quittingAttempts.get(quittingAttemptsQuantity-1).getWeeklyTobaccoExpenditure();

                }
            } catch (Exception e) {

                e.printStackTrace();
            }

            try {
                smokingData = sessionData.getSmokingData(getContext());
                List<SFBQuittingAttempt> quittingAttempts = smokingData.getQuittingAttempts();
                int quittingAttemptsQuantity = quittingAttempts.size();
                SimpleDateFormat dateFormat = new SimpleDateFormat();
                dateFormat.applyPattern("dd/MM/yyyy");
                quittingDateTextView.setText(dateFormat.format(quittingAttempts.get(quittingAttemptsQuantity-1).getQuittingDate().getTime()));

                Calendar d = Calendar.getInstance();

                if (d.before(quittingAttempts.get(quittingAttemptsQuantity-1).getQuittingDate())) {
                    ((TextView) rootView.findViewById(R.id.quitting_title)).setText(R.string.future_quitting_attempt);
                    quittingDateTextView.setText(dateFormat.format(quittingAttempts.get(quittingAttemptsQuantity-1).getQuittingDate().getTime()));

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        ///BUTTON BEHAVIOURS

        //ACCESS TO Explanation about form and the button to go to this form

        View.OnClickListener accessToFormInformation = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int colorPrimary = getResources().getColor(R.color.colorPrimary);
                int colorTransparent = getResources().getColor(android.R.color.transparent);

                RelativeLayout selectFagerstromFormInformationBackground  = (RelativeLayout) rootView.findViewById(R.id.access_information_test_fagerstrom_background);
                RelativeLayout selectRichmondFormInformationBackground  = (RelativeLayout) rootView.findViewById(R.id.access_information_test_richmond_background);
                RelativeLayout selectPersonalDataFormInformationBackground  = (RelativeLayout) rootView.findViewById(R.id.access_information_personal_data_background);
                RelativeLayout  selectPreviousSmokingHabitsFormInformationBackground  = (RelativeLayout) rootView.findViewById(R.id.access_information_previous_smoking_habits_background);

                selectFagerstromFormInformationBackground.setBackgroundColor(colorTransparent);
                selectRichmondFormInformationBackground.setBackgroundColor(colorTransparent);
                selectPersonalDataFormInformationBackground.setBackgroundColor(colorTransparent);
                selectPreviousSmokingHabitsFormInformationBackground.setBackgroundColor(colorTransparent);

                TextView form_title = (TextView) rootView.findViewById(R.id.form_title);

                switch (v.getId()){
                    case R.id.access_information_test_fagerstrom:
                        selectFagerstromFormInformationBackground.setBackgroundColor(colorPrimary);
                        form_title.setText(R.string.fagerstrom_test_title);
                        formInformationSelected = fagerstromFormInformationTAG;
                        break;
                    case R.id.access_information_test_richmond:
                        selectRichmondFormInformationBackground.setBackgroundColor(colorPrimary);
                        form_title.setText(R.string.richmond_test_title);
                        formInformationSelected = richmondFormInformationTAG;
                        break;
                    case R.id.access_information_personal_data:
                        selectPersonalDataFormInformationBackground.setBackgroundColor(colorPrimary);
                        form_title.setText(R.string.personal_data);
                        formInformationSelected = personalDataFormInformationTAG;
                        break;
                    case R.id.access_information_previous_smoking_habits:
                        selectPreviousSmokingHabitsFormInformationBackground.setBackgroundColor(colorPrimary);
                        form_title.setText(R.string.previous_smoking_habits_form_title);
                        formInformationSelected = previousSmokingHabitsFormInformationTAG;
                        break;
                    default:
                        break;
                }
            }
        };

        selectFagerstromFormInformation.setOnClickListener(accessToFormInformation);
        selectRichmondFormInformation.setOnClickListener(accessToFormInformation);
        selectPersonalDataFormInformation.setOnClickListener(accessToFormInformation);
        selectPreviousSmokingHabitsFormInformation.setOnClickListener(accessToFormInformation);

        // GO TO selected form

        goToForm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (formInformationSelected){
                    case fagerstromFormInformationTAG:
                        if(sessionData.isQuittingDateFilled()){
                            toast = Toast.makeText(getContext(), R.string.cannot_edit_smoking, Toast.LENGTH_SHORT);
                            toast.show();
                        }else
                            mListener.goToTestFagerstrom();
                        break;
                    case richmondFormInformationTAG:
                        if(sessionData.isQuittingDateFilled()){
                            toast = Toast.makeText(getContext(), R.string.cannot_edit_smoking, Toast.LENGTH_SHORT);
                            toast.show();
                        }else
                            mListener.goToTestRichmond();
                        break;
                    case personalDataFormInformationTAG:
                        mListener.goToEditPersonalDataForm();
                        break;
                    case previousSmokingHabitsFormInformationTAG:
                        if(sessionData.isQuittingDateFilled()){
                            toast = Toast.makeText(getContext(), R.string.cannot_edit_smoking, Toast.LENGTH_SHORT);
                            toast.show();
                        }else
                            mListener.goToPreviousSmokingHabitsForm();
                        break;
                    default:
                        break;
                }
            }
        });


        // CHECK FOR the user have filled a quitting . If it is false and personal data is filled too,
        //   GO TO addQuittingPerdiod form using a custom DialogFragment

        buttonStartQuittingAttempt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!sessionData.isQuittingDateFilled()) {
                        if (sessionData.isDataForBeginTreatmentCompleted()) {

                            mListener.goToQuittingAttemptDateForm();

                        } else {
                            toast = Toast.makeText(getContext(), R.string.must_fill_data_test, Toast.LENGTH_SHORT);
                            toast.show();
                        }
                    }
                }
        });

        // CHECK FOR the user have filled a quitting attempt. If it is true, GO TO add EndDateQuittingAttempt
        // dialog
        buttonEndQuittingAttempt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sessionData.isQuittingDateFilled()){
                    //TODO this dialog invoked should be modified to ask the real end quitting attempt date
                    //Alert message: treatment data will be erased
                    AlertDialog alert = resetStartTreatmentDateDialog();
                    alert.show();
                }
            }
        });

        layoutGoToEditProfileDataDuringQuittingAttempt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.goToEditPersonalDataForm();
            }
        });

        Button buttonAccessToProfileExtendedData = (Button) rootView.findViewById(R.id.access_extended_profile_form_button);

        buttonAccessToProfileExtendedData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), ExtendedProfileFormActivity.class));
            }
        });


        return rootView;

    }

    private AlertDialog resetStartTreatmentDateDialog() {

        //Params for analytical purpose

        final String[] section_name = {""};
        final String date = (new SimpleDateFormat("yyyy-MM-dd")).format(Calendar.getInstance().getTime());
        final String time = (new SimpleDateFormat("HH:mm:ss.SSS")).format(Calendar.getInstance().getTime());
        final Float init = Long.valueOf(System.nanoTime()/1000000).floatValue();

        // Basic AlertDialog.
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setTitle(R.string.finish_quitting_attempt)
                .setMessage(R.string.finish_attempt_text)
                .setPositiveButton(R.string.ok,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) { // Case positive: finish quitting attempt. This action is registered for analytical purpose
                                section_name[0] = SFBConstantsAndCodes.ANALYTIC_SECTION_END_QUITTING_ATTEMPT_CONFIRMED;
                                mFinQuitAttempt = new FinishQuittingAttemptTask(
                                        UserProfileDataFragment.this.getContext());
                                mFinQuitAttempt.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
                            }
                        })
                .setNegativeButton(R.string.cancel_form,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) { // The user continues the quitting attempt. This action is registered
                                section_name[0] = SFBConstantsAndCodes.ANALYTIC_SECTION_END_QUITTING_ATTEMPT_CANCELLED;
                            }
                        })
        .setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) { // Store interaction in database
                Float fin = Long.valueOf(System.nanoTime()/1000000).floatValue();
                SFBAppInteractionAnalytic SFBAppInteractionAnalytic = new SFBAppInteractionAnalytic(section_name[0], date, time, (fin-init));
                db.insertAppInteraction(SFBAppInteractionAnalytic);
            }
        });

        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnPersonalDataFragmentInteractionListener) {
            mListener = (OnPersonalDataFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnPersonalDataInteractionListener");
        }
        section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_PRACTICE;

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        mListener.onPersonalDataFragmentInteraction(null);
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnPersonalDataFragmentInteractionListener {
        void onPersonalDataFragmentInteraction(Uri uri);

        void goToEditPersonalDataForm();
        void goToTestRichmond();
        void goToTestFagerstrom();
        void goToPreviousSmokingHabitsForm();
        void goToQuittingAttemptDateForm();
        void refreshPersonalDataSection();

        // TODO May this can be reused to request a quitting attempt end date to the user.
        void setDateInDatePicker(int id, String title);

    }

    private class FinishQuittingAttemptTask extends AsyncTask<Void, Void, Boolean> {

        private final Context mContext;
        private Integer failCode;
        private ProgressDialog mProgressDialog;
        private final int CODE_NO_FAILS = 0;

        private final int CODE_ERROR_INTERNET_CONNECTION = 4;
        private final int CODE_ERROR_NOT_STORED = 6;

        FinishQuittingAttemptTask(Context context) {
            mContext = context;
            failCode = CODE_NO_FAILS;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {

            Boolean everythingCorrect = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();

            // Check if exists an internet connection
            if (XMLHttpPost.isConnectedToInternet(UserProfileDataFragment.this.getContext())) {
                // SEND HTTP POST REQUEST
                String responseXML = null;
                // Create the specific xml request. This don't need values.
                String fileXMLRequest = file.finishQuittingAttempt(SFBDate.dateToString(Calendar.getInstance()));
                try {
                    //Introduce XML and catch server response
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, getContext(),
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    getContext()).getUserCredentials()) );

                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }

                everythingCorrect = responseXML == "created";
                if(!everythingCorrect)
                    failCode = CODE_ERROR_NOT_STORED;

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }

            return everythingCorrect;
        }
        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog = new ProgressDialog(mContext);
                mProgressDialog.setMessage(getString(R.string.checking_user));
                mProgressDialog.setCancelable(false);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mFinQuitAttempt = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (success) { // Data saved in server: stop quitting attempt and alert to the user
                sessionData.resetTreatmentData();
                db.deleteBadges();
                toast = Toast.makeText(getContext(), R.string.quitting_attempt_finished, Toast.LENGTH_SHORT);
                toast.show();
                mListener.refreshPersonalDataSection(); // Refresh information on fragment
            } else { // Data not saved in server: it is not possible stop quitting attempt and alert to the user with
                // the specific issue information
                String errorMessage = "Error";
                switch (failCode) {
                    case CODE_ERROR_NOT_STORED:
                        errorMessage = getString(R.string.conection_server_problem);
                        Snackbar.make(rootView.findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    case CODE_ERROR_INTERNET_CONNECTION:
                        errorMessage = getString(R.string.error_internet_connection);
                        Snackbar.make(rootView.findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    default:
                        Snackbar.make(rootView.findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                }
            }
        }

        @Override
        protected void onCancelled() {
            mFinQuitAttempt = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}
