package com.salumedia.quitandreturn.views.forms;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.SFBFragment;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;


/**
 * Created by Francisco on 28/4/17.
 */

/**
 * A fragment that shows the start quitting period form
 */
public class PreviousSmokingHabitsFormFragment extends SFBFragment {

    // Tag used to identify the fragment and for analytical purpose
    public static final String TAG = "PREVIOUS_SMOKING_HABITS_FORM";

    // Form fields
    EditText dailyCigarettes;
    EditText weeklyExpenditure;
    Spinner currency;

    // Access to shared preferences
    SessionData sessionData;

    // Auxiliary view to inflate the fragment. It is used in auxiliary methods, so it is set as an
    // attribute of the class
    View rootView;

    // Default necessary constructor
    public PreviousSmokingHabitsFormFragment() {
    }

    // Constructor that allow receive information from the invoking class
    public static PreviousSmokingHabitsFormFragment newInstance(Bundle arguments){

        PreviousSmokingHabitsFormFragment f =  new PreviousSmokingHabitsFormFragment();
        //Extract information if exists
        if(arguments != null){
            f.setArguments(arguments);
        }
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Not View attributes instantiation
        section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_PREVIOUS_SMOKING_HABITS_FORM; // Analysis purpose
        sessionData = SessionData.getSessionData(getContext()); // Shared preferences access
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Inflating the dialog fragment
        rootView = inflater.inflate(R.layout.form_fragment_previous_smoking_habits, null);

        // View attributes instantiation
        dailyCigarettes = (EditText) rootView.findViewById(R.id.daily_cigarettes);
        weeklyExpenditure = (EditText) rootView.findViewById(R.id.weekly_expenditure);
        currency = (Spinner) rootView.findViewById(R.id.currency);

        //Adapter used to create the currency spinner
        ArrayAdapter<CharSequence> currencyAdapter = ArrayAdapter.createFromResource(getActivity(),
                R.array.currency, android.R.layout.simple_spinner_item);
        currencyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        currency.setAdapter(currencyAdapter);

        if(!sessionData.getPreviousDailyCigarettes().equals(0f))
            dailyCigarettes.setText(String.valueOf(Math.round(sessionData.getPreviousDailyCigarettes())));
        if(!sessionData.getWeeklyTobaccoExpenditure().equals(0f)) {
            weeklyExpenditure.setText(String.valueOf(Math.round(sessionData.getWeeklyTobaccoExpenditure())));

            String savedCurrency = sessionData.getCurrency(); //the value you want the position for
            int spinnerPosition = currencyAdapter.getPosition(savedCurrency);
            currency.setSelection(spinnerPosition);
        }

        View.OnFocusChangeListener resetColor = new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                Drawable correctFieldDrawable = getResources().getDrawable(R.drawable.text_field);
                v.setBackgroundDrawable(correctFieldDrawable);
            }
        };

        dailyCigarettes.setOnFocusChangeListener(resetColor);
        weeklyExpenditure.setOnFocusChangeListener(resetColor);

        // This allow hide the window keyboard when is touched other place of the screen
        rootView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                InputMethodManager inputMethodManager =
                        (InputMethodManager)getActivity().getSystemService(FragmentActivity.INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(v.getWindowToken(), 0);
                return true;
            }
        });

        return rootView;
    }
}
