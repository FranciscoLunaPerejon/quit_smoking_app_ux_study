package com.salumedia.quitandreturn.utils;


import com.salumedia.quitandreturn.R;

/**
 * Created by joaquin on 16/6/16.
 */
public final class SFBConstantsAndCodes {

    /**
     * Metrics
     */

    /* These are the section names used with the fragments that extends of SFBFragment with analysis
        purpose. Others fragments,like BenefistFragment, Helping, etc., that are in tabs, have
        special analysis because at least 2 sections are started at the same time with tabs views,
        and it's more difficult to analyse which section are currently seeing the user.
    */
    public static final String ANALYTIC_SECTION_PERSONAL_DATA = "PERSONAL_DATA";
    public static final String ANALYTIC_SECTION_PERSONAL_DATA_FORM = "PERSONAL_FORM";
    public static final String ANALYTIC_SECTION_TEST_RICMOND_FORM = "RICMOND_FORM";
    public static final String ANALYTIC_SECTION_PREVIOUS_SMOKING_HABITS_FORM = "PREVIOUS_SMOKING_HABITS_FORM";
    public static final String ANALYTIC_SECTION_TEST_FAGERSTROM_FORM = "FAGERSTROM_FORM";
    public static final String ANALYTIC_SECTION_TEST_WEEK_DAYS_PREFERENCES_FORM = "WEEK_DAYS_PREFERENCES_FORM";
    public static final String ANALYTIC_SECTION_ADD_QUITTING_ATTEMPT = "ADD_QUITTING_ATTEMPT";
    public static final String ANALYTIC_SECTION_END_QUITTING_ATTEMPT_CONFIRMED = "END_QUITTING_ATTEMPT_CONFIRM";
    public static final String ANALYTIC_SECTION_END_QUITTING_ATTEMPT_CANCELLED = "END_QUITTING_ATTEMPT_CANCELLED";
    public static final String ANALYTIC_SECTION_PREFERENCES = "PREFERENCES";
    public static final String ANALYTIC_SECTION_PRACTICE = "BEGIN_RELAXATION";
    public static final String ANALYTIC_SECTION_ABOUT = "ABOUT";
    public static final String ANALYTIC_SECTION_TEST_CIGARETTES_CONSUMED_QUESTION = "CIGARETTES_CONSUMED_QUESTION";
    public static final String ANALYTIC_SECTION_TEST_MESSAGES_FREQUENCY_QUESTION = "MESSAGES_FREQUENCY_QUESTION";
    public static final String ANALYTIC_SECTION_MINIGAMES = "MINIGAMES_MENU";
    public static final String ANALYTIC_SECTION_GAME_WHACK_MOLES = "GAME_WHACK_MOLES";
    public static final String ANALYTIC_SECTION_GAME_BLOW_BALLOONS = "GAME_BLOW_BALLOONS";
    public static final String ANALYTIC_SECTION_GAME_PHYSICAL_EXERCISES = "GAME_PHYSICAL_EXERCISES";

    // Flurry analytics codes

    public static final String ANALYTIC_SECTION_LOG_TIME = "time spent in section";
    public static final String ANALYTIC_SECTION = "section";

    /**
     * Facebook group url
     */
    public static final String FACEBOOK_GROUP_URL = "https://www.facebook.com/groups/1113294622124655/";
    public static final String FACEBOOK_PACKAGE_NAME = "com.facebook.katana";
    public static final String FACEBOOK_MODAL_URL_SCHEME = "fb://facewebmodal/f?href=";

    /**
     * Notifications
     */
    public static final String NOTIFICATION_TITLE_KEY = "title";
    public static final String NOTIFICATION_MESSAGE_KEY = "message";
    public static final String NOTIFICATION_TYPE_KEY = "type";
    public static final String NOTIFICATION_REQUEST_CODE_KEY = "requestCode";
    public static final String NOTIFICATION_DRAWABLE_CODE_KEY = "drawableCode";
    public static final String NOTIFICATION_USER_NAME_CODE_KEY = "userNameCode";
    public static final String NOTIFICATION_USER_ID_CODE_KEY = "userIdCode";
    public static final String NOTIFICATION_URL_PHOTO_CODE_KEY = "photoURL";

    public static final int NOTIFICATION_TYPE_SAVINGS = 0;
    public static final int NOTIFICATION_TYPE_SMOKEFREE = 1;
    public static final int NOTIFICATION_TYPE_HOURS_REGAINED = 2;
    public static final int NOTIFICATION_TYPE_CIGARETTES_NOT_SMOKED = 3;
    public static final int NOTIFICATION_TYPE_OTHER = 4;
    public static final int NOTIFICATION_TYPE_CRAVING = 5;
    public static final int NOTIFICATION_TYPE_MESSAGE_FROM_SERVER = 6;
    public static final int NOTIFICATION_TYPE_MOTIVATIONAL_MESSAGE_FROM_SERVER = 7;
    public static final int NOTIFICATION_TYPE_FOLLOW_UP = 8;
    public static final int NOTIFICATION_TYPE_INFORMATION = 9;

    /**
     * User constants
     */
    public static final String USER_GENDER_MALE = "hombre";
    public static final String USER_GENDER_FEMALE = "mujer";


    /**
     * Permissions
     */

    public static final Integer CODE_MUTE_NOTIFICATIONS_CANCELLED = 0;
    public static final Integer CODE_MUTE_NOTIFICATIONS_8_HOURS = 1;
    public static final Integer CODE_MUTE_NOTIFICATIONS_1_DAY = 2;
    public static final Integer CODE_MUTE_NOTIFICATIONS_1_WEEK = 3;

    /**
     * Badges
     */
    public static final String NOTIFICATION_INTERNAL_BADGE = "internalBadge";

    public static final String BADGE_SAVINGS = "savings";
    public static final String BADGE_SMOKE_FREE = "smokeFree";
    public static final String BADGE_HOURS_REGAINED = "hoursRegained";
    public static final String BADGE_CIGARETTES = "cigarettes";
    public static final String BADGE_OTHER = "other";
    public static final Integer BADGE_ACHIEVED = 1;
    public static final Integer BADGE_NOT_ACHIEVED = 0;
    public static final int[] SAVINGS_DRAWABLES = {
            R.drawable.badge_savings_00,
            R.drawable.badge_savings_01,
            R.drawable.badge_savings_02,
            R.drawable.badge_savings_03,
            R.drawable.badge_savings_04,
            R.drawable.badge_savings_05,
            R.drawable.badge_savings_06,
            R.drawable.badge_savings_07,
            R.drawable.badge_savings_08,
            R.drawable.badge_savings_09,
            R.drawable.badge_savings_10,
            R.drawable.badge_savings_11,
            R.drawable.badge_savings_12,
            R.drawable.badge_savings_13
    };

    public static final int[] SMOKE_FREE_DRAWABLES = {
            R.drawable.badge_smoke_free_00,
            R.drawable.badge_smoke_free_01,
            R.drawable.badge_smoke_free_02,
            R.drawable.badge_smoke_free_03,
            R.drawable.badge_smoke_free_04,
            R.drawable.badge_smoke_free_05,
            R.drawable.badge_smoke_free_06,
            R.drawable.badge_smoke_free_07,
            R.drawable.badge_smoke_free_08,
            R.drawable.badge_smoke_free_09,
            R.drawable.badge_smoke_free_10,
            R.drawable.badge_smoke_free_11,
            R.drawable.badge_smoke_free_12,
            R.drawable.badge_smoke_free_13,
            R.drawable.badge_smoke_free_14,
            R.drawable.badge_smoke_free_15,
            R.drawable.badge_smoke_free_16,
            R.drawable.badge_smoke_free_17,
            R.drawable.badge_smoke_free_18,
            R.drawable.badge_smoke_free_19,
            R.drawable.badge_smoke_free_20,
            R.drawable.badge_smoke_free_21,
            R.drawable.badge_smoke_free_22
    };

    public static final int[] HOURS_REGAINED_DRAWABLES = {
            R.drawable.badge_hours_regained_00,
            R.drawable.badge_hours_regained_01,
            R.drawable.badge_hours_regained_02,
            R.drawable.badge_hours_regained_03,
            R.drawable.badge_hours_regained_04,
            R.drawable.badge_hours_regained_05,
            R.drawable.badge_hours_regained_06,
    };
    public static final int[] CIGARETTES_DRAWABLES = {
            R.drawable.badge_not_smoke_00,
            R.drawable.badge_not_smoke_01,
            R.drawable.badge_not_smoke_02,
            R.drawable.badge_not_smoke_03,
            R.drawable.badge_not_smoke_04,
            R.drawable.badge_not_smoke_05,
            R.drawable.badge_not_smoke_06,
            R.drawable.badge_not_smoke_07,
            R.drawable.badge_not_smoke_08,
            R.drawable.badge_not_smoke_09
    };
    public static final int[] OTHER_DRAWABLES = {
            R.drawable.email,
            R.drawable.email,
            R.drawable.email,
            R.drawable.email,
            R.drawable.email,
            R.drawable.email,
            R.drawable.email,
            R.drawable.email
    };

    public static final int SELECTED_NOTIFICATION = 0;
    public static final int PREVIOUS_NOTIFICATION = 1;

    public static final boolean BEGIN = true;
    public static final boolean END = false;
    public static final String INTERVAL = "interval";


    /**
     * Fragments-SFBTestForm id codes
     */

    public static final int SIGN_UP_FORM_ID = 0;
    public static final int SIGN_UP_FORM_CONFIRMATION_ID = 1;
    public static final int PERSONAL_DATA_FORM_ID = 2;
    public static final int RICHMOND_TEST_FORM_ID = 3;
    public static final int FAGERSTROM_TEST_FORM_ID = 4;
    public static final int PREVIOUS_SMOKING_HABITS_ID = 5;
    public static final int WEEK_DAYS_PREFERENCES_ID = 6;
    public static final int START_QUITTING_ATTEMPT_ID = 7;


    /**
     * Questions-CasualQuestions id codes
     */
    public static final int SMOKEFREE_QUESTION_ID = 1;
    public static final int MESSAGES_FREQUENCY_QUESTION_ID = 2;


    /**
     * Questions-CasualQuestions id for Notifications of Casual Questions
     */
    public static final int SMOKEFREE_QUESTION_NOTIFICATION_BOX_ID = 1;
    public static final int MESSAGES_FREQUENCY_QUESTION_NOTIFICATION_BOX_ID = 2;


}