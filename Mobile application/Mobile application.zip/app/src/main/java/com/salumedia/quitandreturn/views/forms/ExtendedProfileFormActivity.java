package com.salumedia.quitandreturn.views.forms;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.adapters.ExtendedProfileFormQuestionAdapter;
import com.salumedia.quitandreturn.model.SFBAppInteractionAnalytic;
import com.salumedia.quitandreturn.model.SFBExtendedProfileFormQuestion;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.XMLHttpPost;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.SFBAnalytics;
import com.salumedia.quitandreturn.utils.SFBEncode;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;


/**
 * Created by Francisco on 16/6/17.
 */

public class ExtendedProfileFormActivity extends AppCompatActivity {


    public static final String RATING_BAR_QUESTION_KEY = "rating";
    public static final String RADIO_BUTTON_QUESTION_KEY = "oneOption";
    public static final String CHECK_BOX_QUESTION_KEY = "multipleOption";


    // The analysis record the section name, date and time of accessing, and accessing duration
    public String section_name = "EXTENDED_FORM";
    public String date;
    public String time;
    public Float init;


    Toolbar toolbar;

    // Session information
    SessionData sessionData;
    LocalDataBaseHelper db;


    // Views

    RecyclerView listOfQuestionsView;

    ArrayList<SFBExtendedProfileFormQuestion> listOfQuestions;

    SendExtendedFormTask mSendExtendedFormTask = null;


    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sessionData = SessionData.getSessionData(getApplicationContext());

        db = new LocalDataBaseHelper(ExtendedProfileFormActivity.this);

        setContentView(R.layout.activity_extended_form);

        toolbar = (Toolbar) findViewById(R.id.toolbar);

        //This button have a "check and save" purpose, depending of form-fragment that contains the activity
        Button saveButton = (Button) findViewById(R.id.button2_toolbar);

        toolbar.setNavigationIcon(R.drawable.ic_go_back);
        toolbar.setTitle(R.string.extended_profile_form_title);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();
            }
        });

        View.OnClickListener onClickSaveFormButtonListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSendExtendedFormTask = new SendExtendedFormTask(listOfQuestions, ExtendedProfileFormActivity.this);
                mSendExtendedFormTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
            }
        };

        saveButton.setVisibility(View.VISIBLE);
        saveButton.setOnClickListener(onClickSaveFormButtonListener);


        listOfQuestions = createListOfExtendedFormQuestions();

        listOfQuestionsView = (RecyclerView) findViewById(R.id.list_of_questions_recyclerView);

        listOfQuestionsView.setHasFixedSize(true);
        listOfQuestionsView.setItemViewCacheSize(db.getAllExtendedFormResponses().size());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        listOfQuestionsView.setLayoutManager(layoutManager);

        ExtendedProfileFormQuestionAdapter extendedProfileFormQuestionAdapter =
                new ExtendedProfileFormQuestionAdapter(ExtendedProfileFormActivity.this, listOfQuestions);

        listOfQuestionsView.setAdapter(extendedProfileFormQuestionAdapter);


    }

    @Override
    protected void onResume() {
        inizializeAnalyticData();
        super.onResume();
    }

    @Override
    protected void onPause() {
        finalizeAndSendAnalyticData();
        super.onPause();
    }

    private ArrayList<SFBExtendedProfileFormQuestion> createListOfExtendedFormQuestions() {

        ArrayList<SFBExtendedProfileFormQuestion> resListOfQuestions = new ArrayList<>();

        int tagReferenceID = 0;
        int typeReferencesID = 1;
        int titleReferencesID = 2;
        int descriptionReferencesID = 3;
        int numberOfAnswersReferencesID = 4;
        int answersReferenceReferencesID = 5;

        Resources resources = getResources();
        TypedArray extendedFormQuestionsReferences = resources.obtainTypedArray(R.array.extended_form_questions);

        int questionTagsID = extendedFormQuestionsReferences.getResourceId(tagReferenceID, 0);
        @SuppressWarnings("ResourceType") int questionTypeID = extendedFormQuestionsReferences.getResourceId(typeReferencesID, 0);
        @SuppressWarnings("ResourceType") int questionTitleID = extendedFormQuestionsReferences.getResourceId(titleReferencesID, 0);
        @SuppressWarnings("ResourceType") int questionDescriptionID = extendedFormQuestionsReferences.getResourceId(descriptionReferencesID, 0);
        @SuppressWarnings("ResourceType") int questionNumberOfAnswersID = extendedFormQuestionsReferences.getResourceId(numberOfAnswersReferencesID, 0);
        @SuppressWarnings("ResourceType") int questionAnswerReferenceID = extendedFormQuestionsReferences.getResourceId(answersReferenceReferencesID, 0);

        if (questionTagsID > 0 && questionTypeID > 0 && questionTitleID > 0 && questionDescriptionID > 0 && questionNumberOfAnswersID > 0 && questionAnswerReferenceID > 0) {
            String[] questionTags = resources.getStringArray(questionTagsID);
            String[] questionType = resources.getStringArray(questionTypeID);
            String[] questionTitle = resources.getStringArray(questionTitleID);
            String[] questionDescription = resources.getStringArray(questionDescriptionID);
            int[] questionNumberOfAnswers = resources.getIntArray(questionNumberOfAnswersID);
            TypedArray questionAnswerReferences = resources.obtainTypedArray(questionAnswerReferenceID);

            Map<String, Boolean[]> responsesInDataBase = db.getAllExtendedFormResponses();


            for (int i = 0; i < questionTags.length; i++) {

                int answersID = questionAnswerReferences.getResourceId(i, 0);
                if (answersID > 0) {
                    String[] answersTexts = resources.getStringArray(answersID);

                    resListOfQuestions.add(SFBExtendedProfileFormQuestion.newInstance(questionTags[i],
                            questionTitle[i], questionDescription[i], questionType[i],
                            questionNumberOfAnswers[i], answersTexts,
                            responsesInDataBase.get(questionTags[i])));
                }
            }
            questionAnswerReferences.recycle();
        }
        extendedFormQuestionsReferences.recycle();

        return resListOfQuestions;
    }


    private void inizializeAnalyticData() {
        init = Long.valueOf(System.nanoTime() / 1000000).floatValue();
        Calendar currentTime = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        date = sdf.format(currentTime.getTime());
        SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss.SSS");
        time = sdf2.format(currentTime.getTime());

        try {
            SFBAnalytics.startLogTimeInSection(section_name +
                    "_author:" + SessionData.getSessionData(this).getUserData(this).getUserId() +
                    "_date:" + date + " " + time);
        } catch (Exception e) {
            SFBAnalytics.startLogTimeInSection(section_name + "_author:NOT_AVAILABLE" +
                    "_date:" + date + " " + time);
        }
    }

    private void finalizeAndSendAnalyticData() {
        Float fin = Long.valueOf(System.nanoTime() / 1000000).floatValue();
        SFBAppInteractionAnalytic SFBAppInteractionAnalytic = new SFBAppInteractionAnalytic(section_name, date, time, (fin - init));
        db.insertAppInteraction(SFBAppInteractionAnalytic);
        try {
            SFBAnalytics.stopLogTimeInSection(section_name +
                    "_author:" + SessionData.getSessionData(this).getUserData(this).getUserId() +
                    "_date:" + date + " " + time);

        } catch (Exception e) {
            SFBAnalytics.stopLogTimeInSection(section_name + "_author:NOT_AVAILABLE" +
                    "_date:" + date + " " + time);
        }
        SFBAnalytics.stopLogTimeInSection(section_name);
    }

    /**
     * An {@link AsyncTask} to send to the server a recover-account request by reset the password.
     */
    public class SendExtendedFormTask extends AsyncTask<Void, Void, Boolean> {

        private final ArrayList<SFBExtendedProfileFormQuestion> listQuestions;
        private final Context mContext;
        private Integer failCode;
        private ProgressDialog mProgressDialog;
        private final int CODE_NO_FAILS = 0;
        private final int CODE_ERROR_INVALID_DATA = 3;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;

        SendExtendedFormTask(ArrayList<SFBExtendedProfileFormQuestion> listQuestions, Context context) {
            this.listQuestions = listQuestions;
            mContext = context;
            failCode = CODE_NO_FAILS;
        }


        @Override
        protected Boolean doInBackground(Void... voids) {
            // Attempt authentication against a network service.
            /**
             * create xml file
             * string xml request with user in md5
             *
             * check connectivity
             */

            Boolean dataSavedInServer = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();
            //String fileXMLRequest = file.getAllDataRequest(mUserId, SFBEncode.encodeToMD5(mPassword));//file.getAllDataRequest(mUserId); //SFBEncode.encodeToMD5(mUserId), token

            if (XMLHttpPost.isConnectedToInternet(ExtendedProfileFormActivity.this)) {

                String fileXMLRequest = file.setExtendedProfile(listQuestions);

                // ENVIAR PETICIÓN HTTP POST
                String responseXML = null;

                try {
                    //Introduces XML y devuelve respuesta del servidor
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, getApplicationContext(),
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    getApplicationContext()).getUserCredentials()));


                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }

                dataSavedInServer = responseXML == "created";
                if (!dataSavedInServer)
                    failCode = CODE_ERROR_INVALID_DATA;

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }

            return dataSavedInServer;
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog = new ProgressDialog(mContext);
                mProgressDialog.setMessage(getString(R.string.checking_user));
                mProgressDialog.setCancelable(false);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (success) {
                saveQuestionAnswersOnDatabase();

                String alertTreatmentStarted = getString(R.string.data_saved_correctly);
                sessionData.setExtendedProfileFormCompletionState(SessionData.extended_profile_form_completion_state_not_updated);
                Toast toast = Toast.makeText(mContext, alertTreatmentStarted, Toast.LENGTH_SHORT);
                toast.show();
            } else {
                String errorMessage = "Error";
                switch (failCode) {
                    case CODE_ERROR_INVALID_DATA:
                        errorMessage = getString(R.string.error_data_not_stored);
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    case CODE_ERROR_INTERNET_CONNECTION:
                        errorMessage = getString(R.string.error_internet_connection);
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                    default:
                        Snackbar.make(findViewById(android.R.id.content), errorMessage, Snackbar.LENGTH_LONG)
                                .show();
                        break;
                }
            }
        }

        @Override
        protected void onCancelled() {
            mSendExtendedFormTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void saveQuestionAnswersOnDatabase() {
            for (SFBExtendedProfileFormQuestion question : listOfQuestions) {
                db.updateExtendedFormQuestionAnswer(question.getQuestionTag(), question.getAnswerResponses());
            }
        }
    }


}
