package com.salumedia.quitandreturn.model;

import java.util.Calendar;

/**
 * Created by Francisco on 10/3/17.
 */

/**
 * An SFBQuittingAttempt contains information as the start date, the previous smoking habits and the
 * motivation and addiction level by the user of a specific quitting smoking period.
 */
public class SFBQuittingAttempt {

    private Float previousDailyCigarettes;
    private Float weeklyTobaccoExpenditure;
    private String currency;
    private Calendar quittingDate;
    private Calendar quittingEndDate;
    private Integer fagerstromTestResult;
    private Integer richmondTestResult;


    public static SFBQuittingAttempt getInstance(){
        return new SFBQuittingAttempt();
    }

    public static SFBQuittingAttempt getInstance(Float previousDailyCigarettes, Float weeklyTobaccoExpenditure,
                                                 String currency, Calendar quittingDate, Calendar quittingEndDate,
                                                 Integer fagerstromTestResult, Integer richmondTestResult){
        if(quittingEndDate ==null){
            return new SFBQuittingAttempt(previousDailyCigarettes, weeklyTobaccoExpenditure, currency,
                    quittingDate, fagerstromTestResult, richmondTestResult);
        }
        else{
            return new SFBQuittingAttempt(previousDailyCigarettes, weeklyTobaccoExpenditure, currency,
                    quittingDate, quittingEndDate,fagerstromTestResult, richmondTestResult);
        }
    }

    private SFBQuittingAttempt(){

    }

    private SFBQuittingAttempt(Float previousDailyCigarettes, Float weeklyTobaccoExpenditure,
                               String currency, Calendar quittingDate,
                               Integer fagerstromTestResult, Integer richmondTestResult) {
        this.previousDailyCigarettes = previousDailyCigarettes;
        this.weeklyTobaccoExpenditure = weeklyTobaccoExpenditure;
        this.currency = currency;
        this.quittingDate = quittingDate;
        this.quittingDate.add(Calendar.HOUR_OF_DAY, 04);
        this.quittingDate.add(Calendar.MINUTE, 00);
        this.fagerstromTestResult = fagerstromTestResult;
        this.richmondTestResult = richmondTestResult;

    }

    private SFBQuittingAttempt(Float previousDailyCigarettes, Float weeklyTobaccoExpenditure,
                               String currency, Calendar quittingDate, Calendar quittingEndDate,
                               Integer fagerstromTestResult, Integer richmondTestResult) {
        this.previousDailyCigarettes = previousDailyCigarettes;
        this.weeklyTobaccoExpenditure = weeklyTobaccoExpenditure;
        this.currency = currency;
        this.quittingDate = quittingDate;
        this.quittingDate.add(Calendar.HOUR_OF_DAY, 04);
        this.quittingDate.add(Calendar.MINUTE, 00);
        this.quittingEndDate = quittingEndDate;
        this.quittingEndDate.add(Calendar.HOUR_OF_DAY, 04);
        this.quittingEndDate.add(Calendar.MINUTE, 00);
        this.fagerstromTestResult = fagerstromTestResult;
        this.richmondTestResult = richmondTestResult;

    }

    public Float getPreviousDailyCigarettes() {
        return previousDailyCigarettes;
    }

    public Float getWeeklyTobaccoExpenditure() {
        return weeklyTobaccoExpenditure;
    }

    public Calendar getQuittingDate() {
        return quittingDate;
    }

    public Calendar getQuittingEndDate() {
        return quittingEndDate;
    }

    public Integer getFagerstromTestResult() {
        return fagerstromTestResult;
    }
    public Integer getRichmondTestResult() {
        return richmondTestResult;
    }

    public void setPreviousDailyCigarettes(Float previousDailyCigarettes) {
        this.previousDailyCigarettes = previousDailyCigarettes;
    }

    public void setWeeklyTobaccoExpenditure(Float weeklyTobaccoExpenditure) {
        this.weeklyTobaccoExpenditure = weeklyTobaccoExpenditure;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setQuittingDate(Calendar quittingDate) {
        this.quittingDate = quittingDate;
    }

    public void setQuittingEndDate(Calendar quittingEndDate) {
        this.quittingEndDate = quittingEndDate;
    }

    public void setFagerstromTestResult(Integer fagerstromTestResult) {
        this.fagerstromTestResult = fagerstromTestResult;
    }

    public void setRichmondTestResult(Integer richmondTestResult) {
        this.richmondTestResult = richmondTestResult;
    }

    @Override
    public String toString() {
        return "SFBQuittingAttempt{" +
                "previousDailyCigarettes=" + previousDailyCigarettes +
                ", weeklyTobaccoExpenditure=" + weeklyTobaccoExpenditure +
                ", currency='" + currency + '\'' +
                ", quittingDate=" + quittingDate +
                ", quittingEndDate=" + quittingEndDate +
                ", fagerstromTestResult=" + fagerstromTestResult +
                ", richmondTestResult=" + richmondTestResult +
                '}';
    }
}
