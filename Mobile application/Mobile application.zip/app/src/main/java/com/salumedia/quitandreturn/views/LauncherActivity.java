package com.salumedia.quitandreturn.views;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.firebase.iid.FirebaseInstanceId;
import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.MyFirebaseMessagingService;
import com.salumedia.quitandreturn.session.server.XMLHttpPost;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.Timer;
import java.util.TimerTask;



/**
 * Created by Francisco on 28/12/16.
 */

/**
 * This class shows the first screen when the app is launched. Configure Firebase Cloud Message mToken,
 * Select the language and shows a loading message with a nice background
 */
public class LauncherActivity extends AppCompatActivity {

    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;

    private static final String TAG = "LauncherActivity";

    ConfirmUserRegistrationTask mRegTask;

    Boolean invokedWithConfirmRegistrationURL = false;
    Boolean invokedWithResetPasswordURL = false;

    SessionData sessionData;

    private int SCHEDULE_TIME = 2000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);


////////////////////
        String FCMtoken = FirebaseInstanceId.getInstance().getToken();

        // Log and toast
        String msg = getString(R.string.msg_token_fmt, FCMtoken);
        Log.d(TAG, msg);

        // Save FCM mToken in shared preferences
        sessionData = SessionData.getSessionData(LauncherActivity.this);
        sessionData.setFCMToken(FCMtoken);

        // TODO: Local language modification. Currently, it has bugs.
        // Set the language
        /*
        Locale myLocale = new Locale(sessionData.getLanguage());
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = myLocale;
        res.updateConfiguration(conf, dm);
        */
        if(checkPlayServices()) {

            TimerTask task = new TimerTask() {
                @Override
                public void run() {

                    if (sessionData.isLogged()) { //If user is logged, go to main activity
                        if (sessionData.thereAreASmokeFreeQuestionWithoutResponse()) {
                            Intent casualQuestionActivity = new Intent(getApplicationContext(), CasualQuestionActivity.class);
                            casualQuestionActivity
                                    .putExtra(MyFirebaseMessagingService.idQuestion, SFBConstantsAndCodes.SMOKEFREE_QUESTION_ID)
                                    .putExtra(MyFirebaseMessagingService.idQuestionInServer, sessionData.getIdSmokeFreeQuestionInServer())
                                    .putExtra(MyFirebaseMessagingService.receivedQuestionDate, sessionData.getDateReceivedSmokeFreeQuestion())
                                    .putExtra(MyFirebaseMessagingService.idNotification, SFBConstantsAndCodes.SMOKEFREE_QUESTION_NOTIFICATION_BOX_ID);
                            startActivity(casualQuestionActivity);
                        } else if (sessionData.thereAreAMessagesFrequencyQuestionWithoutResponse()) {
                            Intent casualQuestionActivity = new Intent(getApplicationContext(), CasualQuestionActivity.class);
                            casualQuestionActivity
                                    .putExtra(MyFirebaseMessagingService.idQuestion, SFBConstantsAndCodes.MESSAGES_FREQUENCY_QUESTION_ID)
                                    .putExtra(MyFirebaseMessagingService.idQuestionInServer, sessionData.getIdMessagesFrequencyQuestionInServer())
                                    .putExtra(MyFirebaseMessagingService.receivedQuestionDate, sessionData.getDateReceivedMessagesFrequencyQuestion())
                                    .putExtra(MyFirebaseMessagingService.idNotification, SFBConstantsAndCodes.MESSAGES_FREQUENCY_QUESTION_NOTIFICATION_BOX_ID);
                            startActivity(casualQuestionActivity);
                        } else
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                        finish(); //Prevent to return to this activity
                    } else if (getIntent().getAction().contains("action.VIEW")) {
                        Uri uri = getIntent().getData();
                        invokedWithConfirmRegistrationURL = uri.getPath().contains("confirmregistration");
                        invokedWithResetPasswordURL = uri.getPath().contains("resetpassword");
                        if (invokedWithConfirmRegistrationURL) {
                            String username = uri.getQueryParameter("username");
                            String token = uri.getQueryParameter("token");

                            mRegTask = new ConfirmUserRegistrationTask(username, token, getApplicationContext());
                            mRegTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);

                        }/*else if(invokedWithResetPasswordURL){
                        // TODO currently the unique way to reset the password is accessing to a web page

                    }*/ else { // Else, go to login activity
                            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    } else {// Else, go to login activity
                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        startActivity(intent);
                        finish();
                    }

                }
            };
            Timer timer = new Timer();
            // Wait for launch the following activity
            timer.schedule(task, SCHEDULE_TIME);
        }

    }

    private boolean checkPlayServices() {
        GoogleApiAvailability gApi = GoogleApiAvailability.getInstance();
        int resultCode = gApi.isGooglePlayServicesAvailable(this);
        if(resultCode != ConnectionResult.SUCCESS){
            if(gApi.isUserResolvableError(resultCode)){
                gApi.getErrorDialog(this, resultCode, PLAY_SERVICES_RESOLUTION_REQUEST).show();
            }else{
                Toast.makeText(this, "Yo must to install Google PLay Services", Toast.LENGTH_LONG).show();
                finish();
            }
            return false;
        }
        return true;
    }

    /**
     * An {@link AsyncTask} to send to the server the sign up request.
     */
    public class ConfirmUserRegistrationTask extends AsyncTask<Void, Void, Boolean> {

        private final String mUsername;
        private final String mToken;
        private final Context mContext;
        private Integer failCode;
        private ProgressDialog mProgressDialog;
        private final int CODE_NO_FAILS = 0;
        private final int CODE_ERROR_USER_EXISTS = 3;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;
        private final int CODE_ERROR_REQUEST_INVALID = 5;

        ConfirmUserRegistrationTask(String username, String token, Context context) {
            mUsername = username;
            mToken = token;
            mContext = context;
            failCode = CODE_NO_FAILS;
        }


        @Override
        protected Boolean doInBackground(Void... voids) {
            /**
             * create xml file
             * string xml request with user in md5
             *
             * check connectivity
             */

            Boolean registrationRequestVerified = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();
            //String fileXMLRequest = file.getAllDataRequest(mUsername, SFBEncode.encodeToMD5(mToken));//file.getAllDataRequest(mUsername); //SFBEncode.encodeToMD5(mUsername), mToken

            if (XMLHttpPost.isConnectedToInternet(LauncherActivity.this)) {

                String fileXMLRequest = file.verifyUserRegistrationRequest(mUsername, mToken);

                // ENVIAR PETICIÓN HTTP POST
                String responseXML = "";

                try {
                    //Introduces XML y devuelve respuesta del servidor
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, getApplicationContext(), null);

                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }

                registrationRequestVerified = responseXML == "created";
                if (!registrationRequestVerified)
                    if (responseXML.equals("forbidden"))
                        failCode = CODE_ERROR_REQUEST_INVALID;
                    else if(responseXML.equals("method_not_allowed"))
                        failCode = CODE_ERROR_USER_EXISTS;

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }

            return registrationRequestVerified;
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog = new ProgressDialog(mContext);
                mProgressDialog.setMessage(getString(R.string.checking_user));
                mProgressDialog.setCancelable(false);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mRegTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (success) {

                Intent intent = new Intent(getApplicationContext(), FormActivity.class);
                intent.putExtra("idForm", SFBConstantsAndCodes.SIGN_UP_FORM_CONFIRMATION_ID);
                intent.putExtra("username", mUsername);
                intent.putExtra("token", mToken);
                startActivity(intent);
                finish();

            } else {
                String errorMessage = "Error";
                Toast errorToast;
                switch (failCode) {
                    case CODE_ERROR_REQUEST_INVALID:
                        errorMessage = getString(R.string.error_request_invalid);
                        break;
                    case CODE_ERROR_USER_EXISTS:
                        errorMessage = getString(R.string.error_user_already_confirmed);
                        break;
                    case CODE_ERROR_INTERNET_CONNECTION:
                        errorMessage = getString(R.string.error_internet_connection);
                        break;
                    default:
                        break;
                }
                errorToast = Toast.makeText(LauncherActivity.this, errorMessage, Toast.LENGTH_LONG);
                errorToast.show();
                startActivity(new Intent(LauncherActivity.this, LoginActivity.class));
                finish();
            }
        }

        @Override
        protected void onCancelled() {
            mRegTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            //showProgress(false);
        }
    }

}