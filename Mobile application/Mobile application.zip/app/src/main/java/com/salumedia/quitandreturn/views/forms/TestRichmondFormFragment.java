package com.salumedia.quitandreturn.views.forms;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.SFBFragment;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;


/**
 * Created by Francisco on 12/1/17.
 */

public class TestRichmondFormFragment extends SFBFragment {

    // Tag used to identify the fragment and for analytical purpose
    public static final String TAG = "TEST_RICHMOND_FORM";

    // Access to shared preferences
    SessionData sessionData;

    // Default necessary constructor
    public TestRichmondFormFragment() {
    }

    // Constructor that allow receive information from the invoking class
    public static TestRichmondFormFragment newInstance(Bundle arguments) {

        TestRichmondFormFragment f = new TestRichmondFormFragment();
        if (arguments != null) {
            f.setArguments(arguments);
        }
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Not View attributes instantiation
        section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_TEST_RICMOND_FORM; // Analysis purpose
        sessionData = SessionData.getSessionData(getContext()); // Shared preferences access
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // Inflating the fragment
        View rootView = inflater.inflate(R.layout.form_fragment_test_richmond, container, false);

        // Check if this form was filled in the past and if questions responses are saved in shared
        // preferences (session data). Positive Case: show the previous responses.
        if(sessionData.isFilledRichmondTest()){
            int[] list = {R.id.richmond_q1,R.id.richmond_q2,
                    R.id.richmond_q3, R.id.richmond_q4};
            Integer[] answers = sessionData.getRichmondAnswers();
            if(!answers[0].equals(-1)) {
                RadioGroup radioGroup;
                RadioButton radioButton;
                for (int i = 0; i < list.length; i++) {
                    radioGroup = (RadioGroup) rootView.findViewById(list[i]);
                    radioButton = (RadioButton) radioGroup.getChildAt(answers[i]);
                    radioButton.setChecked(true);
                }
            }
        }

        return rootView;
    }
}
