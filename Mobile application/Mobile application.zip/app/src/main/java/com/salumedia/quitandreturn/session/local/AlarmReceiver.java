package com.salumedia.quitandreturn.session.local;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBNotification;
import com.salumedia.quitandreturn.session.server.MyFirebaseMessagingService;
import com.salumedia.quitandreturn.session.server.SendFastQuestionResponse;
import com.salumedia.quitandreturn.utils.ImageConversions;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBDate;
import com.salumedia.quitandreturn.views.CasualQuestionActivity;
import com.salumedia.quitandreturn.views.LauncherActivity;
import com.salumedia.quitandreturn.views.MainActivity;
import com.salumedia.quitandreturn.views.main_navigationdrawer_sections.TabsInitFragment;

import java.util.Calendar;

import static android.content.Context.NOTIFICATION_SERVICE;


public class AlarmReceiver extends BroadcastReceiver {
    public AlarmReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {

        boolean createNotificationWithOptions = false;

        boolean doNotCreateNotifications = false;

        Bundle extras = intent.getExtras();
        Integer type = extras.getInt(SFBConstantsAndCodes.NOTIFICATION_TYPE_KEY, 50);

        Intent resultIntent;
        Bitmap icon;
        //Drawable drawable;

        String title = extras.getString(SFBConstantsAndCodes.NOTIFICATION_TITLE_KEY, "");

        switch (type) {
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_CIGARETTES_NOT_SMOKED:
                resultIntent = new Intent(context, MainActivity.class);
                //drawable = ResourcesCompat.getDrawable(context.getResources(), R.drawable.ic_cigarettes, null);
                break;
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_HOURS_REGAINED:
                resultIntent = new Intent(context, MainActivity.class);
                //drawable = ResourcesCompat.getDrawable(context.getResources(), R.drawable.ic_regained_hours, null);
                break;
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_SAVINGS:
                resultIntent = new Intent(context, MainActivity.class);
                //drawable = ResourcesCompat.getDrawable(context.getResources(), R.drawable.ic_savings_eu, null);
                break;
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_SMOKEFREE:
                resultIntent = new Intent(context, MainActivity.class);
                //drawable = ResourcesCompat.getDrawable(context.getResources(), R.drawable.ic_smoke_free, null);
                break;
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_OTHER:
                resultIntent = new Intent(context, MainActivity.class);
                //drawable = ResourcesCompat.getDrawable(context.getResources(), R.drawable.ic_message_lamp, null);
                break;
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_MOTIVATIONAL_MESSAGE_FROM_SERVER:
                // Create and show a simple notification containing the received FCM message.
                resultIntent = new Intent(context, MainActivity.class);
                resultIntent.putExtra(MainActivity.SUBSECTION_KEY, TabsInitFragment.TAB_MESSAGES);
                resultIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                title = context.getString(R.string.smokefreebrain_notification_title);
                //TODO
                /* PendingIntent pendingIntent = PendingIntent.getActivity(context, 0 /* Request code * /, intent,
                        PendingIntent.FLAG_ONE_SHOT);
                */
                saveMotivationalMessage(context, extras);
                break;
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_FOLLOW_UP:
                resultIntent = new Intent(context, LauncherActivity.class);
                createNotificationWithOptions = true;
                break;
            case SFBConstantsAndCodes.NOTIFICATION_TYPE_INFORMATION:
                resultIntent = new Intent(context, MainActivity.class);
                saveNotification(context, extras);
                //drawable = ResourcesCompat.getDrawable(context.getResources(), R.drawable.email, null);
                break;
            default:
                doNotCreateNotifications = true;
                resultIntent = null;
                break;
        }

        if (!doNotCreateNotifications) {
            SessionData sessionData = SessionData.getSessionData(context);

            NotificationCompat.Builder notificationBuilder;

            if (createNotificationWithOptions) {
            /*  CREATE NOTIFICATION WITH OPTIONS BUTTONS  */

                int questionCode;
                String questionTitle;
                String questionText;
                String questionBigText;

                // Notification code, used to cancel it from an intent
                int idNotification_big_view;
                String date = SFBDate.timestampToString(Calendar.getInstance());

                PendingIntent pendingIntent = PendingIntent.getActivity(context, 0 /* Request code */, resultIntent,
                        PendingIntent.FLAG_ONE_SHOT);

                String message = extras.getString(SFBConstantsAndCodes.NOTIFICATION_MESSAGE_KEY, "");
                String serverQuestionId = extras.getString(SFBConstantsAndCodes.NOTIFICATION_REQUEST_CODE_KEY, "0");

                switch (message) {
                    case "SmokeFreeQuestion":

                        idNotification_big_view = SFBConstantsAndCodes.SMOKEFREE_QUESTION_NOTIFICATION_BOX_ID;
                        questionCode = SFBConstantsAndCodes.SMOKEFREE_QUESTION_ID;
                        questionTitle = context.getString(R.string.record_smokefree_notification_title);
                        questionText = context.getString(R.string.record_smokefree_notification_text);
                        questionBigText = context.getString(R.string.record_smokefree_notification_big_text);

                        sessionData.setIdSmokeFreeQuestionInServer(serverQuestionId);
                        sessionData.setDateReceivedSmokeFreeQuestion(date);
                        sessionData.changeIfThereAreASmokeFreeQuestionWithoutResponse(true);

                        Intent openQuestion = new Intent(context, CasualQuestionActivity.class);
                        openQuestion.putExtra(MyFirebaseMessagingService.idQuestion, questionCode)
                                .putExtra(MyFirebaseMessagingService.idQuestionInServer, serverQuestionId)
                                .putExtra(MyFirebaseMessagingService.receivedQuestionDate, date)
                                .putExtra(MyFirebaseMessagingService.idNotification, idNotification_big_view);
                        PendingIntent pendingOpenQuestion = PendingIntent.getActivity(context, 1, openQuestion, PendingIntent.FLAG_UPDATE_CURRENT);

                        Intent sendFastQuestionResponse = new Intent(context, SendFastQuestionResponse.class);
                        sendFastQuestionResponse.putExtra(MyFirebaseMessagingService.idQuestion, questionCode)
                                .putExtra(MyFirebaseMessagingService.idQuestionInServer, serverQuestionId)
                                .putExtra(MyFirebaseMessagingService.receivedQuestionDate, date)
                                .putExtra(MyFirebaseMessagingService.idNotification, idNotification_big_view)
                                .putExtra(MyFirebaseMessagingService.questionResponse, 0);
                        PendingIntent pendingSendFastQuestionResponse = PendingIntent.getService(context, 0, sendFastQuestionResponse, PendingIntent.FLAG_UPDATE_CURRENT);

                        NotificationCompat.Action fast_response_action = new NotificationCompat.Action.Builder(
                                R.drawable.ic_thumb_up_black_24dp, context.getString(R.string.yes), pendingSendFastQuestionResponse).build();
                        NotificationCompat.Action open_question_access = new NotificationCompat.Action.Builder(
                                R.drawable.ic_thumb_down_black_24dp, context.getString(R.string.no), pendingOpenQuestion).build();

                        try {
                            NotificationCompat.Builder notificationBuilderSomeOptions =
                                    new NotificationCompat.Builder(context)
                                            .setContentTitle(questionTitle)
                                            .setContentText(questionText)
                                            .setPriority(Notification.PRIORITY_HIGH)
                                            .setDefaults(Notification.DEFAULT_ALL)
                                            .setStyle(new NotificationCompat.BigTextStyle()
                                                    .bigText(questionBigText))
                                            .setContentIntent(pendingIntent)
                                            .addAction(fast_response_action)
                                            .addAction(open_question_access);

                            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT)
                                notificationBuilderSomeOptions.setSmallIcon(R.drawable.logo)
                                        .setLargeIcon(ImageConversions.getBitmapFromDrawable(context, R.drawable.logo_min));
                            else
                                notificationBuilderSomeOptions.setSmallIcon(R.drawable.vector_logo)
                                        .setLargeIcon(ImageConversions.getBitmapFromDrawable(context, R.drawable.logo));

                            NotificationManager mNotifyMgr =
                                    (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);

                            mNotifyMgr.notify(idNotification_big_view, notificationBuilderSomeOptions.build());

                        } catch (Exception e) {

                        } finally {

                        }

                        break;
                    case "MessagesFrequencyQuestion":

                        idNotification_big_view = SFBConstantsAndCodes.MESSAGES_FREQUENCY_QUESTION_NOTIFICATION_BOX_ID;
                        questionCode = SFBConstantsAndCodes.MESSAGES_FREQUENCY_QUESTION_ID;
                        questionTitle = context.getString(R.string.record_messages_frequency_notification_title);
                        questionText = context.getString(R.string.record_messages_frequency_notification_text);
                        questionBigText = context.getString(R.string.record_messages_frequency_notification_big_text);

                        sessionData.setIdMessagesFrequencyQuestionInServer(serverQuestionId);
                        sessionData.setDateReceivedMessagesFrequencyQuestion(date);
                        sessionData.changeIfThereAreAMessagesFrequencyQuestionWithoutResponse(true);

                        Intent sendFastQuestionResponseFew = new Intent(context, SendFastQuestionResponse.class);
                        sendFastQuestionResponseFew.putExtra(MyFirebaseMessagingService.idQuestion, questionCode)
                                .putExtra(MyFirebaseMessagingService.idQuestionInServer, serverQuestionId)
                                .putExtra(MyFirebaseMessagingService.receivedQuestionDate, date)
                                .putExtra(MyFirebaseMessagingService.idNotification, idNotification_big_view)
                                .putExtra(MyFirebaseMessagingService.questionResponse, 0);
                        PendingIntent pendingSendFastQuestionResponseFew = PendingIntent.getService(context, 1, sendFastQuestionResponseFew, PendingIntent.FLAG_UPDATE_CURRENT);

                        NotificationCompat.Action fast_response_action_few = new NotificationCompat.Action.Builder(
                                R.drawable.ic_low_frequency_messages_black_24dp, context.getString(R.string.record_messages_frequency_notification_few_answer), pendingSendFastQuestionResponseFew).build();


                        Intent sendFastQuestionResponseMedium = new Intent(context, SendFastQuestionResponse.class);
                        sendFastQuestionResponseMedium.putExtra(MyFirebaseMessagingService.idQuestion, questionCode)
                                .putExtra(MyFirebaseMessagingService.idQuestionInServer, serverQuestionId)
                                .putExtra(MyFirebaseMessagingService.receivedQuestionDate, date)
                                .putExtra(MyFirebaseMessagingService.idNotification, idNotification_big_view)
                                .putExtra(MyFirebaseMessagingService.questionResponse, 1);
                        PendingIntent pendingSendFastQuestionResponseMedium = PendingIntent.getService(context, 2, sendFastQuestionResponseMedium, PendingIntent.FLAG_UPDATE_CURRENT);

                        NotificationCompat.Action fast_response_action_medium = new NotificationCompat.Action.Builder(
                                R.drawable.ic_medium_frequency_messages_black_24dp, context.getString(R.string.record_messages_frequency_notification_medium_answer), pendingSendFastQuestionResponseMedium).build();

                        Intent sendFastQuestionResponseMany = new Intent(context, SendFastQuestionResponse.class);
                        sendFastQuestionResponseMany.putExtra(MyFirebaseMessagingService.idQuestion, questionCode)
                                .putExtra(MyFirebaseMessagingService.idQuestionInServer, serverQuestionId)
                                .putExtra(MyFirebaseMessagingService.receivedQuestionDate, date)
                                .putExtra(MyFirebaseMessagingService.idNotification, idNotification_big_view)
                                .putExtra(MyFirebaseMessagingService.questionResponse, 2);
                        PendingIntent pendingSendFastQuestionResponseMany = PendingIntent.getService(context, 3, sendFastQuestionResponseMany, PendingIntent.FLAG_UPDATE_CURRENT);

                        NotificationCompat.Action fast_response_action_many = new NotificationCompat.Action.Builder(
                                R.drawable.ic_high_frequency_messages_black_24dp, context.getString(R.string.record_messages_frequency_notification_many_answer), pendingSendFastQuestionResponseMany).build();
                        try {
                            NotificationCompat.Builder notificationBuilderSomeOptions =
                                    new NotificationCompat.Builder(context)
                                            .setContentTitle(questionTitle)
                                            .setContentText(questionText)
                                            .setPriority(Notification.PRIORITY_HIGH)
                                            .setDefaults(Notification.DEFAULT_ALL)
                                            .setStyle(new NotificationCompat.BigTextStyle()
                                                    .bigText(questionBigText))
                                            .setContentIntent(pendingIntent)
                                            .addAction(fast_response_action_few)
                                            .addAction(fast_response_action_medium)
                                            .addAction(fast_response_action_many);

                            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT)
                                notificationBuilderSomeOptions.setSmallIcon(R.drawable.logo)
                                        .setLargeIcon(ImageConversions.getBitmapFromDrawable(context, R.drawable.logo_min));
                            else
                                notificationBuilderSomeOptions.setSmallIcon(R.drawable.vector_logo)
                                        .setLargeIcon(ImageConversions.getBitmapFromDrawable(context,R.drawable.logo));

                            NotificationManager mNotifyMgr =
                                    (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);

                            mNotifyMgr.notify(idNotification_big_view, notificationBuilderSomeOptions.build());

                        } catch (Exception e) {
                            Toast.makeText(context, e.toString(), Toast.LENGTH_LONG).show();
                        } finally {

                        }

                        break;
                }


            } else {
            /*   CREATE SIMPLE NOTIFICATION   */
                //icon = ((BitmapDrawable) drawable).getBitmap();
                String message = extras.getString(SFBConstantsAndCodes.NOTIFICATION_MESSAGE_KEY, "");
                String requestCode = extras.getString(SFBConstantsAndCodes.NOTIFICATION_REQUEST_CODE_KEY, "0");

                if (intent.hasExtra(SFBConstantsAndCodes.NOTIFICATION_DRAWABLE_CODE_KEY)) {
                    Integer drawableCode = extras.getInt(SFBConstantsAndCodes.NOTIFICATION_DRAWABLE_CODE_KEY, 0);
                    resultIntent.putExtra(SFBConstantsAndCodes.NOTIFICATION_DRAWABLE_CODE_KEY, drawableCode);
                }

                String url = extras.getString(SFBConstantsAndCodes.NOTIFICATION_URL_PHOTO_CODE_KEY);
                resultIntent.putExtra("notification", true);
                resultIntent.putExtra(SFBConstantsAndCodes.NOTIFICATION_MESSAGE_KEY, message);
                resultIntent.putExtra(SFBConstantsAndCodes.NOTIFICATION_TYPE_KEY, type);
                resultIntent.putExtra(SFBConstantsAndCodes.NOTIFICATION_URL_PHOTO_CODE_KEY, url);

                PendingIntent resultPendingIntent = PendingIntent.getActivity(context, Integer.parseInt(requestCode), resultIntent, PendingIntent.FLAG_ONE_SHOT);
                Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                notificationBuilder = new NotificationCompat.Builder(context)
                        .setContentText(message)
                        .setContentTitle(title)
                        .setTicker(context.getString(R.string.sfb_server_notification))
                        .setAutoCancel(true)
                        .setSound(defaultSoundUri)
                        .setPriority(Notification.PRIORITY_HIGH)
                        .setContentIntent(resultPendingIntent);

                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT)
                    notificationBuilder.setSmallIcon(R.drawable.logo)
                            .setLargeIcon(ImageConversions.getBitmapFromDrawable(context, R.drawable.logo_min));
                else
                    notificationBuilder.setSmallIcon(R.drawable.vector_logo)
                            .setLargeIcon(ImageConversions.getBitmapFromDrawable(context, R.drawable.logo));

                if (sessionData.getMuteNotificationsUntil().before(Calendar.getInstance())) {
                    NotificationManager notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
                    notificationManager.notify(1, notificationBuilder.build());
                }


            }
        }
    }

    private void saveMotivationalMessage(Context context, Bundle extras) {
        String sender = extras.getString(SFBConstantsAndCodes.NOTIFICATION_USER_ID_CODE_KEY);
        String receiver = SessionData.getSessionData(context).getUserId();
        String message = extras.getString(SFBConstantsAndCodes.NOTIFICATION_MESSAGE_KEY);
        String serverMotivationalMessageId = extras.getString(SFBConstantsAndCodes.NOTIFICATION_REQUEST_CODE_KEY, "0");
        int type = extras.getInt(SFBConstantsAndCodes.NOTIFICATION_TYPE_KEY);
        SFBNotification notification = new SFBNotification(sender, receiver, message, type, Calendar.getInstance());

        LocalDataBaseHelper db = new LocalDataBaseHelper(context);
        db.insertMessageNotificationFromFCM(notification, serverMotivationalMessageId);

    }

    private void saveNotification(Context context, Bundle extras) {
        String sender = extras.getString(SFBConstantsAndCodes.NOTIFICATION_USER_ID_CODE_KEY);
        String receiver = SessionData.getSessionData(context).getUserId();
        String message = extras.getString(SFBConstantsAndCodes.NOTIFICATION_MESSAGE_KEY);
        int type = extras.getInt(SFBConstantsAndCodes.NOTIFICATION_TYPE_KEY);
        SFBNotification notification = new SFBNotification(sender, receiver, message, type, Calendar.getInstance());

        LocalDataBaseHelper db = new LocalDataBaseHelper(context);

        if (!message.equals(context.getResources().getString(R.string.quitting_attempt_has_started))
                || (message.equals(context.getResources().getString(R.string.quitting_attempt_has_started))
                && !SessionData.getSessionData(context).hasIntroducedActiveQuittingAttempDateInThisSession())) {
            notification.setText(String.format(context.getResources().getString(R.string.quitting_attempt_started_explanation),
                    SessionData.getSessionData(context).getUserNick()));
            db.insertMessageNotification(notification);
            SessionData.getSessionData(context).setHasIntroducedActiveQuittingAttempDateInThisSession(true);
        }
    }

    public static void setAlarmNotification(Context context, SFBNotification item, String requestCodeKey) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        //System.out.println("El type es " + item.getType());

        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra(SFBConstantsAndCodes.NOTIFICATION_TITLE_KEY, context.getString(R.string.sfb_notification));
        intent.putExtra(SFBConstantsAndCodes.NOTIFICATION_MESSAGE_KEY, item.getText());
        intent.putExtra(SFBConstantsAndCodes.NOTIFICATION_TYPE_KEY, item.getType());
        intent.putExtra(SFBConstantsAndCodes.NOTIFICATION_USER_NAME_CODE_KEY, item.getUserName());
        intent.putExtra(SFBConstantsAndCodes.NOTIFICATION_REQUEST_CODE_KEY, requestCodeKey);
        intent.putExtra(SFBConstantsAndCodes.NOTIFICATION_URL_PHOTO_CODE_KEY, item.getPhotoUrl());
        if (item.getIdDrawableCode() != null) {
            intent.putExtra(SFBConstantsAndCodes.NOTIFICATION_DRAWABLE_CODE_KEY, item.getIdDrawableCode());
        }
        Integer requestCodeInteger = Integer.parseInt(requestCodeKey);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, requestCodeInteger, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        manager.set(AlarmManager.RTC_WAKEUP, item.getSentDate().getTimeInMillis(), pendingIntent);
    }

}
