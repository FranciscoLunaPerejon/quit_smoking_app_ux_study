package com.salumedia.quitandreturn.views.dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBMessageInteractionAnalytic;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.XMLHttpPost;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.SFBAnalytics;
import com.salumedia.quitandreturn.utils.SFBChecks;
import com.salumedia.quitandreturn.utils.SFBEncode;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;



/**
 * Created by joaquin on 29/8/16.
 */

/**
 * This class shows a small window with the content of a motivational message, a form to know the
 * user opinion about this message and the possibility of check it like favorite.
 */
public class RateMessageDialogFragment extends DialogFragment {

    // This class needs params from the fragment that invokes it. It must be saved in a bundle (an
    // object with the capacity of store arguments in a map). These are the keys used to store the
    // params in extras.
    private final static String ID_MESSAGE_BODY = "message"; // Message text
    private final static String ID_SERVER_KEY = "idServer"; // Message id in server
    private final static String ID_DATE = "dateWhenRead"; //
    private final static String ID_TIME_START_READ = "timeStartRead";
    private final static String ID_TIME_START_MILLIS = "timeStartMillis";
    private final static String ID_TIME_TO_READ = "timeToRead"; // Minutes before lecture


    // Access to local DB
    LocalDataBaseHelper db = new LocalDataBaseHelper(getActivity());

    // View attributes
    private TextView textViewMessage;
    private Button buttonSave;
    private RatingBar messageRating;
    private TextView textIfMessageIsRepeated;
    private LinearLayout coincidenceExplanationLayout;
    private TextView coincidenceExplanation;


    private boolean isMessagePreviouslyRated = false;

    private boolean isSavedInteractionWithMessage = false;

    // An Async Task instance. It allows to do a background task
    RateMessageTask mRateMessageTask;

    // Get the possibility to do something from another fragment or activity when this dialog is dismiss
    private DialogInterface.OnDismissListener onDismissListener;
    public void setOnDismissListener(DialogInterface.OnDismissListener onDismissListener){
        this.onDismissListener = onDismissListener;
    }
    @Override
    public void onDismiss(DialogInterface dialog) {

        if(!isSavedInteractionWithMessage) {
            saveInteractionWithMessage();
            isSavedInteractionWithMessage = true;
        }

        super.onDismiss(dialog);

        if(onDismissListener != null){
            onDismissListener.onDismiss(dialog);
        }
        String date;
        String time;
        try{
            Bundle argsv = getArguments();
            if(argsv.containsKey(ID_DATE) && argsv.containsKey(ID_TIME_START_READ)){
                date = argsv.getString(ID_DATE);
                time = argsv.getString(ID_TIME_START_READ);
            }else{
                date = "unknownDate";
                time = "unknownTime";
            }

        }catch (Exception e){
            date = "unknownDate";
            time = "unknownTime";
        }

        try{
            SFBAnalytics.startLogTimeInSection("MOTIVATIONAL_MESSAGE" +
                    "_author:" +  SessionData.getSessionData(getContext()).getUserData(getContext()).getUserId() +
                    "_date:" + date + " " +  time);
            SFBAnalytics.stopLogTimeInSection("MOTIVATIONAL_MESSAGE" +
                    "_author:" + SessionData.getSessionData(getContext()).getUserData(getContext()).getUserId() +
                    "_date:" + date + " " +  time);
        }catch (Exception e){
            SFBAnalytics.startLogTimeInSection("MOTIVATIONAL_MESSAGE" + "_author:NOT_AVALIABLE" +
                    "_date:" + date + " " +  time);
            SFBAnalytics.stopLogTimeInSection("MOTIVATIONAL_MESSAGE" + "_author:NOT_AVALIABLE" +
                    "_date:" + date + " " +  time);
        }

    }

    // Default necessary constructor
    public RateMessageDialogFragment() {
    }

    // Constructor that receives the necessary params to create the message dialog
    public static RateMessageDialogFragment newInstance(String text, String idServer, Calendar timestampWhenRead, String timeToRead) {
        RateMessageDialogFragment rateMessageDialogFragment = new RateMessageDialogFragment();
        // In fragments, it seems it is not possible declare attributes and instance them in a constructor,
        // so the information received should be stored in a bundle.
        Bundle args = new Bundle();
        args.putString(ID_MESSAGE_BODY, text); //Message body
        args.putString(ID_SERVER_KEY, idServer); // Message id in server

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        args.putString(ID_DATE, sdf.format(timestampWhenRead.getTime())); //Date when read
        SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss.SSS");
        args.putString(ID_TIME_START_READ, sdf2.format(timestampWhenRead.getTime())); // Date start to see the message dialog
        args.putFloat(ID_TIME_START_MILLIS, Long.valueOf(System.nanoTime()/1000000).floatValue()); // Millisecond start read
        args.putString(ID_TIME_TO_READ, timeToRead); //Time to read in seconds
        rateMessageDialogFragment.setArguments(args);

        // Not allow dismiss the dialog when touch in other part of the screen
        rateMessageDialogFragment.setCancelable(false);

        return rateMessageDialogFragment;
    }


    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        // Inflating the dialog fragment
        LayoutInflater inflater = getActivity().getLayoutInflater();
        final View rootView = inflater.inflate(R.layout.dialog_rate_message, null);

        // View attributes instantiation
        textViewMessage = (TextView) rootView.findViewById(R.id.textViewMessageToRate);
        buttonSave = (Button) rootView.findViewById(R.id.buttonSave);
        messageRating = (RatingBar)rootView.findViewById(R.id.message_rating_ratingbar);
        textIfMessageIsRepeated = (TextView) rootView.findViewById(R.id.text_if_message_is_repeated);
        coincidenceExplanationLayout = (LinearLayout) rootView.findViewById(R.id.match_percentage_layout);
        coincidenceExplanation = (TextView) rootView.findViewById(R.id.text_match_percentage);

        TextView whyRateMessageTitle = (TextView) rootView.findViewById(R.id.why_rate_message_title);
        whyRateMessageTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView whyRateMessageBody = (TextView) rootView.findViewById(R.id.why_rate_message_body);
                if(whyRateMessageBody.getVisibility() == View.GONE) {
                    whyRateMessageBody.setVisibility(View.VISIBLE);
                    whyRateMessageBody.requestFocus();
                }
                else {
                    whyRateMessageBody.setVisibility(View.GONE);
                    textViewMessage.requestFocus();
                }
            }
        });
        Bundle argsv = getArguments();



        String previousRating = (new LocalDataBaseHelper(getActivity())).getMessageNotificationRating(argsv.getString(ID_SERVER_KEY));

        isMessagePreviouslyRated = !previousRating.equals("0");

        // Check last vote for this message
        if(isMessagePreviouslyRated) {
            setPreviousRating(previousRating);
            buttonSave.setVisibility(View.VISIBLE);
            this.setCancelable(true);

        }

        // Builder used to manage the dialog fragment
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(rootView);

        return builder.create();
    }


    @Override
    public void onStart(){
        super.onStart();
        AlertDialog d = (AlertDialog)getDialog();
        if(d != null) {

            String message = getArguments().getString(ID_MESSAGE_BODY);

        /*  Used to check if the division of element included on the message works
            if(message.contains("c"))
                message = "El texto con el mensaje que aparecerá dando consejo o alguna informacion interesante al paciente en tratamiento para dejar de fumar.//0";
            else
                message = "El texto con el mensaje que aparecerá dando consejo o alguna informacion interesante al paciente en tratamiento para dejar de fumar.//0//Texto que cambiara dependiendo del numero de veces que se haya mandado el mensaje. Procederá del servidor.";
         */

            String[] messageAndDataDivided = message.split("//");

            textViewMessage.setText(messageAndDataDivided[0]);

            Boolean messageContainsMoreData = messageAndDataDivided.length > 1;

            Boolean messageBringCoincidenceExplanation = messageContainsMoreData && SFBChecks.stringIsANumber(messageAndDataDivided[1]);

            if(messageBringCoincidenceExplanation) {
                //String messageWithPercentageSymbol = messageAndDataDivided[1] + "%";
                //coincidenceExplanation.setText(messageWithPercentageSymbol);
                String messageWithPercentageSymbol = messageAndDataDivided[1].equals("0") ? getString(R.string.coincidence_explanation_control_group)
                                                                                            : getString(R.string.coincidence_explanation_intervention_group) ;
                coincidenceExplanation.setText(messageWithPercentageSymbol);
            }else{
                coincidenceExplanationLayout.setVisibility(View.GONE);
            }

            Boolean messageIsRepeated = messageAndDataDivided.length >2;

            if(messageIsRepeated){
                textIfMessageIsRepeated.setVisibility(View.VISIBLE);
                textIfMessageIsRepeated.setText(messageAndDataDivided[2]);
            }

            // Personalized button for the dialog
            buttonSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (checkIfDataIsCorrect()) {

                        saveInteractionWithMessage();

                        isSavedInteractionWithMessage = true;
                        dismiss();

                    } else {
                        Snackbar.make(view, R.string.choice_an_option, Snackbar.LENGTH_LONG).show();
                    }
                }
            });

            messageRating.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                @Override
                public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                    if(!isMessagePreviouslyRated){
                        buttonSave.callOnClick();
                    }
                }
            });

        }
    }

    // Check the last vote option if it message was voted previously
    private void setPreviousRating(String vote){
        messageRating.setRating(Float.valueOf(vote));
    }


    // Check if is selected a vote value
    private boolean checkIfDataIsCorrect(){
        return messageRating.getRating() != 0;
    }


    public void saveInteractionWithMessage(){
        // Extract extras to store analytical information about the message
        Bundle argsv = getArguments();
        Float aux = argsv.getFloat(ID_TIME_START_MILLIS);
        Float aux2 = Long.valueOf(System.nanoTime()/1000000).floatValue();
        Float secondsLecture = (aux2 - aux)/1000; // save seconds lecture

        // Create the object used to manipulate the message lecture information
        SFBMessageInteractionAnalytic sfbMessageInteractionAnalytic = new SFBMessageInteractionAnalytic(argsv.getString(ID_SERVER_KEY),
                argsv.getString(ID_DATE),
                argsv.getString(ID_TIME_START_READ),
                secondsLecture,
                argsv.getString(ID_TIME_TO_READ), //In seconds
                String.valueOf(getAnswer()),
                "0");

        mRateMessageTask = new RateMessageDialogFragment.RateMessageTask(getActivity(),
                sfbMessageInteractionAnalytic);
        mRateMessageTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);

        (new LocalDataBaseHelper(getActivity())).updateMessageNotification(sfbMessageInteractionAnalytic.getIdServer(), "1", sfbMessageInteractionAnalytic.getVote());

    }

    // Codify the vote option selected
    @NonNull
    private Integer getAnswer(){
        return Float.valueOf(messageRating.getRating()).intValue();
    }



    private class RateMessageTask extends AsyncTask<Void, Void, Boolean> {

        Context context;

        // Attribute with the information to send to the server
        private SFBMessageInteractionAnalytic SFBMessageInteractionAnalytic;

        // used to pause the app activity until the task finish, and alert to the user
        private ProgressDialog mProgressDialog;


        // Constructor
        RateMessageTask(Context context, SFBMessageInteractionAnalytic SFBMessageInteractionAnalytic){
            this.context = context;
            this.SFBMessageInteractionAnalytic = SFBMessageInteractionAnalytic;
        }

        // The task part that is executed in different thread (The other parts are executed in the main thread)
        @Override
        protected Boolean doInBackground(Void... voids) {

            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            GenerateXMLFile file = GenerateXMLFile.getInstance();

            // Check if exists an internet connection
            if (XMLHttpPost.isConnectedToInternet(context)) {
                // SEND HTTP POST REQUEST
                String responseXML = null;

                // Create the xml request with the previous values
                List<SFBMessageInteractionAnalytic> list = new ArrayList<>();
                list.add(SFBMessageInteractionAnalytic);
                // Specific xml request using the values
                String fileXMLRequest = file.addMessageInteractions(list);

                try {
                    //Introduce XML and catch server response
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, context,
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    context).getUserCredentials()) );
                } catch (CertificateException | NoSuchAlgorithmException | KeyManagementException | IOException | KeyStoreException e) {
                    e.printStackTrace();
                }
                return true;
            } else {
                return false;
            }
        }

        @Override
        protected void onPreExecute() {
            try {
                mProgressDialog = new ProgressDialog(context);
                mProgressDialog.setMessage(getString(R.string.checking_user));
                mProgressDialog.setCancelable(false);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onPostExecute(final Boolean success) {

            mRateMessageTask = null;

            if(!success) { //Data not saved in server: store in local db temporally
                db.insertMessageInteractionToSend(SFBMessageInteractionAnalytic);

            }

        }
        @Override
        protected void onCancelled() {
            mRateMessageTask = null;
            try {
                if (mProgressDialog != null && mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}
