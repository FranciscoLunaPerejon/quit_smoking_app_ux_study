package com.salumedia.quitandreturn.views.forms;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ToggleButton;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.SFBFragment;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.views.dialogs.TimePickerDialogFragment;

import java.util.Arrays;

/**
 * Created by Francisco on 5/4/17.
 */

public class WeekDaysPreferencesFormFragment extends SFBFragment {

    // Tag used to identify the fragment and for analytical purpose
    public static final String TAG = "WEEK_DAYS_PREFERENCES_FORM";

    // Arrays with the view IDs on layout. It is used for iterative instantiation and reduce code

    private final int[] toggleWeekDaysId = new int[]{R.id.check_monday, R.id.check_tuesday, R.id.check_wednesday,
            R.id.check_thursday, R.id.check_friday, R.id.check_saturday, R.id.check_sunday};

    private final int[] beginButtonsId = new int[]{R.id.buttonBeginingMonday, R.id.buttonBeginingTuesday,
            R.id.buttonBeginingWednesday, R.id.buttonBeginingThursday, R.id.buttonBeginingFriday,
            R.id.buttonBeginingSaturday, R.id.buttonBeginingSunday};

    private final int[] endButtonsId = new int[]{R.id.buttonEndingMonday, R.id.buttonEndingTuesday,
            R.id.buttonEndingWednesday, R.id.buttonEndingThursday, R.id.buttonEndingFriday,
            R.id.buttonEndingSaturday, R.id.buttonEndingSunday};

    // Auxiliary attributes for store values selected for the user in this form

    private String[] dayWksPref;
    private String[] weekDaysAllowed = new String[7];
    private String[] intervalBeginValues = new String[7];
    private String[] intervalEndValues = new String[7];

    // Form fields
    private ToggleButton[] weekDaysToggleButtons = new ToggleButton[7];
    private Button[] intervalBeginButtons = new Button[7];
    private Button[] intervalEndButtons = new Button[7];

    // Access to shared preferences
    SessionData sessionData;

    // Auxiliary view to inflate the fragment. It is used in auxiliary methods, so it is set as an
    // attribute of the class
    View rootView;

    // Default necessary constructor
    public WeekDaysPreferencesFormFragment() {
    }

    // Constructor that allow receive information from the invoking class
    public static WeekDaysPreferencesFormFragment newInstance(Bundle arguments){

        WeekDaysPreferencesFormFragment f =  new WeekDaysPreferencesFormFragment();
        //Extract information if exists
        if(arguments != null){
            f.setArguments(arguments);
        }
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Not View attributes instantiation

        section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_TEST_WEEK_DAYS_PREFERENCES_FORM; // Analysis purpose

        sessionData = SessionData.getSessionData(getActivity()); // Shared preferences access
        dayWksPref = sessionData.getWeekDaysPreferences(); // Access to stored week days preferences

        // Get week days preferences correctly divided
        weekDaysAllowed = Arrays.copyOfRange(dayWksPref, 0, 7); // Weeks days that s/he wants receive messages
        intervalBeginValues = Arrays.copyOfRange(dayWksPref, 7, 14);  // Start hour for each week day
        intervalEndValues = Arrays.copyOfRange(dayWksPref, 14, 21); // End hour for each week day
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // Inflating the fragment
        rootView = inflater.inflate(R.layout.form_fragment_weekdays_preferences, container, false);

        // View attributes instantiation

        for (int day = 0; day < 7; day++) {
            weekDaysToggleButtons[day] = (ToggleButton) rootView.findViewById(toggleWeekDaysId[day]);
            intervalBeginButtons[day] = (Button) rootView.findViewById(beginButtonsId[day]);
            intervalEndButtons[day] = (Button) rootView.findViewById(endButtonsId[day]);

            setCurrentConfiguration(day);

            setToggleBehaviour(weekDaysToggleButtons[day], intervalBeginButtons[day], intervalEndButtons[day]);

            final int day_copy = day;
            View.OnClickListener showTimeOnClick = new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    intervalBeginButtons[day_copy].setTextColor(getResources().getColor(R.color.colorAccent));
                    intervalEndButtons[day_copy].setTextColor(getResources().getColor(R.color.colorAccent));
                    showTimePickerDialog(SFBConstantsAndCodes.END, v.getId());
                }
            };

            intervalBeginButtons[day].setOnClickListener(showTimeOnClick);
            intervalEndButtons[day].setOnClickListener(showTimeOnClick);
        }
        return rootView;
    }

    // fill the views with the previously saved weekDaysPreferences
    private void setCurrentConfiguration(int day) {
        String beginTimeV;
        String endTimeV;

        //Enable or disable buttons depending of saved weekDaysPreferences

        Boolean dayAllow = dayWksPref[day].equals("t");

        if (dayAllow) {
            weekDaysToggleButtons[day].setChecked(true);
            intervalBeginButtons[day].setEnabled(true);
            intervalEndButtons[day].setEnabled(true);
        } else {
            weekDaysToggleButtons[day].setChecked(false);
            intervalBeginButtons[day].setEnabled(false);
            intervalEndButtons[day].setEnabled(false);
        }

        // For usability, we keep the time values which are set for the user though he not allow to
        // sent messages in a specific day. In this way, user can fill the form faster if s/he decide
        // allow to send messages for this day week again.
        String hourBeginPref = intervalBeginValues[day];
        String hourEndPref = intervalEndValues[day];
        try {
            if (!hourBeginPref.contains("-1") && !hourEndPref.contains("-1")) {
                beginTimeV = normalize(hourBeginPref);
                endTimeV = normalize(hourEndPref);

            } else {

                beginTimeV = "08:00";
                endTimeV = "22:00";
            }
        }catch (StringIndexOutOfBoundsException e){
            beginTimeV = "08:00";
            endTimeV = "22:00";
        }
        intervalBeginButtons[day].setText(beginTimeV);
        intervalEndButtons[day].setText(endTimeV);
    }

    // Enable or disable the correspondent pair of time-buttons if toggle button associated is
    // checked or unchecked, respectively.
    private void setToggleBehaviour(ToggleButton dayAllowed, final Button timeBegin, final Button timeEnd) {
        dayAllowed.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                timeBegin.setEnabled(isChecked);
                timeEnd.setEnabled(isChecked);

            }
        });
    }

    // It invokes a timePicker dialog and send it necessary information
    private void showTimePickerDialog(boolean interval, int viewId) {
        DialogFragment newFragment = new TimePickerDialogFragment();
        Bundle bundle = new Bundle();
        bundle.putBoolean(SFBConstantsAndCodes.INTERVAL, interval);
        bundle.putInt(TimePickerDialogFragment.VIEW_ID, viewId);
        newFragment.setArguments(bundle);
        newFragment.show(getFragmentManager(), "timePicker");
    }

    // Auxiliary method to parse correctly the time information
    public String normalize(String answer) {
        String hours = answer.substring(0, answer.indexOf(":"));
        String minutes = answer.substring(answer.indexOf(":") + 1, answer.length());
        if (Integer.parseInt(hours) < 10 && hours.length() == 1) {
            hours = "0" + hours;
        }

        if (Integer.parseInt(minutes) < 10 && minutes.length() == 1) {
            minutes = "0" + minutes;
        }
        return hours + ":" + minutes;
    }

    // Update time intervals only if correspondent toggle button is checked and if pairs interval
    // buttons have different value (intervalBeginX == intervalEndX is not possible). Only if the
    // last case is false (at least a pair interval have same value), return empty array.
    public String[] checkForCorrectTimeValues(){

        String[] preferences;

        boolean correctValues = true;

        for (int day = 0; day < 7; day++) {
            if (weekDaysToggleButtons[day].isChecked()) {
                weekDaysAllowed[day] = "t";
                String intervalBegin = intervalBeginButtons[day].getText().toString();
                String intervalEnd = intervalEndButtons[day].getText().toString();
                if (!intervalBegin.equals(intervalEnd)) {
                    intervalBeginValues[day] = intervalBegin;
                    intervalEndValues[day] = intervalEnd;
                } else {
                    intervalBeginButtons[day].setTextColor(Color.RED);
                    intervalEndButtons[day].setTextColor(Color.RED);

                    correctValues = false;
                }
            } else {
                weekDaysAllowed[day] = "f";
            }
        }

        if (correctValues) {
            preferences = new String[21];
            // save data weekDaysPreferences in session data
            System.arraycopy(weekDaysAllowed, 0, preferences, 0, 7);
            System.arraycopy(intervalBeginValues, 0, preferences, 7, 7);
            System.arraycopy(intervalEndValues, 0, preferences, 14, 7);
        }else {
            preferences = new String[0];
        }

        return preferences;
    }

}
