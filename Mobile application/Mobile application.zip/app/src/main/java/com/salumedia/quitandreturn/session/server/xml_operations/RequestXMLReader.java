package com.salumedia.quitandreturn.session.server.xml_operations;

import com.salumedia.quitandreturn.model.SFBPersonalData;
import com.salumedia.quitandreturn.model.SFBQuittingAttempt;
import com.salumedia.quitandreturn.model.SFBSmokingData;
import com.salumedia.quitandreturn.model.SFBUser;
import com.salumedia.quitandreturn.utils.SFBCurrencyConversions;
import com.salumedia.quitandreturn.utils.SFBDate;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;




/**
 * Created by Francisco on 5/2/17.
 */

/**
 * This class process xml messages received by the server doing a sequential search
 */
public class RequestXMLReader extends DefaultHandler{

    private XMLReader read;
    private String XMLfile;

    private HashMap<String,String> savedValues;

    // Flags to know when it is in a specific section in the xml
    private boolean isInServerID = false;
    private boolean isInRetrieveId = false;
    private boolean isInRegisterDate = false;
    private boolean isInPersonalData = false;
    private boolean isInDemographicData = false;
    private boolean isInSmokingData = false;
    private boolean isInClinicalData = false;
    private boolean isInName = false;
    private boolean isInGender =false;
    private boolean isInBirthDate = false;
    private boolean isInEmploymentSituation = false;
    private boolean isInStartSmokingDate =false;
    private boolean isInIsInQuittinAttempt = false;
    private boolean isInQuittingAttemptList = false;
    private boolean isInQuittingAttempt = false;
    private boolean isInStartDate = false;
    private boolean isInEndDate = false;
    private boolean isInDailyCigarettes = false;
    private boolean isInWeeklyTobaccoExpenditure = false;
    private boolean isInCurrency = false;
    private boolean isInRichmondResult = false;
    private boolean isInFagerstromResult = false;
    private boolean isInClinicalGroup = false;
    private boolean isInPatientCode = false;
    private boolean isInExtendedProfile = false;
    private boolean isInExtendedFormQuestionResponse = false;
    private int extendedFormQuestionResponseIndex = 0;
    private boolean isInPreferences = false;
    private boolean isInLanguage = false;
    private boolean isInNotDisturb = false;
    private boolean isInDateNotDisturb = false;
    private boolean isInWeekDaysPreferences = false;
    private boolean isInAllowOnMonday = false;
    private boolean isInAllowOnTuesday = false;
    private boolean isInAllowOnWednesday = false;
    private boolean isInAllowOnThursday = false;
    private boolean isInAllowOnFriday = false;
    private boolean isInAllowOnSaturday = false;
    private boolean isInAllowOnSunday = false;
    private boolean isInBeginTimeMonday = false;
    private boolean isInBeginTimeTuesday = false;
    private boolean isInBeginTimeWednesday = false;
    private boolean isInBeginTimeThursday = false;
    private boolean isInBeginTimeFriday = false;
    private boolean isInBeginTimeSaturday = false;
    private boolean isInBeginTimeSunday = false;
    private boolean isInEndTimeMonday = false;
    private boolean isInEndTimeTuesday = false;
    private boolean isInEndTimeWednesday = false;
    private boolean isInEndTimeThursday = false;
    private boolean isInEndTimeFriday = false;
    private boolean isInEndTimeSaturday = false;
    private boolean isInEndTimeSunday = false;
    private boolean isInMessageList = true;
    private boolean isInMessage = false;
    private boolean isInMessageText = false;
    private boolean isInMessageServerId = false;
    private boolean isInIsRead = false;
    private boolean isInVote = false;
    private boolean isInReceivedDate = false;

    // Parameters to save the information contained in the xml file

    private String registerDate;

    private SFBUser user = new SFBUser();
    private SFBSmokingData smokingData = new SFBSmokingData();
    private SFBPersonalData personalData = new SFBPersonalData();
    private Integer clinicalGroup;
    private String patientCode = "";
    private List<SFBQuittingAttempt> quittingAttemptList = new ArrayList<>();
    private SFBQuittingAttempt quittingAttempt;
    private Boolean inQuittingAttempt;

    private String extendedProfileFormQuestionResponse;
    private List<Boolean[]> extendedProfileFormQuestionResponseList = new ArrayList<>();

    private String language;
    private String notDisturbElection;
    private String dateNotDisturb;
    private String[] weekDaysPreferences = new String[21];

    private String messageServerId;
    private String messageText;
    private String messageIsRead;
    private String messageVote;
    private String receivedDate;

    private List<String[]> messages = new ArrayList<>();


    public RequestXMLReader(String XMLfile){
        super();
        this.XMLfile = XMLfile;
        this.savedValues = new HashMap<>();
        initializeXMLReader();
    }
    
    private void initializeXMLReader() {
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();

            read = saxParser.getXMLReader();
            read.setContentHandler(this);
            read.setErrorHandler(this);
            // Before to process the file, the line breaks are erased .
            // TODO: [Juan Alvarez] When the file is null, it throws error.
            XMLfile = XMLfile == null ? "" : XMLfile.replaceAll("\n", "");
            if (!XMLfile.contains("<EHR_EXTRACT xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"")) {
                XMLfile = XMLfile.replace("<EHR_EXTRACT", "<EHR_EXTRACT xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
            }
            read.parse(new InputSource(new StringReader(XMLfile)));            // XML is processed.
        } catch (SAXException | IOException | ParserConfigurationException e) {
            e.printStackTrace();
        }
    }

    public String getRegisterDate(){
        return registerDate;
    }

    public SFBUser getUserData(){
        return user;
    }

    public Boolean getInQuittingAttempt(){
        return inQuittingAttempt;
    }

    public Integer getClinicalGroup() {
        return clinicalGroup;
    }

    public String getPatientCode(){
        return patientCode;
    }

    public List<Boolean[]> getExtendedProfileFormQuestionResponseList(){
        return extendedProfileFormQuestionResponseList;
    }

    public List<String[]> getMessages(){
        return messages;
    }

    public String getLanguage(){
        return language;
    }

    public String getNotDisturbElection(){
        return notDisturbElection;
    }

    public String getDateNotDisturb(){
        return dateNotDisturb;
    }

    public String[] getWeekDaysPreferences(){
        return weekDaysPreferences;
    }

    // Check if it is in the beginning of an XML element, that is, it is in the beginning of an specific section
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if(localName.equalsIgnoreCase("ServerID")){
            this.isInServerID = true;
        }
        else if(localName.equalsIgnoreCase("RetrieveID")){
            this.isInRetrieveId = true;
        }else if(localName.equalsIgnoreCase("register_date")){
            registerDate = "";
            this.isInRegisterDate = true;
        }else if(localName.equalsIgnoreCase("PersonalData")){
            this.isInPersonalData = true;
        }else if(localName.equalsIgnoreCase("Preferences")){
            this.isInPreferences = true;
        }else if(localName.equalsIgnoreCase("Messages")){
            this.isInMessageList = true;
        }else if(isInPersonalData) {
            if (localName.equalsIgnoreCase("DemographicData")) {
                this.isInDemographicData = true;
            } else if (localName.equalsIgnoreCase("SmokingData")) {
                this.isInSmokingData = true;
            } else if (localName.equalsIgnoreCase("ClinicalData")){
                this.isInClinicalData = true;
            }else if(localName.equalsIgnoreCase("ExtendedProfile")){
                this.isInExtendedProfile = true;
            }else if(isInDemographicData) {
                if (localName.equalsIgnoreCase("name")) {
                    this.isInName = true;
                }else if(localName.equalsIgnoreCase("gender")){
                    this.isInGender = true;
                }else if(localName.equalsIgnoreCase("birth_date")){
                    this.isInBirthDate = true;
                }else if(localName.equalsIgnoreCase("employment_situation")){
                    this.isInEmploymentSituation = true;
                }
            }else if(isInClinicalData){
                if(localName.equalsIgnoreCase("clinical_group")){
                    this.isInClinicalGroup = true;
                }else if(localName.equalsIgnoreCase("patient_code")){
                    this.isInPatientCode = true;
                }
            }else if(isInSmokingData){
                if(localName.equalsIgnoreCase("begin_smoking_date")){
                    this.isInStartSmokingDate = true;
                }else if(localName.equalsIgnoreCase("in_quitting_period")){
                    this.isInIsInQuittinAttempt = true;
                }else if(localName.equalsIgnoreCase("QuittingPeriods")){
                    this.isInQuittingAttemptList = true;
                }else if(isInQuittingAttemptList){
                    if(localName.equalsIgnoreCase("item")){
                        quittingAttempt = SFBQuittingAttempt.getInstance();
                        this.isInQuittingAttempt = true;
                    }else if(this.isInQuittingAttempt){
                        if(localName.equalsIgnoreCase("start_date")){
                            this.isInStartDate = true;
                        }else if(localName.equalsIgnoreCase("end_date")){
                            this.isInEndDate = true;
                        }else if(localName.equalsIgnoreCase("daily_cigarettes")){
                            this.isInDailyCigarettes = true;
                        }else if(localName.equalsIgnoreCase("weekly_expenditure")){
                            this.isInWeeklyTobaccoExpenditure = true;
                        }else if(localName.equalsIgnoreCase("currency")){
                            this.isInCurrency = true;
                        }else if(localName.equalsIgnoreCase("richmond_result")){
                            this.isInRichmondResult = true;
                        }else if(localName.equalsIgnoreCase("fagerstrom_result")){
                            this.isInFagerstromResult = true;
                        }
                    }
                }
            }else if(isInExtendedProfile){
                if(localName.contains("extended_question_")){
                    this.isInExtendedFormQuestionResponse = true;
                    this.extendedFormQuestionResponseIndex = Integer.valueOf(localName.split("_")[2]);
                    extendedProfileFormQuestionResponse = "";
                }
            }
        }else if(isInPreferences){
            if(localName.equalsIgnoreCase("language")){
                isInLanguage = true;
            }else if(localName.equalsIgnoreCase("not_disturb")){
                isInNotDisturb = true;
            }else if (localName.equalsIgnoreCase("date_not_disturb")){
                dateNotDisturb = "";
                isInDateNotDisturb = true;
            }else if(localName.equalsIgnoreCase("WeekDaysPreferences")){
                isInWeekDaysPreferences = true;
            }else if(isInWeekDaysPreferences){
                if(localName.equalsIgnoreCase("allow_on_monday")){
                    isInAllowOnMonday = true;
                }else if(localName.equalsIgnoreCase("allow_on_tuesday")){
                    isInAllowOnTuesday = true;
                }else if(localName.equalsIgnoreCase("allow_on_wednesday")){
                    isInAllowOnWednesday = true;
                }else if(localName.equalsIgnoreCase("allow_on_thursday")){
                    isInAllowOnThursday = true;
                }else if(localName.equalsIgnoreCase("allow_on_friday")){
                    isInAllowOnFriday = true;
                }else if(localName.equalsIgnoreCase("allow_on_saturday")){
                    isInAllowOnSaturday = true;
                }else if(localName.equalsIgnoreCase("allow_on_sunday")){
                    isInAllowOnSunday = true;
                }else if(localName.equalsIgnoreCase("begin_time_monday")){
                    isInBeginTimeMonday = true;
                }else if(localName.equalsIgnoreCase("begin_time_tuesday")){
                    isInBeginTimeTuesday = true;
                }else if(localName.equalsIgnoreCase("begin_time_wednesday")){
                    isInBeginTimeWednesday = true;
                }else if(localName.equalsIgnoreCase("begin_time_thursday")){
                    isInBeginTimeThursday = true;
                }else if(localName.equalsIgnoreCase("begin_time_friday")){
                    isInBeginTimeFriday = true;
                }else if(localName.equalsIgnoreCase("begin_time_saturday")){
                    isInBeginTimeSaturday = true;
                }else if(localName.equalsIgnoreCase("begin_time_sunday")){
                    isInBeginTimeSunday = true;
                }else if(localName.equalsIgnoreCase("end_time_monday")){
                    isInEndTimeMonday = true;
                }else if(localName.equalsIgnoreCase("end_time_tuesday")){
                    isInEndTimeTuesday = true;
                }else if(localName.equalsIgnoreCase("end_time_wednesday")){
                    isInEndTimeWednesday = true;
                }else if(localName.equalsIgnoreCase("end_time_thursday")){
                    isInEndTimeThursday = true;
                }else if(localName.equalsIgnoreCase("end_time_friday")){
                    isInEndTimeFriday = true;
                }else if(localName.equalsIgnoreCase("end_time_saturday")){
                    isInEndTimeSaturday = true;
                }else if(localName.equalsIgnoreCase("end_time_sunday")){
                    isInEndTimeSunday = true;
                }
            }
        }
        else if(isInMessageList){
            if(localName.equalsIgnoreCase("item")){
                this.isInMessage = true;
            }else if(isInMessage){
                if(localName.equalsIgnoreCase("id_server")){
                    isInMessageServerId = true;
                }else if(localName.equalsIgnoreCase("text")){
                    messageText = "";
                    isInMessageText = true;
                }else if(localName.equalsIgnoreCase("is_read")){
                    this.isInIsRead = true;
                }else if(localName.equalsIgnoreCase("vote")){
                    this.isInVote = true;
                }else if(localName.equalsIgnoreCase("received_date")){
                    receivedDate = "";
                    this.isInReceivedDate = true;
                }
            }
        }
    }
    // When it is in the end of a XML element, a section is finished. If it is the end of a main section,
    // maybe it is necessary to store some previous saved data in an object more complex.
    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if(localName.equalsIgnoreCase("ServerID")){
            this.isInServerID = false;
        }else if(localName.equalsIgnoreCase("RetrieveID")){
            this.isInRetrieveId = false;
        }else if(localName.equalsIgnoreCase("register_date")){
            this.isInRegisterDate = false;
        }else if(localName.equalsIgnoreCase("Messages")){
            this.isInMessageList = false;
        }else if(localName.equalsIgnoreCase("Preferences")){
            this.isInPreferences = false;
        }else if (localName.equalsIgnoreCase("ExtendedProfile")){
            this.isInExtendedProfile = false;
        }else if (localName.equalsIgnoreCase("SmokingData")) {
            this.isInSmokingData = false;
            user.setSmokingData(smokingData);
        }else if (localName.equalsIgnoreCase("DemographicData")) {
            this.isInDemographicData = false;
            user.setPersonalData(personalData);
        } else if(localName.equalsIgnoreCase("ClinicalData")){
            this.isInClinicalData = false;
        } else if(localName.equalsIgnoreCase("PersonalData")){
            this.isInPersonalData = false;
        }else if(isInPersonalData){
            if(isInDemographicData) {
                if (localName.equalsIgnoreCase("name")) {
                    this.isInName = false;
                } else if (localName.equalsIgnoreCase("gender")) {
                    this.isInGender = false;
                } else if (localName.equalsIgnoreCase("birth_date")) {
                    this.isInBirthDate = false;
                } else if (localName.equalsIgnoreCase("employment_situation")) {
                    this.isInEmploymentSituation = false;
                }
            }
            else if(isInClinicalData){
                if(localName.equalsIgnoreCase("clinical_group")){
                    this.isInClinicalGroup = false;
                }else if (localName.equalsIgnoreCase("patient_code")){
                    this.isInPatientCode = false;
                }
            }else if(isInSmokingData){
                if(localName.equalsIgnoreCase("begin_smoking_date")){
                    this.isInStartSmokingDate = false;
                } else if(localName.equalsIgnoreCase("in_quitting_period")){
                    this.isInIsInQuittinAttempt = false;
                } else if(localName.equalsIgnoreCase("QuittingPeriods")){
                    smokingData.setQuittingAttempts(quittingAttemptList);
                    this.isInQuittingAttemptList = false;
                } else if(isInQuittingAttemptList){
                    if(localName.equalsIgnoreCase("item")){
                        quittingAttemptList.add(quittingAttempt);
                        this.isInQuittingAttempt = false;
                    }else if(this.isInQuittingAttempt){
                        if(localName.equalsIgnoreCase("start_date")){
                            this.isInStartDate = false;
                        }else if(localName.equalsIgnoreCase("end_date")){
                            this.isInEndDate = false;
                        }else if(localName.equalsIgnoreCase("daily_cigarettes")){
                            this.isInDailyCigarettes = false;
                        }else if(localName.equalsIgnoreCase("weekly_expenditure")){
                            this.isInWeeklyTobaccoExpenditure = false;
                        }else if(localName.equalsIgnoreCase("currency")){
                            this.isInCurrency = false;
                        }else if(localName.equalsIgnoreCase("richmond_result")){
                            this.isInRichmondResult = false;
                        }else if(localName.equalsIgnoreCase("fagerstrom_result")){
                            this.isInFagerstromResult = false;
                        }
                    }
                }
            } else if(isInExtendedProfile){
                if(localName.contains("extended_question_")){
                    Boolean[] questionResponses = new Boolean[extendedProfileFormQuestionResponse.length()];
                    for(int i = 0; i<extendedProfileFormQuestionResponse.length();i++){
                        questionResponses[i] = extendedProfileFormQuestionResponse.charAt(i) == '1';
                    }
                    extendedProfileFormQuestionResponseList.add(questionResponses);
                    this.isInExtendedFormQuestionResponse = false;
                }
            }
        }else if(isInPreferences){
            if(localName.equalsIgnoreCase("language")){
                isInLanguage = false;
            }else if(localName.equalsIgnoreCase("not_disturb")){
                isInNotDisturb = false;
            }else if (localName.equalsIgnoreCase("date_not_disturb")){
                isInDateNotDisturb = false;
            }else if(localName.equalsIgnoreCase("WeekDaysPreferences")){
                isInWeekDaysPreferences = false;
            }else if(isInWeekDaysPreferences){
                if(localName.equalsIgnoreCase("allow_on_monday")){
                    isInAllowOnMonday = false;
                }else if(localName.equalsIgnoreCase("allow_on_tuesday")){
                    isInAllowOnTuesday = false;
                }else if(localName.equalsIgnoreCase("allow_on_wednesday")){
                    isInAllowOnWednesday = false;
                }else if(localName.equalsIgnoreCase("allow_on_thursday")){
                    isInAllowOnThursday = false;
                }else if(localName.equalsIgnoreCase("allow_on_friday")){
                    isInAllowOnFriday = false;
                }else if(localName.equalsIgnoreCase("allow_on_saturday")){
                    isInAllowOnSaturday = false;
                }else if(localName.equalsIgnoreCase("allow_on_sunday")){
                    isInAllowOnSunday = false;
                }else if(localName.equalsIgnoreCase("begin_time_monday")){
                    isInBeginTimeMonday = false;
                }else if(localName.equalsIgnoreCase("begin_time_tuesday")){
                    isInBeginTimeTuesday = false;
                }else if(localName.equalsIgnoreCase("begin_time_wednesday")){
                    isInBeginTimeWednesday = false;
                }else if(localName.equalsIgnoreCase("begin_time_thursday")){
                    isInBeginTimeThursday = false;
                }else if(localName.equalsIgnoreCase("begin_time_friday")){
                    isInBeginTimeFriday = false;
                }else if(localName.equalsIgnoreCase("begin_time_saturday")){
                    isInBeginTimeSaturday = false;
                }else if(localName.equalsIgnoreCase("begin_time_sunday")){
                    isInBeginTimeSunday = false;
                }else if(localName.equalsIgnoreCase("end_time_monday")){
                    isInEndTimeMonday = false;
                }else if(localName.equalsIgnoreCase("end_time_tuesday")){
                    isInEndTimeTuesday = false;
                }else if(localName.equalsIgnoreCase("end_time_wednesday")){
                    isInEndTimeWednesday = false;
                }else if(localName.equalsIgnoreCase("end_time_thursday")){
                    isInEndTimeThursday = false;
                }else if(localName.equalsIgnoreCase("end_time_friday")){
                    isInEndTimeFriday = false;
                }else if(localName.equalsIgnoreCase("end_time_saturday")){
                    isInEndTimeSaturday = false;
                }else if(localName.equalsIgnoreCase("end_time_sunday")){
                    isInEndTimeSunday = false;
                }
            }
        }else if(isInMessageList){
            if(localName.equalsIgnoreCase("item")){
                messages.add(new String[]{messageServerId, messageText, messageIsRead, messageVote, receivedDate});
                this.isInMessage = false;
            }else if(this.isInMessage){
                if(localName.equalsIgnoreCase("id_server")){
                    this.isInMessageServerId = false;
                }else if(localName.equalsIgnoreCase("text")){
                    this.isInMessageText = false;
                }else if(localName.equalsIgnoreCase("is_read")){
                    this.isInIsRead = false;
                }else if(localName.equalsIgnoreCase("vote")){
                    this.isInVote = false;
                }else if(localName.equalsIgnoreCase("received_date")){
                    this.isInReceivedDate = false;
                }
            }
        }
    }

    // It process, extract and save the information of an specific parameter depends on in which section it is.
    // NOTE: this method can be invoked more than once per section if the content is too large.
    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String aux;
        if(this.isInServerID){
            savedValues.put("serverID", new String(Arrays.copyOfRange(ch, start, length)));
        }
        else if(this.isInRetrieveId){
            savedValues.put(("retrieveID"), new String(Arrays.copyOfRange(ch, start, length)));
        }
        else if(this.isInRegisterDate){
            registerDate = registerDate.concat(new String(Arrays.copyOfRange(ch, start, length)));
        }else if(this.isInPersonalData) {
            if (this.isInDemographicData) {
                aux = new String(Arrays.copyOfRange(ch, start, length));
                if(!aux.equals("null")) {
                    if (this.isInName) {
                        personalData.setName(aux);
                    } else if (this.isInGender) {
                        personalData.setGender(aux.toCharArray()[0]);
                    } else if (this.isInBirthDate) {
                        personalData.setBirthDate(SFBDate.stringToCalendar(aux));
                    } else if (this.isInEmploymentSituation) {
                        personalData.setEmploymentStatus(aux);
                    }
                }
            } else if(this.isInClinicalData){
                aux = new String(Arrays.copyOfRange(ch, start, length));
                if(!aux.equals("null")){
                    if(this.isInClinicalGroup){
                        clinicalGroup = Integer.valueOf(aux);
                    }else if(this.isInPatientCode){
                        patientCode = patientCode.concat(aux);
                    }
                }
            } else if (this.isInSmokingData) {
                aux = new String(Arrays.copyOfRange(ch, start, length));
                if(!aux.equals("null")) {
                    if (this.isInStartSmokingDate) {
                        smokingData.setDateStartingSmoking(SFBDate.stringToCalendar(aux));
                    }else if(this.isInIsInQuittinAttempt){
                        inQuittingAttempt = aux.equals("true");
                    }else if(this.isInQuittingAttemptList){
                        if(this.isInQuittingAttempt){
                            if(this.isInStartDate){
                                quittingAttempt.setQuittingDate(SFBDate.stringToCalendar(aux));
                            }else if(this.isInEndDate){
                                quittingAttempt.setQuittingEndDate(SFBDate.stringToCalendar(aux));
                            }else if (this.isInDailyCigarettes) {
                                quittingAttempt.setPreviousDailyCigarettes(Float.parseFloat(aux));
                            } else if (this.isInWeeklyTobaccoExpenditure) {
                                quittingAttempt.setWeeklyTobaccoExpenditure(Float.parseFloat(aux));
                            }else if(this.isInCurrency){
                                quittingAttempt.setCurrency(SFBCurrencyConversions.currencyISOCodeToSymbol(aux));
                            }else if(this.isInRichmondResult){
                                quittingAttempt.setRichmondTestResult(Integer.parseInt(aux));
                            }else if(this.isInFagerstromResult){
                                quittingAttempt.setFagerstromTestResult(Integer.parseInt(aux));
                            }
                        }
                    }
                }
            } else if (this.isInExtendedProfile){
                aux = new String(Arrays.copyOfRange(ch, start, length));
                if(this.isInExtendedFormQuestionResponse){
                    extendedProfileFormQuestionResponse = extendedProfileFormQuestionResponse.concat(aux);
                    System.out.println(extendedFormQuestionResponseIndex);
                }
            }
        }else if(this.isInPreferences){
            aux = new String(Arrays.copyOfRange(ch,start, length));
            if(this.isInLanguage){
                language = aux;
            }else if(this.isInNotDisturb){
                notDisturbElection = aux;
            }else if(this.isInDateNotDisturb){
                dateNotDisturb = dateNotDisturb.concat(aux);
            }else if(this.isInWeekDaysPreferences){
                if(this.isInAllowOnMonday){
                    weekDaysPreferences[0] = aux;
                }else if(this.isInAllowOnTuesday){
                    weekDaysPreferences[1] = aux;
                }else if(this.isInAllowOnWednesday){
                    weekDaysPreferences[2] = aux;
                }else if(this.isInAllowOnThursday){
                    weekDaysPreferences[3] = aux;
                }else if(this.isInAllowOnFriday){
                    weekDaysPreferences[4] = aux;
                }else if(this.isInAllowOnSaturday){
                    weekDaysPreferences[5] = aux;
                }else if(this.isInAllowOnSunday){
                    weekDaysPreferences[6] = aux;
                }else if(this.isInBeginTimeMonday){
                    weekDaysPreferences[7] = aux;
                }else if(this.isInBeginTimeTuesday){
                    weekDaysPreferences[8] = aux;
                }else if(this.isInBeginTimeWednesday){
                    weekDaysPreferences[9] = aux;
                }else if(this.isInBeginTimeThursday){
                    weekDaysPreferences[10] = aux;
                }else if(this.isInBeginTimeFriday){
                    weekDaysPreferences[11] = aux;
                }else if(this.isInBeginTimeSaturday){
                    weekDaysPreferences[12] = aux;
                }else if(this.isInBeginTimeSunday){
                    weekDaysPreferences[13] = aux;
                }else if(this.isInEndTimeMonday){
                    weekDaysPreferences[14] = aux;
                }else if(this.isInEndTimeTuesday){
                    weekDaysPreferences[15] = aux;
                }else if(this.isInEndTimeWednesday){
                    weekDaysPreferences[16] = aux;
                }else if(this.isInEndTimeFriday){
                    weekDaysPreferences[17] = aux;
                }else if(this.isInEndTimeThursday){
                    weekDaysPreferences[18] = aux;
                }if(this.isInEndTimeSaturday){
                    weekDaysPreferences[19] = aux;
                }else if(this.isInEndTimeSunday){
                    weekDaysPreferences[20] = aux;
                }
            }
        }else if(this.isInMessageList){
            if(this.isInMessage){
                aux = new String(Arrays.copyOfRange(ch,start, length));
                if(this.isInMessageServerId){
                    messageServerId = aux;
                }else if(this.isInMessageText){
                    messageText = messageText.concat(aux);
                }else if(this.isInIsRead){
                    messageIsRead = aux;
                }else if(this.isInVote){
                    messageVote =aux;
                }else if(this.isInReceivedDate){
                    receivedDate = receivedDate.concat(aux);
                }
            }
        }
    }
}
