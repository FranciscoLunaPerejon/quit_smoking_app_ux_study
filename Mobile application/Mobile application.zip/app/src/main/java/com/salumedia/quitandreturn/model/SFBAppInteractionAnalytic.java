package com.salumedia.quitandreturn.model;

/**
 * Created by Francisco on 25/3/17.
 */

/**
 * Used to create app interaction instances, for analytical purpose, that contains information
 * about the time spend in a section.
 */
public class SFBAppInteractionAnalytic {

    private String tagName, date, time;
    private Float milliSecondsDuration;

    public SFBAppInteractionAnalytic(String tagName, String date, String time, Float milliSecondsDuration) {
        this.tagName = tagName;
        this.date = date;
        this.time = time;
        this.milliSecondsDuration = milliSecondsDuration;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Float getMilliSecondsDuration() {
        return milliSecondsDuration;
    }

    public void setMilliSecondsDuration(Float milliSecondsDuration) {
        this.milliSecondsDuration = milliSecondsDuration;
    }

    @Override
    public String toString() {
        return "SFBAppInteractionAnalytic{" +
                "tagName='" + tagName + '\'' +
                ", date='" + date + '\'' +
                ", time='" + time + '\'' +
                ", milliSecondsDuration=" + milliSecondsDuration +
                '}';
    }
}
