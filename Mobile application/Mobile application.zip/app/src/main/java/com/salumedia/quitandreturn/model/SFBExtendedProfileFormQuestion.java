package com.salumedia.quitandreturn.model;

import java.util.Arrays;

/**
 * Created by Francisco on 16/6/17.
 */

public class SFBExtendedProfileFormQuestion {

    private String questionTag;
    private String title;
    private String description;
    private String typeQuestion;
    private Integer numberOfAnswers;
    private String[] answerTexts;
    private Boolean[] answerResponses;

    public static SFBExtendedProfileFormQuestion newInstance(String questionId, String title, String description, String typeQuestion, Integer numberOfAnswers, String[] answersTexts){
        return new SFBExtendedProfileFormQuestion(questionId,title,description,typeQuestion,numberOfAnswers,answersTexts);
    }

    public static SFBExtendedProfileFormQuestion newInstance(String questionId, String title, String description, String typeQuestion, Integer numberOfAnswers, String[] answersTexts, Boolean[] answerResponses){
        return new SFBExtendedProfileFormQuestion(questionId,title,description,typeQuestion,numberOfAnswers,answersTexts, answerResponses);
    }

    private SFBExtendedProfileFormQuestion(String questionTag, String title, String description, String typeQuestion, Integer numberOfAnswers, String[] answerTexts) {
        this.questionTag = questionTag;
        this.title = title;
        this.description = description;
        this.typeQuestion = typeQuestion;
        this.numberOfAnswers = numberOfAnswers;
        this.answerTexts = answerTexts;
        this.answerResponses = new Boolean[answerTexts.length];
        Arrays.fill(this.answerResponses, false);
    }

    private SFBExtendedProfileFormQuestion(String questionTag, String title, String description, String typeQuestion, Integer numberOfAnswers, String[] answerTexts, Boolean[] answerResponses) {
        this.questionTag = questionTag;
        this.title = title;
        this.description = description;
        this.typeQuestion = typeQuestion;
        this.numberOfAnswers = numberOfAnswers;
        this.answerTexts = answerTexts;
        this.answerResponses = answerResponses;
    }

    public String getQuestionTag() {
        return questionTag;
    }

    public void setQuestionTag(String questionTag) {
        this.questionTag = questionTag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTypeQuestion() {
        return typeQuestion;
    }

    public void setTypeQuestion(String typeQuestion) {
        this.typeQuestion = typeQuestion;
    }

    public Integer getNumberOfAnswers() {
        return numberOfAnswers;
    }

    public void setNumberOfAnswers(Integer numberOfAnswers) {
        this.numberOfAnswers = numberOfAnswers;
    }

    public String[] getAnswerTexts() {
        return answerTexts;
    }

    public void setAnswerTexts(String[] answerTexts) {
        this.answerTexts = answerTexts;
    }


    public Boolean[] getAnswerResponses() {
        return answerResponses;
    }
    public void setAnswerResponses(Boolean[] answerResponses) {
        this.answerResponses = answerResponses;
    }


    @Override
    public String toString() {
        return "SFBExtendedProfileFormQuestion{" +
                "questionTag='" + questionTag + '\'' +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", typeQuestion='" + typeQuestion + '\'' +
                ", numberOfAnswers=" + numberOfAnswers +
                ", answerTexts=" + Arrays.toString(answerTexts) +
                '}';
    }
}

