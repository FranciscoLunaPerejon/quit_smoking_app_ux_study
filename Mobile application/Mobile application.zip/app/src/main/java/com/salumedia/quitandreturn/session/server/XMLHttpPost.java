package com.salumedia.quitandreturn.session.server;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.salumedia.quitandreturn.session.local.SessionData;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Locale;
import java.util.TimeZone;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;


/**
 * Created by joaquin on 7/6/16.
 */

public class XMLHttpPost {
    public static final String URL_MIRTH = "http://introduceYourServerIP:903/myrestservice/";
    final static HostnameVerifier DO_NOT_VERIFY = new HostnameVerifier() {
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    };

    /**
     * Trust every server - dont check for any certificate
     */
    private static void trustAllHosts() {
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[]{};
            }

            public void checkClientTrusted(X509Certificate[] chain,
                                           String authType) throws CertificateException {
            }

            public void checkServerTrusted(X509Certificate[] chain,
                                           String authType) throws CertificateException {
            }
        }};

        // Install the all-trusting trust manager
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection
                    .setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // "http://10.100.125.136:90/";
    public static String envioXmlHttpPost(String archivoXML, Context context, String logcat) throws
            CertificateException, KeyStoreException, IOException, NoSuchAlgorithmException, KeyManagementException {

        ////////////////////////////////////////////////////////////////////////////////////////////
        // TODO This part of code is to add a certificate to the HTTP post communication.
        // For the moment, it's useless because SSL isn't implemented in the server
 /*       CertificateFactory cf = CertificateFactory.getInstance("X.509");

        InputStream caInput;

        caInput = context.getApplicationContext().getResources().openRawResource(R.raw.juntadaes);

        Certificate ca;
        try {
            ca = cf.generateCertificate(caInput);
        } finally {
            caInput.close();
        }

        // Crea keystore con nuestras CA verdaderas
        String keyStoreType = KeyStore.getDefaultType();
        KeyStore keyStore = KeyStore.getInstance(keyStoreType);
        keyStore.load(null, null);
        keyStore.setCertificateEntry("ca", ca);

        // Crea un TrustManager que confia en mis CA
        String tmfAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(tmfAlgorithm);
        tmf.init(keyStore);

        // Crea SSLContext que usa TrustManager
        SSLContext contextssl = SSLContext.getInstance("TLS");
        contextssl.init(null, tmf.getTrustManagers(), null);
*/
        ///////////////////////////////// END CODE PART FOR CERTIFICATE //////////////////////////

        String strResponse = "";
/*
        DefaultHttpClient hc = new DefaultHttpClient();
        //Donde se enviará los parámetros vía POST.

        hc.getParams().setParameter(CoreProtocolPNames.PROTOCOL_VERSION, HttpVersion.HTTP_1_1);
        HttpPost hp = new HttpPost(URL_MIRTH);
        trustAllHosts();

        hp.addHeader("Content-Type", "application/xml");
        hp.addHeader("Accept", "text/xml");
*/
        URL url = new URL(URL_MIRTH);
        HttpURLConnection connection = (HttpURLConnection)url.openConnection();

        connection.setRequestProperty("Content-Type", "application/xml");
        connection.setRequestProperty("Accept", "text/xml");
        connection.setRequestMethod("POST");

        if(logcat!=null){
            connection.setRequestProperty("Authorization", "Basic  " + logcat);
            connection.setRequestProperty("fcmToken", "key=" + SessionData.getSessionData(context).getFCMToken());
            connection.setRequestProperty("timeZone", TimeZone.getDefault().getID());
            connection.setRequestProperty("language", Locale.getDefault().toString());
        }

        connection.setDoInput(true);
        connection.setDoOutput(true);

        try {
            /*
            // Adding data to send.
            StringEntity valor = new StringEntity(archivoXML, "UTF-8");
            // valor.setContentType("application/xml");
            hp.setEntity(valor);
            // Sending params.
            HttpResponse resp = hc.execute(hp);*/

            OutputStream output = new BufferedOutputStream(connection.getOutputStream());
            output.write(archivoXML.getBytes());
            output.flush();

            connection.connect();


            // Y la respuesta la devolvemos en un String.
            /*            if (resp.getStatusLine().getStatusCode() == 200) {
                BufferedReader rd = new BufferedReader(new InputStreamReader(resp.getEntity().getContent()));
                String line;
                do{
                    line = rd.readLine();
                    strResponse += line;
                }while (line != null);
            }else if(resp.getStatusLine().getStatusCode() == 201)
                strResponse = "created";
            else if(resp.getStatusLine().getStatusCode() == 401)
                strResponse = "unauthorized";
            else if(resp.getStatusLine().getStatusCode() == 403)
                strResponse = "forbidden";
            else if(resp.getStatusLine().getStatusCode() == 405)
                strResponse = "method_not_allowed";
            else
                strResponse = "error"; */

            if (connection.getResponseCode() == 200) {
            /*    BufferedReader rd = new BufferedReader(new InputStreamReader(resp.getEntity().getContent()));
                String line;
                do{
                    line = rd.readLine();
                    strResponse += line;
                }while (line != null);*/
                InputStream inputStream = connection.getInputStream();
                StringBuffer strBufferResponse = new StringBuffer("");

                BufferedReader rd =  new BufferedReader(new InputStreamReader(inputStream));
                String line = "";
                while ((line = rd.readLine()) != null) {
                    strBufferResponse.append(line);
                }
                strResponse = strBufferResponse.toString();
            }else if(connection.getResponseCode() == 201)
                strResponse = "created";
            else if(connection.getResponseCode() == 401)
                strResponse = "unauthorized";
            else if(connection.getResponseCode() == 403)
                strResponse = "forbidden";
            else if(connection.getResponseCode() == 405)
                strResponse = "method_not_allowed";
            else
                strResponse = "error";

        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            connection.disconnect();
        }

        return strResponse;
    }

    public static boolean isConnectedToInternet(Context context) {
        ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo nInf = connMgr.getActiveNetworkInfo();
        return nInf != null && nInf.isConnected();
    }
}
