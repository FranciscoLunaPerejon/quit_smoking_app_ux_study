package com.salumedia.quitandreturn.views.forms;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.SFBFragment;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;


/**
 * Created by Francisco on 13/1/17.
 */

/**
 * A fragment that shows the fagerstrom form
 */
public class TestFagerstromFormFragment extends SFBFragment {

    // Tag used to identify the fragment and for analytical purpose
    public static final String TAG = "TEST_FAGERSTROM_FORM";

    // Access to shared preferences
    SessionData sessionData;

    // Default necessary constructor
    public TestFagerstromFormFragment() {
    }

    // Constructor that allow receive information from the invoking class
    public static TestFagerstromFormFragment newInstance(Bundle arguments) {

        TestFagerstromFormFragment f = new TestFagerstromFormFragment();
        if (arguments != null) {
            f.setArguments(arguments);
        }
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Not View attributes instantiation
        section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_TEST_FAGERSTROM_FORM; // Analysis purpose
        sessionData = SessionData.getSessionData(getContext());
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // Inflating the fragment
        View rootView = inflater.inflate(R.layout.form_fragment_test_fagerstrom, container, false);

        // Check if this form was filled in the past and if questions responses are saved in shared
        // preferences (session data). Positive Case: show the previous responses.
        if(sessionData.isFilledFagerstromTest()){
            int[] list = {R.id.fagerstrom_q1,R.id.fagerstrom_q2, R.id.fagerstrom_q3,
                    R.id.fagerstrom_q4, R.id.fagerstrom_q5, R.id.fagerstrom_q6};
            Integer[] answers = sessionData.getFagerstromAnswers();
            if(!answers[0].equals(-1)) {
                RadioGroup radioGroup;
                RadioButton radioButton;
                for (int i = 0; i < list.length; i++) {
                    radioGroup = (RadioGroup) rootView.findViewById(list[i]);
                    radioButton = (RadioButton) radioGroup.getChildAt(answers[i]);
                    radioButton.setChecked(true);
                }
            }
        }

        return rootView;
    }

}
