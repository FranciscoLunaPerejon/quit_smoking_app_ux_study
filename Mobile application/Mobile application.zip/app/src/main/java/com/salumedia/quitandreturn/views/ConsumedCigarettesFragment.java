package com.salumedia.quitandreturn.views;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.SFBFragment;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;


/**
 * Created by Francisco on 22/5/17.
 */

public class ConsumedCigarettesFragment extends SFBFragment {

    // Tag used to identify the fragment and for analytical purpose
    public static final String TAG = "CONSUMED_CIGARETTES";

    // Access to shared preferences

    // Auxiliary view to inflate the fragment. It is used in auxiliary methods, so it is set as an
    // attribute of the class
    View rootView;

    // Default necessary constructor
    public ConsumedCigarettesFragment() {
    }

    // Constructor that allow receive information from the invoking class
    public static ConsumedCigarettesFragment newInstance(Bundle arguments){

        ConsumedCigarettesFragment f =  new ConsumedCigarettesFragment();
        //Extract information if exists
        if(arguments != null){
            f.setArguments(arguments);
        }
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Not View attributes instantiation
        section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_TEST_CIGARETTES_CONSUMED_QUESTION; // Analysis purpose
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Inflating the dialog fragment
        rootView = inflater.inflate(R.layout.form_fragment_consumed_cigarettes, null);

        return rootView;
    }
}
