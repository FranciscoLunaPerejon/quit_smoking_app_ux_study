package com.salumedia.quitandreturn.model;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by joaquin on 11/5/16.
 */


public class SFBPersonalData {

    private String name;
    private String surname1;
    private String surname2;
    private Character gender;
    private Calendar birthDate;
    private String employmentStatus;
    private String photo;

    public SFBPersonalData(String name, Character gender, Calendar birthDate, String employmentStatus) {
        this.name = name;
        this.gender = gender;
        this.birthDate = birthDate;
        this.employmentStatus = employmentStatus;
    }

    public SFBPersonalData(String name, Character gender, Calendar birthDate, String employmentStatus, String urlPhoto) {
        this.name = name;
        this.gender = gender;
        this.birthDate = birthDate;
        this.employmentStatus = employmentStatus;
        this.photo = urlPhoto;
    }

    public SFBPersonalData(String userName, String photo) {
        this.name = userName;
        this.photo = photo;
    }

    public SFBPersonalData() {

    }


    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Character getGender() {
        return gender;
    }

    public void setGender(Character gender){
        this.gender = gender;
    }

    public Calendar getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Calendar birthDate) {
        this.birthDate = birthDate;
    }

    public Integer getCurrentAge() {
        Calendar calendarNow = Calendar.getInstance(); // Calendario para zona determinada
        Date now = new Date(); // fecha actual
        calendarNow.setTime(now); // establecemos el calendario a la fecha actual
        Calendar calendarBirth = (Calendar) this.birthDate.clone(); // copiamos la fecha de nacimiento
        // Si el cumpleanios no ha sido aun este anio
        if (calendarNow.get(Calendar.DAY_OF_YEAR) < calendarBirth.get(Calendar.DAY_OF_YEAR)){
            // la edad es la diferencia entre el anio de nacimiento y el actual menos 1, el anio actual
            return calendarNow.get(Calendar.YEAR)-calendarBirth.get(Calendar.YEAR)-1;
        } else {
            // Si no, es la diferencia de anios sin mas
            return calendarNow.get(Calendar.YEAR)-calendarBirth.get(Calendar.YEAR);
        }
    }

    public String getPhoto() {
        return photo;
    }

    public String getEmploymentStatus() {
        return employmentStatus;
    }

    public void setEmploymentStatus(String employmentStatus) {
        this.employmentStatus = employmentStatus;
    }

    @Override
    public String toString() {
        return "SFBPersonalData{" +
                "name='" + name + '\'' +
                ", surname1='" + surname1 + '\'' +
                ", surname2='" + surname2 + '\'' +
                ", gender=" + gender +
                ", birthDate=" + birthDate +
                ", employmentStatus='" + employmentStatus + '\'' +
                ", photo=" + photo +
                '}';
    }
}
