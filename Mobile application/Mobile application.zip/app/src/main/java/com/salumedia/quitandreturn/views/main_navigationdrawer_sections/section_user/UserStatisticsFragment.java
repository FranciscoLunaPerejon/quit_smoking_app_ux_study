package com.salumedia.quitandreturn.views.main_navigationdrawer_sections.section_user;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBNotification;
import com.salumedia.quitandreturn.model.SFBQuittingAttempt;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.TextThumbSeekBar;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;



/**
 * Class that shows the achievements and seek bars if the user is in a quitting period. This also
 * contains access to personal data
 */
public class UserStatisticsFragment extends Fragment {

    // Personalized listener used to send information to container activity
    private OnBenefitsFragmentInteractionListener mListener;

    // View attributes

    private TextView welcomeText;

    private LinearLayout accessPersonalData;

    private LinearLayout layoutSeekBarRegainedHours;
    private LinearLayout layoutSeekBarCigarettes;
    private LinearLayout layoutSeekBarSavings;
    private LinearLayout layoutSeekBarSmokeFree;

    private LinearLayout layoutAchievementsRegainedHours;
    private LinearLayout layoutAchievementsCigarettes;
    private LinearLayout layoutAchievementsSavings;
    private LinearLayout layoutAchievementsSmokeFree;

    private TextView regainedHours;
    private TextView cigarettesNotSmoked;
    private TextView savings;
    private TextView smokeFree;

    private TextView titleSeekBarRegainedHours;
    private TextThumbSeekBar seekBarRegainedHurs;
    private TextView textViewStartRegainedHours;
    private TextView textViewEndRegainedHours;

    private TextView titleSeekBarCigarettes;
    private TextThumbSeekBar seekBarCigarettes;
    private TextView textViewStartCigarettes;
    private TextView textViewEndCigarettes;

    private TextView titleSeekBarSavings;
    private TextThumbSeekBar seekBarSavings;
    private TextView textViewStartSavings;
    private TextView textViewEndSavings;

    private TextView titleSeekBarSmokeFree;
    private TextThumbSeekBar seekBarSmokeFree;
    private TextView textViewStartSmokeFree;
    private TextView textViewEndSmokeFree;

    // Access to shared preferences
    SessionData sessionData;

    // Auxiliary view to inflate the fragment. It is used in auxiliary methods, so it is set as an
    // attribute of the class
    View rootView;

    // Required empty public constructor
    public UserStatisticsFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Not View attributes instantiation
        sessionData = SessionData.getSessionData(getContext()); // Shared preferences access
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_user_progress, container, false);

        // View attributes instantiation

        layoutSeekBarRegainedHours = (LinearLayout)rootView.findViewById(R.id.seekBarRegainedHoursLayout);
        layoutSeekBarCigarettes = (LinearLayout)rootView.findViewById(R.id.seekBarCigarettesLayout);
        layoutSeekBarSavings = (LinearLayout) rootView.findViewById(R.id.seekBarSavingsLayout);
        layoutSeekBarSmokeFree = (LinearLayout) rootView.findViewById(R.id.seekBarSmokeFreeLayout);

        layoutAchievementsRegainedHours = (LinearLayout) rootView.findViewById(R.id.regainedHoursAchievementsLayout);
        layoutAchievementsRegainedHours.setOnClickListener(onLayoutClickListener);

        layoutAchievementsCigarettes = (LinearLayout) rootView.findViewById(R.id.cigarettesNotSmokedAchievementsLayout);
        layoutAchievementsCigarettes.setOnClickListener(onLayoutClickListener);

        layoutAchievementsSavings = (LinearLayout) rootView.findViewById(R.id.savingsAchievementsLayout);
        layoutAchievementsSavings.setOnClickListener(onLayoutClickListener);

        layoutAchievementsSmokeFree = (LinearLayout)rootView.findViewById(R.id.smokeFreeDaysAchievementsLayout);
        layoutAchievementsSmokeFree.setOnClickListener(onLayoutClickListener);

        // Access to personal data
        accessPersonalData = (LinearLayout) rootView.findViewById(R.id.go_to_profile_data_access_layout);
        accessPersonalData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.goToProfileDataSection();
            }
        });

        // load header widget
        regainedHours = (TextView) rootView.findViewById(R.id.textViewColumnRegainedHours);
        cigarettesNotSmoked = (TextView) rootView.findViewById(R.id.textViewColumnCigarettesNotSmoked);
        savings = (TextView) rootView.findViewById(R.id.textViewColumnSavings);
        smokeFree = (TextView) rootView.findViewById(R.id.textViewColumnSmokeFreeDays);


        // load seekbars
        titleSeekBarCigarettes = (TextView) rootView.findViewById(R.id.seekBarCigarettesTitle);
        titleSeekBarRegainedHours = (TextView) rootView.findViewById(R.id.seekBarRegainedHoursTitle);
        titleSeekBarSavings = (TextView) rootView.findViewById(R.id.seekBarSavingsTitle);
        titleSeekBarSmokeFree = (TextView) rootView.findViewById(R.id.seekBarSmokeFreeTitle);

        textViewStartCigarettes = (TextView) rootView.findViewById(R.id.text_view_start_value_seek_bar_cigarettes);
        textViewEndCigarettes = (TextView) rootView.findViewById(R.id.text_view_end_value_seek_bar_cigarettes);
        textViewStartRegainedHours = (TextView) rootView.findViewById(R.id.text_view_start_value_seek_bar_regained_hours);
        textViewEndRegainedHours = (TextView) rootView.findViewById(R.id.text_view_end_value_seek_bar_regained_hours);
        textViewStartSavings = (TextView) rootView.findViewById(R.id.text_view_start_value_seek_bar_savings);
        textViewEndSavings = (TextView) rootView.findViewById(R.id.text_view_end_value_seek_bar_savings);
        textViewStartSmokeFree = (TextView) rootView.findViewById(R.id.text_view_start_value_seek_bar_smoke_free);
        textViewEndSmokeFree = (TextView) rootView.findViewById(R.id.text_view_end_value_seek_bar_smoke_free);

        seekBarCigarettes = (TextThumbSeekBar) rootView.findViewById(R.id.seekBarCigarettes);
        seekBarCigarettes.setEnabled(false);
        seekBarRegainedHurs = (TextThumbSeekBar) rootView.findViewById(R.id.seekBarRegainedHours);
        seekBarRegainedHurs.setEnabled(false);
        seekBarSavings = (TextThumbSeekBar) rootView.findViewById(R.id.seekBarSavings);
        seekBarSavings.setEnabled(false);
        seekBarSmokeFree = (TextThumbSeekBar) rootView.findViewById(R.id.seekBarSmokeFree);
        seekBarSmokeFree.setEnabled(false);

        welcomeText = (TextView) rootView.findViewById(R.id.wellcome_text);
        boolean done = updateViews();
        if(done){ // If update was done
            // Show to the user the achievements
            welcomeText.setText(getString(R.string.welcome)  + sessionData.getUserNick() + getString(R.string.badges_presentation));
            (rootView.findViewById(R.id.achievements_layout)).setVisibility(View.VISIBLE);
            (rootView.findViewById(R.id.widget_seekbar)).setVisibility(View.VISIBLE);
            (rootView.findViewById(R.id.benefits_divider)).setVisibility(View.VISIBLE);
            ((TextView)rootView.findViewById(R.id.go_to_profile_data_text)).setText(R.string.access_personal_data_text);
            layoutAchievementsRegainedHours.setBackgroundResource(R.drawable.button_pressed_badge_style);

        }else if(sessionData.isQuittingDateFilled()){ // If update was not done, if the user set quitting period with a future start date
            // Explain to the user the achievements will be allowed when the indicated start date was reached
            welcomeText.setText(getString(R.string.welcome) + sessionData.getUserNick() + getString(R.string.badges_presentation_future));
            (rootView.findViewById(R.id.achievements_layout)).setVisibility(View.VISIBLE);
            (rootView.findViewById(R.id.benefits_divider)).setVisibility(View.VISIBLE);
            ((TextView)rootView.findViewById(R.id.go_to_profile_data_text)).setText(R.string.access_personal_data_text);
        }
        if(sessionData.isQuittingDateFilled())
            (rootView.findViewById(R.id.go_to_profile_data_box_layout)).setVisibility(View.GONE);

        return rootView;
    }

    private boolean updateViews() {
        boolean res;
        try {
            res = updateWidgetTableAchievements() && updateWidgetSeekBar();
        }catch (NullPointerException e){
            res = false;
        }
        return res;
    }

    //Check if the user is in a quitting period with a past start date. In positive case, update the seek bars
    private boolean updateWidgetSeekBar() {
        boolean res = false;
        if(sessionData.isQuittingDateFilled()) {

            if (sessionData.getQuittingDate().getTimeInMillis() - Calendar.getInstance().getTimeInMillis() < 0) {

                LocalDataBaseHelper db = new LocalDataBaseHelper(getContext());

                ArrayList<SFBNotification> listRegainedHours = db.selectBadgesByType(SFBConstantsAndCodes.NOTIFICATION_TYPE_HOURS_REGAINED);
                TextThumbSeekBar.configureWidget(
                        seekBarRegainedHurs, titleSeekBarRegainedHours, textViewStartRegainedHours, textViewEndRegainedHours, getContext(), listRegainedHours);
                ArrayList<SFBNotification> listCigarettes = db.selectBadgesByType(SFBConstantsAndCodes.NOTIFICATION_TYPE_CIGARETTES_NOT_SMOKED);
                TextThumbSeekBar.configureWidget(
                        seekBarCigarettes, titleSeekBarCigarettes, textViewStartCigarettes, textViewEndCigarettes, getContext(), listCigarettes);
                ArrayList<SFBNotification> listSmokeFree = db.selectBadgesByType(SFBConstantsAndCodes.NOTIFICATION_TYPE_SMOKEFREE);
                TextThumbSeekBar.configureWidget(
                        seekBarSmokeFree, titleSeekBarSmokeFree, textViewStartSmokeFree, textViewEndSmokeFree, getContext(), listSmokeFree);
                ArrayList<SFBNotification> listSavings = db.selectBadgesByType(SFBConstantsAndCodes.NOTIFICATION_TYPE_SAVINGS);
                TextThumbSeekBar.configureWidget(
                        seekBarSavings, titleSeekBarSavings, textViewStartSavings, textViewEndSavings, getContext(), listSavings);

                res = true;
            }
        }
        return res;
    }

    //Check if the user is in a quitting period with a past start date. In positive case, update the achievements
    private boolean updateWidgetTableAchievements() {
        boolean res = false;
        if(sessionData.isQuittingDateFilled()) {
            if(sessionData.getQuittingDate().getTimeInMillis()-Calendar.getInstance().getTimeInMillis()<0) {
                List<SFBQuittingAttempt> quittingPeriods = sessionData.getSmokingData(getContext()).getQuittingAttempts();
                try {
                    int n = quittingPeriods.size();
                    Calendar quittingDate = quittingPeriods.get(n - 1).getQuittingDate();
                    Calendar now = Calendar.getInstance();
                    long timeDifference = now.getTimeInMillis() - quittingDate.getTimeInMillis();
                    float cigarettesPerDay = quittingPeriods.get(n - 1).getPreviousDailyCigarettes();
                    float moneyPerWeek = quittingPeriods.get(n - 1).getWeeklyTobaccoExpenditure();
                    int cigarettesCouldSmoke = Math.round((cigarettesPerDay * timeDifference) / 86400000);
                    int hoursRegained = cigarettesCouldSmoke * 11 / 60;
                    regainedHours.setText(String.valueOf(hoursRegained < 0 ? 0 : hoursRegained));
                    cigarettesNotSmoked.setText(String.valueOf(cigarettesCouldSmoke < 0 ? 0 : cigarettesCouldSmoke));

                    int daysSmokeFree = Math.round(timeDifference / 86400000);
                    smokeFree.setText(String.valueOf(daysSmokeFree < 0 ? 0 : daysSmokeFree));
                    int saving = Math.round(moneyPerWeek * daysSmokeFree / 7);
                    savings.setText(String.valueOf(saving< 0 ? 0 : saving));
                    res = true;
                } catch (IndexOutOfBoundsException e) {
                    e.printStackTrace();
                }
            }
        }
        return res;

    }

    @Override
    public void onResume() {
        super.onResume();
        mListener.onBenefitsFragmentInteraction(null);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    private View.OnClickListener onLayoutClickListener = new View.OnClickListener(){

        private int unpressedDrawable = R.drawable.button_badge_style;
        private int pressedDrawable = R.drawable.button_pressed_badge_style;

        @Override
        public void onClick(View v) {

            layoutSeekBarRegainedHours.setVisibility(View.GONE);
            layoutSeekBarCigarettes.setVisibility(View.GONE);
            layoutSeekBarSavings.setVisibility(View.GONE);
            layoutSeekBarSmokeFree.setVisibility(View.GONE);

            // Clear and mark the badge selected, only if user is in a started quitting period
            if((rootView.findViewById(R.id.widget_seekbar)).getVisibility() == View.VISIBLE){
                layoutAchievementsRegainedHours.setBackgroundResource(unpressedDrawable);
                layoutAchievementsCigarettes.setBackgroundResource(unpressedDrawable);
                layoutAchievementsSavings.setBackgroundResource(unpressedDrawable);
                layoutAchievementsSmokeFree.setBackgroundResource(unpressedDrawable);

                v.setBackgroundResource(pressedDrawable);
            }

            // Make visible the corresponding SeekBar
            switch (v.getId()){
                case R.id.regainedHoursAchievementsLayout:
                    layoutSeekBarRegainedHours.setVisibility(View.VISIBLE);
                    break;
                case R.id.cigarettesNotSmokedAchievementsLayout:
                    layoutSeekBarCigarettes.setVisibility(View.VISIBLE);
                    break;
                case R.id.savingsAchievementsLayout:
                    layoutSeekBarSavings.setVisibility(View.VISIBLE);
                    break;
                case R.id.smokeFreeDaysAchievementsLayout:
                    layoutSeekBarSmokeFree.setVisibility(View.VISIBLE);
                    break;
                default:
                    break;
            }
        }
    };



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnBenefitsFragmentInteractionListener) {
            mListener = (OnBenefitsFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnMeFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    // Send information or actions to his activity
    public interface OnBenefitsFragmentInteractionListener {
        void onBenefitsFragmentInteraction(Uri uri);

        void goToProfileDataSection();
    }
}
