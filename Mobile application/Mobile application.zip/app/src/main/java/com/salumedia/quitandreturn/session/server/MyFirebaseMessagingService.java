package com.salumedia.quitandreturn.session.server;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.salumedia.quitandreturn.model.SFBNotification;
import com.salumedia.quitandreturn.session.local.AlarmReceiver;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;

import com.salumedia.quitandreturn.utils.SFBEncode;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.Calendar;



public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "MyFirebaseMsgService";

    public static final String idQuestion = "idQuestion";
    public static final String idQuestionInServer = "idQuestionInServer";
    public static final String receivedQuestionDate = "receivedQuestionDate";
    public static final String idNotification = "idNotification";
    public static final String questionResponse = "questionResponse";


    public MyFirebaseMessagingService() {
        super();
    }


    /**
     * Called when message is received.
     *
     * @param remoteMessage Object representing the message received from Firebase Cloud Messaging.
     */
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {

        String serverNotificationId = "0";

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            String responseXML = null;

            // Create the xml request with the previous values

            GenerateXMLFile file = GenerateXMLFile.getInstance();
            serverNotificationId = remoteMessage.getData().get("messageId");

            // Sending message from server is received
            String fileXMLRequest = file.setMessageReceived(serverNotificationId);
            //System.out.println(fileXMLRequest);
            try {
                //Introduce XML and catch server response
                responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, this,
                        SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                this).getUserCredentials()) );

            } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }

        if (remoteMessage.getData().get("messageTag") != null) {

            int messageType = 99;
            boolean thereAreMessageType = true;
            if (remoteMessage.getData().get("messageTag").equals("Motivational Message")) {

                messageType = SFBConstantsAndCodes.NOTIFICATION_TYPE_MOTIVATIONAL_MESSAGE_FROM_SERVER;
            } else if (remoteMessage.getData().get("messageTag").equals("Follow up Message")) {

                messageType = SFBConstantsAndCodes.NOTIFICATION_TYPE_FOLLOW_UP;
            }
            else {
                thereAreMessageType = false;
            }

            if(thereAreMessageType) {
                String messageBody = remoteMessage.getData().get("messageBody");
                SFBNotification notification = new SFBNotification("SFBServer", "SFBUser", messageBody,
                        messageType, Calendar.getInstance());
                notification.setUserName(SessionData.getSessionData(this).getUserNick());
                notification.setPhotoUrl("none");
                notification.setText(messageBody);
                notification.setType(messageType);

                AlarmReceiver.setAlarmNotification(getApplicationContext(), notification, serverNotificationId);
            }
        }


        // Also if you intend on generating your own notifications as a result of a received FCM
        // message, here is where that should be initiated. See createSimpleNotification method below.
    }


    /** TODO: pending to delete
     * Create and show a simple notification containing the received FCM message.
     *
     * @param messageBody FCM message body received.
     */
    /*public void createSimpleNotification(String messageBody) {

        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra(MainActivity.SUBSECTION_KEY, TabsInitFragment.TAB_MESSAGES);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 /* Request code * /, intent,
                PendingIntent.FLAG_ONE_SHOT);

        Uri defaultSoundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.vector_logo)
                .setLargeIcon(ImageConversions.getBitmapFromDrawable(this, R.drawable.vector_logo))
                .setContentTitle(getString(R.string.smokefreebrain_notification_title))
                .setContentText(messageBody)
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(0 /* ID of notification * /, notificationBuilder.build());
    }*/


    /**
     * Create and show a simple notification containing the received FCM message.
     *
     * @param messageBody FCM message body received.
     */
   /* public void createNotificationWithOptions(String messageBody, String serverQuestionId) {

        int questionCode;
        String questionTitle;
        String questionText;
        String questionBigText;

        // Notification code, used to cancel it from an intent
        int idNotification_big_view;
        String date = SFBDate.timestampToString(Calendar.getInstance());

        SessionData sessionData = SessionData.getSessionData(this);

        Intent intent = new Intent(this, LauncherActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 /* Request code * /, intent, PendingIntent.FLAG_ONE_SHOT);

        switch (messageBody) {
            case "SmokeFreeQuestion":

                idNotification_big_view = SFBConstantsAndCodes.SMOKEFREE_QUESTION_NOTIFICATION_BOX_ID;
                questionCode = SFBConstantsAndCodes.SMOKEFREE_QUESTION_ID;
                questionTitle = this.getResources().getString(R.string.record_smokefree_notification_title);
                questionText = getString(R.string.record_smokefree_notification_text);
                questionBigText = getString(R.string.record_smokefree_notification_big_text);

                sessionData.setIdSmokeFreeQuestionInServer(serverQuestionId);
                sessionData.setDateReceivedSmokeFreeQuestion(date);
                sessionData.changeIfThereAreASmokeFreeQuestionWithoutResponse(true);

                Intent openQuestion = new Intent(this, CasualQuestionActivity.class);
                openQuestion.putExtra(idQuestion, questionCode)
                        .putExtra(idQuestionInServer, serverQuestionId)
                        .putExtra(receivedQuestionDate, date)
                        .putExtra(idNotification, idNotification_big_view);
                PendingIntent pendingOpenQuestion = PendingIntent.getActivity(this, 1, openQuestion, PendingIntent.FLAG_UPDATE_CURRENT);

                Intent sendFastQuestionResponse = new Intent(this, SendFastQuestionResponse.class);
                sendFastQuestionResponse.putExtra(idQuestion, questionCode)
                        .putExtra(idQuestionInServer, serverQuestionId)
                        .putExtra(receivedQuestionDate, date)
                        .putExtra(idNotification, idNotification_big_view)
                        .putExtra(questionResponse, 0);
                PendingIntent pendingSendFastQuestionResponse = PendingIntent.getService(this, 0, sendFastQuestionResponse, PendingIntent.FLAG_UPDATE_CURRENT);

                NotificationCompat.Action fast_response_action = new NotificationCompat.Action.Builder(
                        R.drawable.ic_thumb_up_black_24dp, getString(R.string.yes), pendingSendFastQuestionResponse).build();
                NotificationCompat.Action open_question_access = new NotificationCompat.Action.Builder(
                        R.drawable.ic_thumb_down_black_24dp, getString(R.string.no), pendingOpenQuestion).build();
                try {
                    Notification notificationBuilder =
                            new NotificationCompat.Builder(this)
                                    .setSmallIcon(R.drawable.vector_logo)
                                    .setLargeIcon(ImageConversions.getBitmapFromDrawable(this, R.drawable.vector_logo))
                                    .setContentTitle(questionTitle)
                                    .setContentText(questionText)
                                    .setPriority(Notification.PRIORITY_HIGH)
                                    .setDefaults(Notification.DEFAULT_ALL)
                                    .setStyle(new NotificationCompat.BigTextStyle()
                                            .bigText(questionBigText))
                                    .setContentIntent(pendingIntent)
                                    .addAction(fast_response_action)
                                    .addAction(open_question_access).build();

                    NotificationManager mNotifyMgr =
                            (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

                    mNotifyMgr.notify(idNotification_big_view, notificationBuilder);

                } catch (Exception e) {
                    Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
                } finally {

                }
                break;
            case "MessagesFrequencyQuestion":
                idNotification_big_view = SFBConstantsAndCodes.MESSAGES_FREQUENCY_QUESTION_NOTIFICATION_BOX_ID;
                questionCode = SFBConstantsAndCodes.MESSAGES_FREQUENCY_QUESTION_ID;
                questionTitle = getString(R.string.record_messages_frequency_notification_title);
                questionText = getString(R.string.record_messages_frequency_notification_text);
                questionBigText = getString(R.string.record_messages_frequency_notification_big_text);

                sessionData.setIdMessagesFrequencyQuestionInServer(serverQuestionId);
                sessionData.setDateReceivedMessagesFrequencyQuestion(date);
                sessionData.changeIfThereAreAMessagesFrequencyQuestionWithoutResponse(true);

                Intent sendFastQuestionResponseFew = new Intent(this, SendFastQuestionResponse.class);
                sendFastQuestionResponseFew.putExtra(idQuestion, questionCode)
                        .putExtra(idQuestionInServer, serverQuestionId)
                        .putExtra(receivedQuestionDate, date)
                        .putExtra(idNotification, idNotification_big_view)
                        .putExtra(questionResponse, 0);
                PendingIntent pendingSendFastQuestionResponseFew = PendingIntent.getService(this, 1, sendFastQuestionResponseFew, PendingIntent.FLAG_UPDATE_CURRENT);

                NotificationCompat.Action fast_response_action_few = new NotificationCompat.Action.Builder(
                        R.drawable.ic_low_frequency_messages_black_24dp, getString(R.string.record_messages_frequency_notification_few_answer), pendingSendFastQuestionResponseFew).build();


                Intent sendFastQuestionResponseMedium = new Intent(this, SendFastQuestionResponse.class);
                sendFastQuestionResponseMedium.putExtra(idQuestion, questionCode)
                        .putExtra(idQuestionInServer, serverQuestionId)
                        .putExtra(receivedQuestionDate, date)
                        .putExtra(idNotification, idNotification_big_view)
                        .putExtra(questionResponse, 1);
                PendingIntent pendingSendFastQuestionResponseMedium = PendingIntent.getService(this, 2, sendFastQuestionResponseMedium, PendingIntent.FLAG_UPDATE_CURRENT);

                NotificationCompat.Action fast_response_action_medium = new NotificationCompat.Action.Builder(
                        R.drawable.ic_medium_frequency_messages_black_24dp, getString(R.string.record_messages_frequency_notification_medium_answer), pendingSendFastQuestionResponseMedium).build();

                Intent sendFastQuestionResponseMany = new Intent(this, SendFastQuestionResponse.class);
                sendFastQuestionResponseMany.putExtra(idQuestion, questionCode)
                        .putExtra(idQuestionInServer, serverQuestionId)
                        .putExtra(receivedQuestionDate, date)
                        .putExtra(idNotification, idNotification_big_view)
                        .putExtra(questionResponse, 2);
                PendingIntent pendingSendFastQuestionResponseMany = PendingIntent.getService(this, 3, sendFastQuestionResponseMany, PendingIntent.FLAG_UPDATE_CURRENT);

                NotificationCompat.Action fast_response_action_many = new NotificationCompat.Action.Builder(
                        R.drawable.ic_high_frequency_messages_black_24dp, getString(R.string.record_messages_frequency_notification_many_answer), pendingSendFastQuestionResponseMany).build();
                try {
                    Notification notificationBuilder =
                            new NotificationCompat.Builder(this)
                                    .setSmallIcon(R.drawable.vector_logo)
                                    .setLargeIcon(ImageConversions.getBitmapFromDrawable(this, R.drawable.vector_logo))
                                    .setContentTitle(questionTitle)
                                    .setContentText(questionText)
                                    .setPriority(Notification.PRIORITY_HIGH)
                                    .setDefaults(Notification.DEFAULT_ALL)
                                    .setStyle(new NotificationCompat.BigTextStyle()
                                            .bigText(questionBigText))
                                    .setContentIntent(pendingIntent)
                                    .addAction(fast_response_action_few)
                                    .addAction(fast_response_action_medium)
                                    .addAction(fast_response_action_many)
                                    .build();

                    NotificationManager mNotifyMgr =
                            (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

                    mNotifyMgr.notify(idNotification_big_view, notificationBuilder);

                } catch (Exception e) {
                    Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
                } finally {

                }
                break;
            default:
                break;
        }
    } */
}