package com.salumedia.quitandreturn.utils;

/**
 * Created by Francisco on 18/4/17.
 */

/**
 * Util set of methods to manage the correct currency conversions
 */
public class SFBCurrencyConversions {

    public static final String ISOEuro = "EUR";
    public static final String ISODollar = "USD";
    public static final String ISOBritishPound = "GBP";
    public static final String ISOYuan = "CNY";
    public static final String ISOTaiwaneseDollar = "TWD";

    public static final String symbolEuro = "€"; //"\\u20ac";
    public static final String symbolDollar = "$"; //"\\u0024";
    public static final String symbolBritishPound = "£"; //"\\u00a3";
    public static final String symbolYuan = "¥"; //"\\u00A5";
    public static final String symbolTaiwaneseDollar = "NT$"; //"NT\\u0024";

    public static Float getConversionCoefficientToEuros(String currency) {
        Float res;
        switch (currency){
            case symbolTaiwaneseDollar:
                res = 32.622f;
                break;
            case symbolDollar:
                res = 1.073f;
                break;
            case symbolYuan:
                res = 7.38f;
                break;
            case symbolBritishPound:
                res = 0.865f;
                break;
            default:
                res = 1f;
                break;
        }
        return res;
    }


    public static String currencySymbolToISOCode(String currency) {
        String res;
        switch (currency){
            case symbolTaiwaneseDollar:
                res = ISOTaiwaneseDollar;
                break;
            case symbolDollar:
                res = ISODollar;
                break;
            case symbolYuan:
                res = ISOYuan;
                break;
            case symbolBritishPound:
                res = ISOBritishPound;
                break;
            default:
                res = ISOEuro;
                break;
        }
        return res;
    }

    public static String currencyISOCodeToSymbol(String ISOCode){
        String res;
        switch (ISOCode){
            case ISOTaiwaneseDollar:
                res = symbolTaiwaneseDollar;
                break;
            case ISODollar:
                res = symbolDollar;
                break;
            case ISOYuan:
                res = symbolYuan;
                break;
            case ISOBritishPound:
                res = symbolBritishPound;
                break;
            default:
                res = symbolEuro;
                break;
        }
        return res;
    }

/*    public static int RoundSavings(int savings, String currency){
        int roundingSavings = savings;
        int precision = 0;
        if(currency.equals(symbolYuan) || currency.equals((symbolTaiwaneseDollar))){
            if(savings <10){
                precision = 0;
            }else if(savings <100){
                precision = 1;
            } else if(savings<1000){
                precision = 2;
            }else if(savings <10000){
                precision = 3;
            }
        }
        int scale = (int) Math.pow(10, precision);

        roundingSavings =  Math.round(savings * scale) / scale;

        return roundingSavings;
    }*/
}
