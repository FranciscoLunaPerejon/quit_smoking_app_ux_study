package com.salumedia.quitandreturn;

import android.support.v4.app.Fragment;

import com.salumedia.quitandreturn.model.SFBAppInteractionAnalytic;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.utils.SFBAnalytics;

import java.text.SimpleDateFormat;
import java.util.Calendar;



/**
 * Created by francisco on 25/3/17.
 */

/**
 * Superclass for fragments which allow get analytical information about the accessing date and
 * time, and time spent on each
 * The most fragment classes extend this for analytical purpose
 */
public class SFBFragment extends Fragment {

    // The analysis record the section name, date and time of accessing, and accessing duration
    public String section_name = "";
    public String date;
    public String time;
    public Float init;


    @Override
    public void onResume() {
        super.onResume();
        // Initialize time parameters
        init = Long.valueOf(System.nanoTime()/1000000).floatValue();
        Calendar currentTime = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        date = sdf.format(currentTime.getTime());
        SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss.SSS");
        time = sdf2.format(currentTime.getTime());

        try{
            SFBAnalytics.startLogTimeInSection(section_name +
                    "_author:" +  SessionData.getSessionData(getContext()).getUserData(getContext()).getUserId() +
                    "_date:" + date + " " +  time);
        }catch (Exception e){
            SFBAnalytics.startLogTimeInSection(section_name + "_author:NOT_AVALIABLE" +
                    "_date:" + date + " " +  time);
        }

    }

    @Override
    public void onPause() {
        super.onPause();
        // Calculate duration and save information in local database
        Float fin = Long.valueOf(System.nanoTime()/1000000).floatValue();
        LocalDataBaseHelper db = new LocalDataBaseHelper(getContext());
        SFBAppInteractionAnalytic SFBAppInteractionAnalytic = new SFBAppInteractionAnalytic(section_name, date, time, (fin-init));
        db.insertAppInteraction(SFBAppInteractionAnalytic);
        try{
            SFBAnalytics.stopLogTimeInSection(section_name +
                    "_author:" + SessionData.getSessionData(getContext()).getUserData(getContext()).getUserId() +
                    "_date:" + date + " " +  time);

        }catch (Exception e){
            SFBAnalytics.stopLogTimeInSection(section_name + "_author:NOT_AVALIABLE" +
                    "_date:" + date + " " +  time);
        }
        SFBAnalytics.stopLogTimeInSection(section_name);
    }


}
