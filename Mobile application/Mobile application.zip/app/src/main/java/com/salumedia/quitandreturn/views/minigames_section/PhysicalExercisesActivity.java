package com.salumedia.quitandreturn.views.minigames_section;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBAppInteractionAnalytic;
import com.salumedia.quitandreturn.model.SFBMiniGameAnalytics;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.XMLHttpPost;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.SFBAnalytics;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBEncode;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class PhysicalExercisesActivity extends AppCompatActivity {

    public enum StartButtonEnum {
        START,
        NEXT
    }

    public class IntructCard {
        public int ID;
        public String Name;
        public int video; //Drawable drawable = res.getDrawable(R.drawable.cigon);
        public String InstuctionsText;
        public Boolean skipped = false;
        public Boolean started = false;
        public Date dateTimeStarted; // corresponds to the datetime the card shown up
        public String dateTimeStartedStr;
        public Date dateTimeFinished; // corresponds to the datetime the Next of Skip clicked
        public String dateTimeFinishedStr;
        public int planDuration = 10;
    }

    public class PhysicalExerResults {
        public int completed;
        public int skipped;
        public List<IntructCard> exercises;
    }

    public String date;
    public String time;
    public Float init;
    public static final String section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_GAME_PHYSICAL_EXERCISES;

    RelativeLayout gameRelativeLayout;
    VideoView videoViewInstructions;
    VideoView videoView;
    TextView timeTextView;
    TextView totalTextView;
    Button buttonStart;
    Button buttonSkip;
    View finishContainerView;
    TextView finishTextView;
    View resultLayoutView;
    TextView exerFinishedTextView;
    TextView exerSkippedTextView;
    Button restartButton;
    Button backButton;
    View startContainerView;

    List<IntructCard> ProtocolIntructCard;
    CountDownTimer mCountDownTimer = null;
    private int ProtocolIndex = 0;
    int totalSkipped = 0;
    int totalScore = 0;

    PhysicalExerResults gameResults = new PhysicalExerResults();

    StartButtonEnum StartButtonStatus = StartButtonEnum.START;

    private SendPhysExerGameResultsTask mSendPhysExerGameResultsTask = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_physical_exercises);

        // Initialize game miniGameActivity
        gameResults.skipped = 0;
        gameResults.completed = 0;
        gameResults.exercises = ProtocolIntructCard;

        // Get layout and widgets
        gameRelativeLayout = (RelativeLayout) findViewById(R.id.gameRelativeLayout);
        timeTextView = (TextView) findViewById(R.id.timetextView);
        totalTextView = (TextView) findViewById(R.id.totaltextView);
        buttonStart = (Button) findViewById(R.id.buttonStart);
        buttonSkip = (Button) findViewById(R.id.buttonSkip);
        videoViewInstructions = (VideoView) findViewById(R.id.videoViewInstructions);
        videoView = (VideoView) findViewById(R.id.videoView);
        finishContainerView = findViewById(R.id.finishContainerView);
        finishTextView = (TextView) findViewById(R.id.finishTextView);
        resultLayoutView = findViewById(R.id.results_layout);
        exerFinishedTextView = (TextView) findViewById(R.id.exerFinishedTextView);
        exerSkippedTextView = (TextView) findViewById(R.id.exerSkippedtextView);
        restartButton = (Button) findViewById(R.id.restartButton);
        backButton = (Button) findViewById(R.id.backButton);
        startContainerView = findViewById(R.id.startContainerView);

        buttonStart.setVisibility(View.INVISIBLE);
        buttonSkip.setVisibility(View.INVISIBLE);

        startContainerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            startContainerView.setVisibility(View.GONE);
                            buttonStart.setVisibility(View.VISIBLE);
                            buttonSkip.setVisibility(View.VISIBLE);

                            PrepareProtocolList();

                            final Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    // Initialize total
                                    String scoreText = getString(R.string.physical_exercises_score) + 0;
                                    totalTextView.setText(scoreText);
                                    PresentProtocolTask(ProtocolIndex);
                                }
                            }, 300);

                        }
                    });
                }

                return true;
            }
        });

        // Button events
        buttonStart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (StartButtonStatus == StartButtonEnum.START) {
                    StartExercise();
                } else {
                    NextExercise();
                    // Reset countdown
                    mCountDownTimer.cancel();
                    String timeText = getString(R.string.physical_exercises_time) + ProtocolIntructCard.get(ProtocolIndex).planDuration;
                    timeTextView.setText(timeText);
                }
            }
        });

        buttonSkip.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                totalSkipped++;

                if (ProtocolIndex < ProtocolIntructCard.size() - 1) {
                    Calendar c = Calendar.getInstance();
                    ProtocolIntructCard.get(ProtocolIndex).skipped = true;
                    Date datet = c.getTime();
                    ProtocolIntructCard.get(ProtocolIndex).dateTimeFinished = datet;
                    TimeZone tz = TimeZone.getTimeZone("UTC");
                    DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                    df.setTimeZone(tz);
                    ProtocolIntructCard.get(ProtocolIndex).dateTimeFinishedStr = df.format(datet);

                    ProtocolIndex++;
                    PresentProtocolTask(ProtocolIndex);

                    // Reset countdown
                    if (mCountDownTimer != null) {
                        mCountDownTimer.cancel();
                        String timeText = getString(R.string.physical_exercises_time) + ProtocolIntructCard.get(ProtocolIndex).planDuration;
                        timeTextView.setText(timeText);
                    }
                } else {
                    finishGame();
                }

            }
        });

        restartButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                recreate();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });

    }

    private void StartExercise() {
        Calendar c = Calendar.getInstance();
        ProtocolIntructCard.get(ProtocolIndex).skipped = false;
        ProtocolIntructCard.get(ProtocolIndex).started = true;
        Date datet = c.getTime();
        ProtocolIntructCard.get(ProtocolIndex).dateTimeStarted = datet;
        TimeZone tz = TimeZone.getTimeZone("UTC");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        df.setTimeZone(tz);
        ProtocolIntructCard.get(ProtocolIndex).dateTimeStartedStr = df.format(datet);

        mCountDownTimer = new CountDownTimer(ProtocolIntructCard.get(ProtocolIndex).planDuration * 1000, 1000) {

            public void onTick(long millisUntilFinished) {
                String timeText = getString(R.string.physical_exercises_time) + millisUntilFinished / 1000;
                timeTextView.setText(timeText);
            }

            public void onFinish() {
                timeTextView.setText(R.string.physical_exercises_zero_time);
                NextExercise();
            }

        }.start();

        /*
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                NextExercise();
            }
        }, ProtocolIntructCard.get(ProtocolIndex).planDuration * 1000);
        */

        StartButtonStatus = StartButtonEnum.NEXT;
        buttonStart.setText(R.string.physical_exercises_next);

    }

    private void NextExercise() {
        Calendar c = Calendar.getInstance();
        Date datet = c.getTime();
        ProtocolIntructCard.get(ProtocolIndex).dateTimeFinished = datet;
        TimeZone tz = TimeZone.getTimeZone("UTC");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        df.setTimeZone(tz);
        ProtocolIntructCard.get(ProtocolIndex).dateTimeFinishedStr = df.format(datet);

        totalScore = ProtocolIndex + 1 - totalSkipped;
        String scoreText = getString(R.string.physical_exercises_score)  + totalScore;
        totalTextView.setText(scoreText);

        if (ProtocolIntructCard.size() > 0) {
            if (ProtocolIndex < ProtocolIntructCard.size() - 1) {
                ProtocolIndex++;
                PresentProtocolTask(ProtocolIndex);
                StartButtonStatus = StartButtonEnum.START;
                buttonStart.setText(R.string.physical_exercises_begin);
            } else {
                finishGame();
            }
        }

    }


    private void PrepareProtocolList() {
        ProtocolIntructCard = new ArrayList<IntructCard>();

        Calendar c = Calendar.getInstance();

        IntructCard InstCard = new IntructCard();
        InstCard.ID = 1;
        InstCard.Name = "adductabduct";
        InstCard.video = R.raw.exinstruct_adductabduct;
        InstCard.InstuctionsText = "Please Adduct and Abduct";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 2;
        InstCard.Name = "armstretching";
        InstCard.video = R.raw.exinstruct_armstretching;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 3;
        InstCard.Name = "backstretch";
        InstCard.video = R.raw.exinstruct_backstretch;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 4;
        InstCard.Name = "balance";
        InstCard.video = R.raw.exinstruct_balance;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 5;
        InstCard.Name = "bandfwdraises";
        InstCard.video = R.raw.exinstruct_bandfwdraises;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 6;
        InstCard.Name = "bandsideraises";
        InstCard.video = R.raw.exinstruct_bandsideraises;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 7;
        InstCard.Name = "biceps";
        InstCard.video = R.raw.exinstruct_biceps;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 8;
        InstCard.Name = "bicepsband";
        InstCard.video = R.raw.exinstruct_bicepsband;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 9;
        InstCard.Name = "calf";
        InstCard.video = R.raw.exinstruct_calf;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 10;
        InstCard.Name = "cycling";
        InstCard.video = R.raw.exinstruct_cycling;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 11;
        InstCard.Name = "exinstruct";
        InstCard.video = R.raw.exinstruct_exinstruct;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 12;
        InstCard.Name = "extensionflexion";
        InstCard.video = R.raw.exinstruct_extensionflexion;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 13;
        InstCard.Name = "fwdraises";
        InstCard.video = R.raw.exinstruct_fwdraises;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 14;
        InstCard.Name = "headlatexten";
        InstCard.video = R.raw.exinstruct_headlatexten;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 15;
        InstCard.Name = "hiking";
        InstCard.video = R.raw.exinstruct_hiking;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 16;
        InstCard.Name = "legbackward";
        InstCard.video = R.raw.exinstruct_legbackward;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 17;
        InstCard.Name = "legforward";
        InstCard.video = R.raw.exinstruct_legforward;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 18;
        InstCard.Name = "legsideways";
        InstCard.video = R.raw.exinstruct_legsideways;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 19;
        InstCard.Name = "neckstretching";
        InstCard.video = R.raw.exinstruct_neckstretching;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 20;
        InstCard.Name = "quadstretch";
        InstCard.video = R.raw.exinstruct_quadstretch;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 21;
        InstCard.Name = "shoulder";
        InstCard.video = R.raw.exinstruct_shoulder;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 22;
        InstCard.Name = "shoulderrotationback";
        InstCard.video = R.raw.exinstruct_shoulderrotationback;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 23;
        InstCard.Name = "shoulderrotationfwd";
        InstCard.video = R.raw.exinstruct_shoulderrotationfwd;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 24;
        InstCard.Name = "sidelunge";
        InstCard.video = R.raw.exinstruct_sidelunge;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 25;
        InstCard.Name = "sideraises";
        InstCard.video = R.raw.exinstruct_sideraises;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 26;
        InstCard.Name = "sittostand";
        InstCard.video = R.raw.exinstruct_sittostand;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 27;
        InstCard.Name = "skijump";
        InstCard.video = R.raw.exinstruct_skijump;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 28;
        InstCard.Name = "stepup";
        InstCard.video = R.raw.exinstruct_stepup;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 29;
        InstCard.Name = "torsotwist";
        InstCard.video = R.raw.exinstruct_torsotwist;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);

        InstCard = new IntructCard();
        InstCard.ID = 30;
        InstCard.Name = "riceps";
        InstCard.video = R.raw.exinstruct_triceps;
        InstCard.InstuctionsText = "Please stretch your arms";
        InstCard.skipped = false;
        InstCard.dateTimeStarted = c.getTime();
        InstCard.dateTimeFinished = c.getTime();
        InstCard.planDuration = 10;
        ProtocolIntructCard.add(InstCard);
    }


    private void PresentProtocolTask(int index) {
        //videoViewInstructions.setImageResource(ProtocolIntructCard.get(index).drawable);
        //videoViewInstructions.setMediaController(new MediaController(this));
        //Uri video = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.your_raw_file); //do not add any extension
        Uri video = Uri.parse("android.resource://" + getPackageName() + "/" + ProtocolIntructCard.get(index).video); //do not add any extension
        // if your file is named sherif.mp4 and placed in /raw
        // use R.raw.sherif
        videoViewInstructions.setVideoURI(video);
        //videoViewInstructions.start();
        videoViewInstructions.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setLooping(true);
                videoViewInstructions.start();
            }
        });

        StartButtonStatus = StartButtonEnum.START;
        buttonStart.setText(getString(R.string.physical_exercises_begin) );
    }

    private void finishGame() {

        // Completed and skipped exercises
        totalScore = ProtocolIntructCard.size() - totalSkipped;

        String complStr = getString(R.string.physical_exercises_completed_quantity);
        String skippedStr = getString(R.string.physical_exercises_skipped_quantity);

        exerFinishedTextView.setText(complStr + ": " + totalScore);
        exerSkippedTextView.setText(skippedStr + ": " + totalSkipped);

        gameResults.completed = totalScore;
        gameResults.skipped = totalSkipped;
        gameResults.exercises = ProtocolIntructCard;

        // Show finish screen
        timeTextView.setVisibility(View.INVISIBLE);
        buttonStart.setVisibility(View.INVISIBLE);
        buttonSkip.setVisibility(View.INVISIBLE);
        videoView.setVisibility(View.INVISIBLE);
        videoViewInstructions.setVisibility(View.INVISIBLE);
        totalTextView.setVisibility(View.INVISIBLE);
        finishContainerView.setVisibility(View.VISIBLE);
        finishTextView.setVisibility(View.VISIBLE);
        resultLayoutView.setVisibility(View.VISIBLE);
        restartButton.setVisibility(View.VISIBLE);
        backButton.setVisibility(View.VISIBLE);

        // Send miniGameActivity
        sendPhysExerGameResults(gameResults);
    }

    @Override
    public void onResume() {
        super.onResume();
        // Initialize time parameters
        init = Long.valueOf(System.nanoTime()/1000000).floatValue();
        Calendar currentTime = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        date = sdf.format(currentTime.getTime());
        SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss.SSS");
        time = sdf2.format(currentTime.getTime());

        try{
            SFBAnalytics.startLogTimeInSection(section_name +
                    "_author:" +  SessionData.getSessionData(this).getUserData(this).getUserId() +
                    "_date:" + date + " " +  time);
        }catch (Exception e){
            SFBAnalytics.startLogTimeInSection(section_name + "_author:NOT_AVALIABLE" +
                    "_date:" + date + " " +  time);
        }
        SFBAnalytics.startLogTimeInSection(section_name);
    }

    @Override
    public void onPause() {
        super.onPause();
        Float fin = Long.valueOf(System.nanoTime()/1000000).floatValue();
        LocalDataBaseHelper db = new LocalDataBaseHelper(this);
        SFBAppInteractionAnalytic SFBAppInteractionAnalytic = new SFBAppInteractionAnalytic(section_name, date, time, (fin-init));
        db.insertAppInteraction(SFBAppInteractionAnalytic);
        try{
            SFBAnalytics.stopLogTimeInSection(section_name +
                    "_author:" + SessionData.getSessionData(this).getUserData(this).getUserId() +
                    "_date:" + date + " " +  time);

        }catch (Exception e){
            SFBAnalytics.stopLogTimeInSection(section_name + "_author:NOT_AVALIABLE" +
                    "_date:" + date + " " +  time);
        }
        SFBAnalytics.stopLogTimeInSection(section_name);
    }

    public void sendPhysExerGameResults(PhysicalExerResults results) {
        if (mSendPhysExerGameResultsTask != null) {
            return;
        }
        mSendPhysExerGameResultsTask = new SendPhysExerGameResultsTask(PhysicalExercisesActivity.this, results);
        mSendPhysExerGameResultsTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
    }

    public class SendPhysExerGameResultsTask extends AsyncTask<Void, Void, Boolean> {

        private final int CODE_NO_FAILS = 0;
        private final int CODE_ERROR_INTERNET_CONNECTION = 4;
        private final int CODE_ERROR_NOT_STORED = 6;

        public Integer failCode;

        SFBMiniGameAnalytics miniGameActivity;

        Context context;

        public SendPhysExerGameResultsTask(Context context, PhysicalExerResults results) {
            this.context = context;

            this.miniGameActivity = new SFBMiniGameAnalytics(SFBMiniGameAnalytics.PHYSICAL_EXERCISES_NAME,
                                                            date, time, results.completed, results.skipped, 0);

            failCode = CODE_NO_FAILS;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {

            Boolean everythingCorrect = false;

            GenerateXMLFile file = GenerateXMLFile.getInstance();

            if (XMLHttpPost.isConnectedToInternet(PhysicalExercisesActivity.this)) {

                String responseXML = null;

                ArrayList<SFBMiniGameAnalytics> list = new ArrayList<>();
                list.add(miniGameActivity);

                String fileXMLRequest = file.addMiniGameActivity(list);

                try {
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, context,
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    context).getUserCredentials()));
                } catch (CertificateException | NoSuchAlgorithmException | KeyManagementException | IOException | KeyStoreException e) {
                    e.printStackTrace();
                }

                everythingCorrect = responseXML == "created";
                if (!everythingCorrect)
                    failCode = CODE_ERROR_NOT_STORED;

            } else {
                failCode = CODE_ERROR_INTERNET_CONNECTION;
            }


            return everythingCorrect;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mSendPhysExerGameResultsTask = null;
            //fragmentReference.refreshUI(0);
            super.onPostExecute(success);
            //goBack();
            if (success) {
                Log.d("SFBSENT", "Success ok onPostExecute");
                //SFBPreferences.getPreferences(context).setEncourageMessageResponseWithSuccess(SFBConstants.ENCOURAGE_MESSAGE_SENT);
            } else {
                LocalDataBaseHelper db = new LocalDataBaseHelper(context);
                db.insertMiniGameActivity(miniGameActivity);
            }
        }

        @Override
        protected void onCancelled() {
            mSendPhysExerGameResultsTask = null;
            super.onCancelled();
        }
    }

}
