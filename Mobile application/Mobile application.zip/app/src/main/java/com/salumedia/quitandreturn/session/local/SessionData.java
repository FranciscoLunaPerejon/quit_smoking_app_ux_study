package com.salumedia.quitandreturn.session.local;

import android.content.Context;
import android.content.SharedPreferences;

import com.salumedia.quitandreturn.model.SFBPersonalData;
import com.salumedia.quitandreturn.model.SFBQuittingAttempt;
import com.salumedia.quitandreturn.model.SFBSmokingData;
import com.salumedia.quitandreturn.model.SFBUser;
import com.salumedia.quitandreturn.utils.SFBDate;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;


/**
 * Created by Francisco on 31/12/16.
 */

public class SessionData {


    private static final String sessionData = "DataSession";

    // This class contains the SharedPreferences declarations, that is, key-value pairs saved in a
    // file to remember data like login information or preferences that must be persistent when the
    // app is closed.

    //     KEYS
    // Not relevant user data: data used in the app but no in analytics


    private final String userCredentialsKey = "user_nick";
    private final String userNickKey = "user_name";
    private final String languageKey = "language";

    private final String FCMTokenKey = "FCMToken";
    private final String isFirebaseTokenUpdatedKey = "isFCMTokenUpdate";

    private static final String KEY_MUTE_CODE = "keyMuteCode";
    private static final Integer GENERIC_MUTE_CODE = 0;
    private static final String KEY_MUTE_UNTIL = "keyMuteUntil";
    private static final String GENERIC_MUTE_UNTIL = "";

    private static final String isConfigurationUpdatedKey = "isConfigurationUpdated";
    private static final Boolean GENERIC_IS_CONFIGURATION_UPDATED = true;

    // Relevant user data: data used both in app and in analytics
    private final String registerDateKey = "register_date";
    private final String genderKey = "gender";
    private final String birthDateKey = "birth_date";
    private final String employmentStatusKey = "employmentStatus";
    private final String previousDailyCigarettesKey = "prev_daily_cigar";
    private final String weeklyTobaccoExpenditureKey = "weekly_tobacco_expend";
    private final String currencyKey = "currency";
    private static final String startedSmokingDateKey = "startedSmokingDate";
    private final String quittingDateKey = "quitting_date";

    private final String patientCodeKey = "patientCode";

    private final String dailyFitnessActivityLastDaysKey = "dailyFitnessActivityLastDays";
    private final String lastGoogleFitConnectionDateKey = "lastGoogleFitConnectionDate";

    // Casual Questions

    private static String idSmokeFreeQuestionInServerKey = "idSmokeFreeQuestionInServer";
    private static String dateReceivedSmokeFreeQuestionKey = "dateReceivedSmokeFreeQuestion";

    private static String idMessagesFrequencyQuestionInServerKey = "idMessagesFrequencyQuestionInServer";
    private static String dateReceivedMessagesFrequencyQuestionKey = "dateReceivedMessagesFrequencyQuestion";


    //User preferences

    private final String questionnairePreferencesKey = "quest_preferences";
    private static final String KEY_ANSWER_0 = "answer0";
    private static final String KEY_ANSWER_1 = "answer1";
    private static final String KEY_ANSWER_2 = "answer2";
    private static final String KEY_ANSWER_3 = "answer3";
    private static final String KEY_ANSWER_4 = "answer4";
    private static final String KEY_ANSWER_HOUR_BEGIN = "answer5";
    private static final String KEY_ANSWER_HOUR_END = "answer6";

    private final String weeekDaysPreferencesKey = "day_weeks_preferences";
    private static final String ALLOW_MONDAY_KEY = "allow_monday";
    private static final String ALLOW_TUESDAY_KEY = "allow_tuesday";
    private static final String ALLOW_WEDNESDAY_KEY = "allow_wednesday";
    private static final String ALLOW_THURSDAY_KEY = "allow_thursday";
    private static final String ALLOW_FRIDAY_KEY = "allow_friday";
    private static final String ALLOW_SATURDAY_KEY = "allow_saturday";
    private static final String ALLOW_SUNDAY_KEY = "allow_sunday";
    private static final String KEY_HOUR_ALLOW_BEGIN_M = "allow_begin_monday";
    private static final String KEY_HOUR_ALLOW_END_M = "allow_end_monday";
    private static final String KEY_HOUR_ALLOW_BEGIN_T = "allow_begin_tuesday";
    private static final String KEY_HOUR_ALLOW_END_T = "allow_end_tuesday";
    private static final String KEY_HOUR_ALLOW_BEGIN_W = "allow_begin_wednesday";
    private static final String KEY_HOUR_ALLOW_END_W = "allow_end_wednesday";
    private static final String KEY_HOUR_ALLOW_BEGIN_TH = "allow_begin_thursday";
    private static final String KEY_HOUR_ALLOW_END_TH = "allow_end_thursday";
    private static final String KEY_HOUR_ALLOW_BEGIN_F = "allow_begin_friday";
    private static final String KEY_HOUR_ALLOW_END_F = "allow_end_friday";
    private static final String KEY_HOUR_ALLOW_BEGIN_SA = "allow_begin_saturday";
    private static final String KEY_HOUR_ALLOW_END_SA = "allow_end_saturday";
    private static final String KEY_HOUR_ALLOW_BEGIN_SU = "allow_begin_sunday";
    private static final String KEY_HOUR_ALLOW_END_SU = "allow_end_sunday";


    // Relevant and transparent user data: information used in analytic but transparent to the user
    private static final String fagerstromResultsKey = "fagerstromResults";
    private static final String fagerstromQuestion1Key = "fagerstromQuestion1";
    private static final String fagerstromQuestion2Key = "fagerstromQuestion2";
    private static final String fagerstromQuestion3Key = "fagerstromQuestion3";
    private static final String fagerstromQuestion4Key = "fagerstromQuestion4";
    private static final String fagerstromQuestion5Key = "fagerstromQuestion5";
    private static final String fagerstromQuestion6Key = "fagerstromQuestion6";

    private static final String richmondResultsKey = "richmondResults";
    private static final String richmondQuestion1Key = "richmondQuestion1";
    private static final String richmondQuestion2Key = "richmondQuestion2";
    private static final String richmondQuestion3Key = "frichmondQuestion3";
    private static final String richmondQuestion4Key = "richmondQuestion4";

    private static final String lastSectionKey = "lastSection";
    private static final String sectionAccessDateKey = "accessDate";
    private static final String sectionAccessTimeKey = "accessTime";
    private static final String sectionAccessInit = "accessDuration";


    private static final String lastSubsectionMessagesKey = "lastSubsectionMessagesKey";

    private static final String smokeFreeQuestionWithoutResponseKey = "followUpQuestionWithoutResponse";

    private static final String messagesFrequencyQuestionWithoutResponseKey = "messageFrequencyQuestionWithoutResponse";


    // DEFAULT VALUES
    // Not relevant user data: data used in the app but no in analytics

    private static final String GENERIC_CREDENTIALS = "User";
    private static final String GENERIC_USER_NICK = "";


    // Relevant user data: data used both in app and in analytics
    private static final String REGISTER_DATE = "20160728";

    private static final String GENERIC_GENDER = "notFilled";
    private static final String GENERIC_BIRTH_DATE ="";
    private static final String GENERIC_EMPLOYMENT_STATUS = "notFilled";
    private static final String GENERIC_STARTED_SMOKING_DATE ="";
    private static final String GENERIC_QUITTING_DATE = "20160728";
    private static final Float GENERIC_PREVIOUS_DAILY_CIGARETTES = 0f;
    private static final Float GENERIC_WEEKLY_TOBACCO_EXPENDITURE = 0f;
    private static final String GENERIC_CURRENCY = "\\u20ac";

    private static final String GENERIC_PATIENT_CODE = "USER_NOT_TRIED_INTRODUCE_CODE_YET";
    public static final String NOT_HAVE_PATIENT_CODE = "NOT_HAVE_PATIENT_CODE";

    private static final String DAILY_FITNESS_ACTIVITY_LAST_DAYS = "";
    private static final String LAST_GOOGLE_FIT_CONNECTION_DATE = "20160728000000";

    //User preferences

    private static final Boolean GENERIC_QUESTIONNAIRE_SETUP_VALUE = false;

    private static final String GENERIC_ANSWER = "";
    private static final String GENERIC_ANSWER_HOUR = "-1:-1";


    private static final String default_day_week_allowed = "t";


    // Relevant and transparent user data: information used in analytic but transparent to the user

    private static final Integer GENERIC_FAGERSTROM_RESULTS = -1;
    private static final Integer GENERIC_FAGERSTROM_QUESTION = -1;
    private static final Integer GENERIC_RICHMOND_RESULTS = -1;
    private static final Integer GENERIC_RICHMOND_QUESTION = -1;

    // Casual questions

    private String default_id_smoke_free_question_in_server = "99999999";
    private String default_date_received_smoke_free_question = "yyyyMMddHHmmss";

    private String default_id_messages_frequency_question_in_server = "99999999";
    private String default_date_received_messages_frequency_question = "yyyyMMddHHmmss";


    //CHECKS ABOUT FILL DATA
    //KEYS
    private final String isLoggedKey = "is_logged";
    private final String isFirstAccessToMainSectionKey = "is_first_access_to_main_activity";
    private final String isFilledDemographicDataKey = "is_filled_demographic_data";
    private final String isFilledTestFagerstromKey = "is_filled_fagerstrom";
    private final String isFilledPreviousSmokingHabitsKey = "is_filled_previous_smoking_habits";
    private final String isFilledTestRichmondKey = "is_filled_richmond";
    private final String isQuittingDateFilledKey = "is_filled_date_begin_treatment";
    private final String hasIntroducedActiveQuittingAttempDateInThisSessionKey = "have_introduced_active_quitting_attemp";
    private final String isFirstAccessToPersonalDataSectionKey = "is_first_access_to_personal_data_section";
    private final String isFitnessActivityUpdatedKey = "is_fitness_activity_updated";
    private final String extendedProfileFormCompletionStateKey = "extended_profile_form_completion_state_not_updated";

    //default VALUES
    private static boolean is_logged = false;
    private static boolean is_first_access_to_main_activity = true;
    private static boolean is_filled_demographic_data = false;
    private static boolean is_filled_fagerstrom = false;
    private static boolean is_filled_richmond = false;
    private static boolean is_filled_previous_smoking_habits = false;
    private static boolean is_filled_date_begin_treatment = false;
    private static boolean has_introduced_active_quitting_attemp_date_in_this_session = false;
    private static boolean is_first_access_to_personal_data_section = true;
    private static boolean is_fitness_activity_updated = true;
    public static int extended_profile_form_completion_state_not_updated = 0;

    private static boolean there_are_smoke_free_question_without_response = false;
    private static boolean there_are_messages_frequency_question_without_response = false;


    //SharedPreferences management params
    private static SessionData INSTANCE = null;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;


    public SessionData(Context context) {
        this.preferences = context.getSharedPreferences(sessionData, Context.MODE_PRIVATE);
        this.editor = preferences.edit();
    }


    private static void setupInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (SessionData.class) {
                if (INSTANCE == null) {
                    INSTANCE = new SessionData(context);
                }
            }
        }
    }

    public String getPatientCode(){
        return preferences.getString(patientCodeKey, GENERIC_PATIENT_CODE);
    }

    public void setPatientCode(String patientCode){
        editor.putString(patientCodeKey, patientCode);
        editor.apply();
    }

    public Boolean isFilledPatientCodeQuestion(){
        return !getPatientCode().equals(GENERIC_PATIENT_CODE);
    }


    public static SessionData getSessionData(Context context) {
        if (INSTANCE == null) {
            setupInstance(context);
        }
        return INSTANCE;
    }

    public String getLastSection() {
        return preferences.getString(lastSectionKey, "NA");
    }

    public String getSectionAccessDate() {
        return preferences.getString(sectionAccessDateKey, "00-00-0000");
    }

    public String getSectionAccessTime() {
        return preferences.getString(sectionAccessTimeKey, "00:00:00.00");
    }

    public Float getSectionAccessInit() {
        return preferences.getFloat(sectionAccessInit, 0f);
    }

    public String getLastSubsectionMessages() {
        return preferences.getString(lastSubsectionMessagesKey, "NA");
    }

    public void setLastSection(String section) {
        editor.putString(lastSectionKey, section);
        editor.apply();
    }

    public void setSectionAccessDate(String date) {
        editor.putString(sectionAccessDateKey, date);
        editor.apply();
    }

    public void setSectionAccessTime(String time) {
        editor.putString(sectionAccessTimeKey, time);
        editor.apply();
    }

    public void setSectionAccessInit(Float duration) {
        editor.putFloat(sectionAccessInit, duration);
        editor.apply();
    }

    public void setLastSubsectionMessages(String subsection) {
        editor.putString(lastSubsectionMessagesKey, subsection);
        editor.apply();
    }

    public void setRegisterDate(String registerDate){
        editor.putString(registerDateKey, registerDate);
        editor.apply();
    }

    public Calendar getRegisterDate(){
        return SFBDate.stringToCalendar(preferences.getString(registerDateKey, REGISTER_DATE));
    }

    public String getLanguage(){
        return preferences.getString(languageKey, Locale.getDefault().getLanguage());
    }

    public void setLanguage(String language){
        editor.putString(languageKey, language);
        editor.apply();
    }

    public void setFCMToken(String token) {
        editor.putString(FCMTokenKey, token);
        editor.apply();
    }

    public String getFCMToken() {
        return preferences.getString(FCMTokenKey, "");
    }

    public void setIsFirebaseTokenUpdatedInServer(Boolean isFirebaseTokenUpdated){
        editor.putBoolean(isFirebaseTokenUpdatedKey, isFirebaseTokenUpdated);
        editor.apply();
    }
    public Boolean getIsFirebaseTokenUpdatedInServer(){
        return preferences.getBoolean(isFirebaseTokenUpdatedKey, false);
    }

    public boolean isFilledPreference(String key) {
        return preferences.contains(key);
    }

    //Generic check for data filled

    private boolean isFilledData(String key) {
        return preferences.contains(key);
    }

    // Public checks getters and setters

    public boolean isFilledName() {
        return isFilledData(userNickKey);
    }

    public boolean isFilledGender() {
        return isFilledData(genderKey);
    }

    public boolean isFilledBirthDate() {
        return isFilledData(birthDateKey);
    }

    public boolean isFilledEmployment() {
        return isFilledData(employmentStatusKey);
    }

    public boolean isFilledStartSmokingData() {
        return isFilledData(startedSmokingDateKey);
    }

    public boolean isFilledDailyCigarettes() {
        return isFilledData(previousDailyCigarettesKey);
    }

    public boolean isFilledWeeklyExpenditure() {
        return isFilledData(weeklyTobaccoExpenditureKey);
    }

    public Boolean isLogged() {
        return preferences.getBoolean(isLoggedKey, is_logged);
    }

    public boolean isFilledPersonalData() {
        return preferences.getBoolean(isFilledDemographicDataKey, is_filled_demographic_data);
    }

    public boolean hasIntroducedActiveQuittingAttempDateInThisSession(){
        return preferences.getBoolean(hasIntroducedActiveQuittingAttempDateInThisSessionKey, has_introduced_active_quitting_attemp_date_in_this_session);
    }

    public void setHasIntroducedActiveQuittingAttempDateInThisSession(Boolean introduced){
        editor.putBoolean(hasIntroducedActiveQuittingAttempDateInThisSessionKey, introduced);
        editor.apply();
    }

    public int getExtendedProfileFormCompletionState(){
        return preferences.getInt(extendedProfileFormCompletionStateKey, extended_profile_form_completion_state_not_updated);
    }
    public void setExtendedProfileFormCompletionState(int extendedProfileFormCompletionState){
        editor.putInt(extendedProfileFormCompletionStateKey, extendedProfileFormCompletionState);
        editor.apply();
    }

    public Boolean thereAreASmokeFreeQuestionWithoutResponse(){
        return preferences.getBoolean(smokeFreeQuestionWithoutResponseKey, there_are_smoke_free_question_without_response);
    }

    public void changeIfThereAreASmokeFreeQuestionWithoutResponse(Boolean change){
        editor.putBoolean(smokeFreeQuestionWithoutResponseKey, change);
        editor.apply();
    }

    public Boolean thereAreAMessagesFrequencyQuestionWithoutResponse(){
        return preferences.getBoolean(messagesFrequencyQuestionWithoutResponseKey, there_are_messages_frequency_question_without_response);
    }

    public void changeIfThereAreAMessagesFrequencyQuestionWithoutResponse(Boolean change){
        editor.putBoolean(messagesFrequencyQuestionWithoutResponseKey, change);
        editor.apply();
    }


    public String getIdSmokeFreeQuestionInServer(){
        return preferences.getString(idSmokeFreeQuestionInServerKey, default_id_smoke_free_question_in_server);
    }

    public void setIdSmokeFreeQuestionInServer(String idInServer){
        editor.putString(idSmokeFreeQuestionInServerKey, idInServer);
        editor.apply();
    }

    public String getDateReceivedSmokeFreeQuestion(){
        return preferences.getString(dateReceivedSmokeFreeQuestionKey, default_date_received_smoke_free_question);

    }

    public void setDateReceivedSmokeFreeQuestion(String dateReceived){
        editor.putString(dateReceivedSmokeFreeQuestionKey, dateReceived);
        editor.apply();
    }

    public String getIdMessagesFrequencyQuestionInServer(){
        return preferences.getString(idMessagesFrequencyQuestionInServerKey, default_id_messages_frequency_question_in_server);
    }

    public void setIdMessagesFrequencyQuestionInServer(String idInServer){
        editor.putString(idMessagesFrequencyQuestionInServerKey, idInServer);
        editor.apply();
    }

    public String getDateReceivedMessagesFrequencyQuestion(){
        return preferences.getString(dateReceivedMessagesFrequencyQuestionKey, default_date_received_messages_frequency_question);

    }

    public void setDateReceivedMessagesFrequencyQuestion(String dateReceived){
        editor.putString(dateReceivedMessagesFrequencyQuestionKey, dateReceived);
        editor.apply();
    }



    public boolean isIncompletePersonalData(){
        return !isFilledPersonalData() &&
                (!getUserNick().equals(GENERIC_USER_NICK)
                || !getGender().equals(GENERIC_GENDER)
                || !SFBDate.dateToString(getBirthDate()).equals(GENERIC_BIRTH_DATE)
                || !getEmploymentStatus().equals(GENERIC_EMPLOYMENT_STATUS)
                || !SFBDate.dateToString(getStartedSmokingDate()).equals(GENERIC_STARTED_SMOKING_DATE));
    }

    private void demographicDataComplete() {
        editor.putBoolean(isFilledDemographicDataKey, true);
        editor.apply();
    }

    public boolean isFilledFagerstromTest() {
        return preferences.getBoolean(isFilledTestFagerstromKey, is_filled_fagerstrom);
    }

    private void fagerstromTestDone() {
        editor.putBoolean(isFilledTestFagerstromKey, true);
        editor.apply();
    }

    public boolean isFilledRichmondTest() {
        return preferences.getBoolean(isFilledTestRichmondKey, is_filled_richmond);
    }

    private void richmondTestDone() {
        editor.putBoolean(isFilledTestRichmondKey, true);
        editor.apply();
    }

    public boolean isFilledPreviousSmokingHabits(){
        boolean res = preferences.getBoolean(isFilledPreviousSmokingHabitsKey,is_filled_previous_smoking_habits);
        return res;
    }

    private void previousSmokingHabitsFilled(){
        editor.putBoolean(isFilledPreviousSmokingHabitsKey, true);
        editor.apply();
    }

    public boolean isQuittingDateFilled() {
        return preferences.getBoolean(isQuittingDateFilledKey, is_filled_date_begin_treatment);
    }

    private void quittingDateFilled() {
        editor.putBoolean(isQuittingDateFilledKey, true);
        editor.apply();
    }

    public boolean isDataForBeginTreatmentCompleted() {
        return isFilledPersonalData() && isFilledRichmondTest() &&
                isFilledFagerstromTest() && isFilledPreviousSmokingHabits();
    }


    public Boolean isFirstAccessToMainSection() {
        Boolean result = preferences.getBoolean(isFirstAccessToMainSectionKey, is_first_access_to_main_activity);
        setFirstAccessToMainSection(false);
        return result;
    }

    private void setFirstAccessToMainSection(Boolean result) {
        editor.putBoolean(isFirstAccessToMainSectionKey, result);
        editor.apply();
    }

    public boolean isFirstAccessToPersonalDataSection() {
        Boolean result = preferences.getBoolean(isFirstAccessToPersonalDataSectionKey, is_first_access_to_personal_data_section);
        setFirstAccessToPersonalDataSection(false);
        return result;
    }

    public void setFirstAccessToPersonalDataSection(Boolean result) {
        editor.putBoolean(isFirstAccessToPersonalDataSectionKey, result);
        editor.apply();
    }




    public String[] getWeekDaysPreferences() {
        return new String[]{
                preferences.getString(ALLOW_MONDAY_KEY, default_day_week_allowed),
                preferences.getString(ALLOW_TUESDAY_KEY, default_day_week_allowed),
                preferences.getString(ALLOW_WEDNESDAY_KEY, default_day_week_allowed),
                preferences.getString(ALLOW_THURSDAY_KEY, default_day_week_allowed),
                preferences.getString(ALLOW_FRIDAY_KEY, default_day_week_allowed),
                preferences.getString(ALLOW_SATURDAY_KEY, default_day_week_allowed),
                preferences.getString(ALLOW_SUNDAY_KEY, default_day_week_allowed),
                preferences.getString(KEY_HOUR_ALLOW_BEGIN_M, GENERIC_ANSWER_HOUR),
                preferences.getString(KEY_HOUR_ALLOW_BEGIN_T, GENERIC_ANSWER_HOUR),
                preferences.getString(KEY_HOUR_ALLOW_BEGIN_W, GENERIC_ANSWER_HOUR),
                preferences.getString(KEY_HOUR_ALLOW_BEGIN_TH, GENERIC_ANSWER_HOUR),
                preferences.getString(KEY_HOUR_ALLOW_BEGIN_F, GENERIC_ANSWER_HOUR),
                preferences.getString(KEY_HOUR_ALLOW_BEGIN_SA, GENERIC_ANSWER_HOUR),
                preferences.getString(KEY_HOUR_ALLOW_BEGIN_SU, GENERIC_ANSWER_HOUR),
                preferences.getString(KEY_HOUR_ALLOW_END_M, GENERIC_ANSWER_HOUR),
                preferences.getString(KEY_HOUR_ALLOW_END_T, GENERIC_ANSWER_HOUR),
                preferences.getString(KEY_HOUR_ALLOW_END_W, GENERIC_ANSWER_HOUR),
                preferences.getString(KEY_HOUR_ALLOW_END_TH, GENERIC_ANSWER_HOUR),
                preferences.getString(KEY_HOUR_ALLOW_END_F, GENERIC_ANSWER_HOUR),
                preferences.getString(KEY_HOUR_ALLOW_END_SA, GENERIC_ANSWER_HOUR),
                preferences.getString(KEY_HOUR_ALLOW_END_SU, GENERIC_ANSWER_HOUR)
        };
    }

    public void setWeekDaysPreferences(String[] preferences) {
        editor.putString(ALLOW_MONDAY_KEY, preferences[0]);
        editor.putString(ALLOW_TUESDAY_KEY, preferences[1]);
        editor.putString(ALLOW_WEDNESDAY_KEY, preferences[2]);
        editor.putString(ALLOW_THURSDAY_KEY, preferences[3]);
        editor.putString(ALLOW_FRIDAY_KEY, preferences[4]);
        editor.putString(ALLOW_SATURDAY_KEY, preferences[5]);
        editor.putString(ALLOW_SUNDAY_KEY, preferences[6]);
        editor.putString(KEY_HOUR_ALLOW_BEGIN_M, preferences[7]);
        editor.putString(KEY_HOUR_ALLOW_BEGIN_T, preferences[8]);
        editor.putString(KEY_HOUR_ALLOW_BEGIN_W, preferences[9]);
        editor.putString(KEY_HOUR_ALLOW_BEGIN_TH, preferences[10]);
        editor.putString(KEY_HOUR_ALLOW_BEGIN_F, preferences[11]);
        editor.putString(KEY_HOUR_ALLOW_BEGIN_SA, preferences[12]);
        editor.putString(KEY_HOUR_ALLOW_BEGIN_SU, preferences[13]);
        editor.putString(KEY_HOUR_ALLOW_END_M, preferences[14]);
        editor.putString(KEY_HOUR_ALLOW_END_T, preferences[15]);
        editor.putString(KEY_HOUR_ALLOW_END_W, preferences[16]);
        editor.putString(KEY_HOUR_ALLOW_END_TH, preferences[17]);
        editor.putString(KEY_HOUR_ALLOW_END_F, preferences[18]);
        editor.putString(KEY_HOUR_ALLOW_END_SA, preferences[19]);
        editor.putString(KEY_HOUR_ALLOW_END_SU, preferences[20]);
        editor.apply();
    }


    private Boolean getQuestionnaireSetup() {
        return preferences.getBoolean(questionnairePreferencesKey, GENERIC_QUESTIONNAIRE_SETUP_VALUE);
    }

    public void setQuestionnaireSetup(boolean value) {
        editor.putBoolean(questionnairePreferencesKey, value);
        editor.apply();
    }

    public Boolean isQuestionnaireSetup() {
        return (getQuestionnaireSetup() != GENERIC_QUESTIONNAIRE_SETUP_VALUE);
    }

    public String getUserNick() {
        return preferences.getString(userNickKey, GENERIC_USER_NICK);
    }

    public void setUserNick(String userName) {
        editor.putString(userNickKey, userName);
        editor.apply();
    }

    public String getGender() {
        return preferences.getString(genderKey, GENERIC_GENDER);
    }

    public void setGender(String gender) {
        editor.putString(genderKey, gender);
        editor.apply();
    }

    public Calendar getBirthDate() {
        return SFBDate.stringToCalendar(preferences.getString(birthDateKey, GENERIC_BIRTH_DATE));
    }

    public void setBirthDate(String birthDate) {
        editor.putString(birthDateKey, birthDate);
        editor.apply();
    }

    public String getEmploymentStatus() {
        return preferences.getString(employmentStatusKey, GENERIC_EMPLOYMENT_STATUS);
    }

    public void setEmploymentStatus(String employmentStatus) {
        editor.putString(employmentStatusKey, employmentStatus);
        editor.apply();
    }

    public SFBPersonalData getPersonalData() throws ParseException {
        return new SFBPersonalData(
                getUserNick(),
                getGender().charAt(0),
                getBirthDate(),
                getEmploymentStatus()
        );
    }

    public String getUserCredentials() {
        return preferences.getString(userCredentialsKey, GENERIC_CREDENTIALS);
    }

    public String getUserId() {
        return preferences.getString(userCredentialsKey, GENERIC_CREDENTIALS).split(":")[0];
    }

    public void setUserCredentials(String credentials) {
        editor.putString(userCredentialsKey, credentials);
        editor.putBoolean(isLoggedKey, true);
        editor.apply();
    }

    public Calendar getQuittingDate() {
        return SFBDate.stringToCalendar(preferences.getString(quittingDateKey, GENERIC_QUITTING_DATE));
    }

    public void setQuittingDate(String quittingDate) {
        editor.putString(quittingDateKey, quittingDate);
        quittingDateFilled();
    }

    public Calendar getStartedSmokingDate() {
        return SFBDate.stringToCalendar(preferences.getString(startedSmokingDateKey, GENERIC_STARTED_SMOKING_DATE));
    }

    public void setStartedSmokingDate(String startedSmokingDate) {
        editor.putString(startedSmokingDateKey, startedSmokingDate);
        editor.apply();
    }

    public void resetTreatmentData() {
        editor.remove(quittingDateKey);
        editor.remove(isQuittingDateFilledKey);
        editor.remove(isFirstAccessToPersonalDataSectionKey);
        editor.apply();
    }

    public Float getPreviousDailyCigarettes() {
        return preferences.getFloat(previousDailyCigarettesKey, GENERIC_PREVIOUS_DAILY_CIGARETTES);
    }

    public void setPreviousDailyCigarettes(Float previousDailyCigarettes) {
        editor.putFloat(previousDailyCigarettesKey, previousDailyCigarettes);
        editor.apply();
        if(!getWeeklyTobaccoExpenditure().equals(GENERIC_WEEKLY_TOBACCO_EXPENDITURE))
            previousSmokingHabitsFilled();
    }

    public Float getWeeklyTobaccoExpenditure() {
        return preferences.getFloat(weeklyTobaccoExpenditureKey, GENERIC_WEEKLY_TOBACCO_EXPENDITURE);
    }

    public void setWeeklyTobaccoExpenditure(Float weeklyTobaccoExpenditure) {
        editor.putFloat(weeklyTobaccoExpenditureKey, weeklyTobaccoExpenditure);
        editor.apply();
        if(!getPreviousDailyCigarettes().equals(GENERIC_PREVIOUS_DAILY_CIGARETTES))
            previousSmokingHabitsFilled();
    }

    public String getCurrency(){
        return preferences.getString(currencyKey, GENERIC_CURRENCY);
    }

    public void setCurrency(String currency){
        editor.putString(currencyKey, currency);
        editor.apply();
    }

    public boolean checkForPersonalDataComplete() {
        boolean res = false;
        res = res || getUserNick().equals(GENERIC_USER_NICK)
                || getGender().equals(GENERIC_GENDER)
                || SFBDate.dateToString(getBirthDate()).equals(GENERIC_BIRTH_DATE)
                || getEmploymentStatus().equals(GENERIC_EMPLOYMENT_STATUS)
                || SFBDate.dateToString(getStartedSmokingDate()).equals(GENERIC_STARTED_SMOKING_DATE);

        if (!res)
            demographicDataComplete();

        return !res;
    }

    public Integer getFagerstromResult() {
        return preferences.getInt(fagerstromResultsKey, GENERIC_FAGERSTROM_RESULTS);
    }

    //stores the numeric fagerstrom form result
    public void setFagerstromResult(int fagerstromResults) {
        editor.putInt(fagerstromResultsKey, fagerstromResults);
        fagerstromTestDone();
    }

    public Integer[] getFagerstromAnswers() {
        return new Integer[]{
                preferences.getInt(fagerstromQuestion1Key, GENERIC_FAGERSTROM_QUESTION),
                preferences.getInt(fagerstromQuestion2Key, GENERIC_FAGERSTROM_QUESTION),
                preferences.getInt(fagerstromQuestion3Key, GENERIC_FAGERSTROM_QUESTION),
                preferences.getInt(fagerstromQuestion4Key, GENERIC_FAGERSTROM_QUESTION),
                preferences.getInt(fagerstromQuestion5Key, GENERIC_FAGERSTROM_QUESTION),
                preferences.getInt(fagerstromQuestion6Key, GENERIC_FAGERSTROM_QUESTION),
        };
    }

    // stores the fagerstrom form answers of the last quitting period
    public void setFagerstromAnswers(Integer[] answers) {
        String[] answersKeys = {fagerstromQuestion1Key, fagerstromQuestion2Key, fagerstromQuestion3Key,
                fagerstromQuestion4Key, fagerstromQuestion5Key, fagerstromQuestion6Key};
        for (int i = 0; i < answers.length; i++) {
            editor.putInt(answersKeys[i], answers[i]);
        }
        editor.apply();
    }


    public Integer getRichmondResult() {
        return preferences.getInt(richmondResultsKey, GENERIC_RICHMOND_RESULTS);
    }

    //stores the numeric richmond form result
    public void setRichmondResult(int richmondResults) {
        editor.putInt(richmondResultsKey, richmondResults);
        richmondTestDone();
    }


    public Integer[] getRichmondAnswers() {
        return new Integer[]{
                preferences.getInt(richmondQuestion1Key, GENERIC_RICHMOND_QUESTION),
                preferences.getInt(richmondQuestion2Key, GENERIC_RICHMOND_QUESTION),
                preferences.getInt(richmondQuestion3Key, GENERIC_RICHMOND_QUESTION),
                preferences.getInt(richmondQuestion4Key, GENERIC_RICHMOND_QUESTION),
        };
    }


    // stores the richmond form answers of the last quitting period
    public void setRichmondAnswers(Integer[] answers) {
        String[] answersKeys = {richmondQuestion1Key, richmondQuestion2Key, richmondQuestion3Key,
                richmondQuestion4Key};
        for (int i = 0; i < answers.length; i++) {
            editor.putInt(answersKeys[i], answers[i]);
        }
        editor.apply();
    }

    public SFBSmokingData getSmokingData(Context context) {
        //To avoid using more resources for the moment, this method only obtains the last quitting
        // attempt found in the local database, or none if there isn't
        List<SFBQuittingAttempt> lastQuittingPeriodList = new ArrayList<>();
        SFBQuittingAttempt lastQuittingPeriod = new LocalDataBaseHelper(context).selectLastQuittingAttempt();
        if (lastQuittingPeriod != null) {
            lastQuittingPeriodList.add(lastQuittingPeriod);
        }
        return new SFBSmokingData(
                getStartedSmokingDate(),
                lastQuittingPeriodList
        );
    }


    public SFBUser getUserData(Context context) {
        SFBPersonalData personalData;
        try {
            personalData = this.getPersonalData();
        } catch (ParseException e) {
            e.printStackTrace();
            personalData = null;
        }
        return new SFBUser(this.getUserId(), personalData, this.getSmokingData(context));
    }

    public Boolean getIsConfigurationUpdated(){
        return preferences.getBoolean(isConfigurationUpdatedKey, GENERIC_IS_CONFIGURATION_UPDATED);
    }

    public void  setIsConfigurationUpdated(Boolean isConfigurationUpdated){
        editor.putBoolean(isConfigurationUpdatedKey, isConfigurationUpdated);
        editor.apply();
    }

    public void setMuteNotifications(int notificationsCode) {
        editor.putInt(KEY_MUTE_CODE, notificationsCode);
        editor.apply();
    }

    public Integer getMuteNotifications() {
        //Check if the mute notification time it is over
        Calendar muteUntil = getMuteNotificationsUntil();
        if(muteUntil.before(Calendar.getInstance())) //Yes: set muteNotification to disable
            setMuteNotifications(0);

        return preferences.getInt(KEY_MUTE_CODE, GENERIC_MUTE_CODE);
    }

    public void setMuteNotificationsUntil(Calendar calendar) {
        if (calendar.before(Calendar.getInstance())) {
            editor.putString(KEY_MUTE_UNTIL, GENERIC_MUTE_UNTIL);
        } else {
            editor.putString(KEY_MUTE_UNTIL, SFBDate.timestampToString(calendar));
        }
        editor.apply();
    }

    public Calendar getMuteNotificationsUntil() {
        String date = preferences.getString(KEY_MUTE_UNTIL, GENERIC_MUTE_UNTIL);
        Calendar calendar = Calendar.getInstance();
        if (date.equalsIgnoreCase(GENERIC_MUTE_UNTIL)) {
            calendar.add(Calendar.DAY_OF_YEAR, -1);
        } else {
            calendar = SFBDate.stringToCalendar(date);
        }
        return calendar;
    }


    public void deletePreferences() {
        editor.clear();
        editor.apply();
    }


    public void setLastGoogleFitConnectionDate(Calendar connectionDate){
        editor.putString(lastGoogleFitConnectionDateKey, SFBDate.timestampToString(connectionDate));
        editor.apply();
    }
    public Calendar getLastGoogleFitConnectionDate(){
        return SFBDate.stringToCalendar(preferences.getString(lastGoogleFitConnectionDateKey, LAST_GOOGLE_FIT_CONNECTION_DATE));
    }

    public void setDailyFitnessActivityLastDays(String dailyFitnessActivityLastDays){
        if(!dailyFitnessActivityLastDays.equals("")) {
            editor.putString(dailyFitnessActivityLastDaysKey, dailyFitnessActivityLastDays);
            editor.apply();
        }
    }
    public String getDailyFitnessActivityLastDays(){
        return preferences.getString(dailyFitnessActivityLastDaysKey, DAILY_FITNESS_ACTIVITY_LAST_DAYS);
    }

    public void setIsFitnessActivityUpdated(Boolean fitnessActivityUpdated){
        editor.putBoolean(isFitnessActivityUpdatedKey, fitnessActivityUpdated);
        editor.apply();
    }
    public Boolean getIsFitnessActivityUpdated(){
        return preferences.getBoolean(isFitnessActivityUpdatedKey, is_fitness_activity_updated);
    }


}
