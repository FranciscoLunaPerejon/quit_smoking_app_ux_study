package com.salumedia.quitandreturn.views;

import android.app.ActivityManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatImageView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;

import com.github.amlcurran.showcaseview.ShowcaseView;
import com.github.amlcurran.showcaseview.targets.Target;
import com.github.amlcurran.showcaseview.targets.ViewTarget;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.fitness.Fitness;
import com.google.android.gms.fitness.FitnessActivities;
import com.google.android.gms.fitness.data.Bucket;
import com.google.android.gms.fitness.data.DataSet;
import com.google.android.gms.fitness.data.DataType;
import com.google.android.gms.fitness.request.DataReadRequest;
import com.google.android.gms.fitness.result.DataReadResult;
import com.salumedia.quitandreturn.BackgroundService;
import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBAppInteractionAnalytic;
import com.salumedia.quitandreturn.model.SFBMessageInteractionAnalytic;
import com.salumedia.quitandreturn.model.SFBMiniGameAnalytics;
import com.salumedia.quitandreturn.session.local.LocalDataBaseHelper;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.session.server.XMLHttpPost;
import com.salumedia.quitandreturn.session.server.xml_operations.GenerateXMLFile;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBDate;
import com.salumedia.quitandreturn.utils.SFBEncode;
import com.salumedia.quitandreturn.utils.SFBSessionUtils;
import com.salumedia.quitandreturn.views.dialogs.DatePickerDialogFragment;
import com.salumedia.quitandreturn.views.main_navigationdrawer_sections.TabsInitFragment;
import com.salumedia.quitandreturn.views.main_navigationdrawer_sections.section_profile_data.UserProfileDataFragment;
import com.salumedia.quitandreturn.views.main_navigationdrawer_sections.section_user.UserStatisticsFragment;
import com.salumedia.quitandreturn.views.minigames_section.MiniGamesMenuFragment;
import com.salumedia.quitandreturn.views.others_navigationdrawer_sections.AboutFragment;
import com.salumedia.quitandreturn.views.others_navigationdrawer_sections.PreferencesFragment;

import java.io.IOException;
import java.lang.reflect.Field;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static java.text.DateFormat.getDateInstance;

public class MainActivity extends AppCompatActivity
        implements TabsInitFragment.OnTabsInitFragmentInteractionListener,
        UserProfileDataFragment.OnPersonalDataFragmentInteractionListener,
        UserStatisticsFragment.OnBenefitsFragmentInteractionListener,
        DatePickerDialogFragment.OnDatePickerFragmentInteractionListener,
        PreferencesFragment.OnPreferencesFragmentInteractionListener,
        View.OnClickListener {


    //TODO In this class, there are some repeated code that can be simplified using auxiliary methods
    // For example, click on configuration item of NavigationView is very similar to click on configuration button of Toolbar


    private static final String TAG = "Main_Activity";

    private SessionData sessionData;

    private static final String AUTH_PENDING = "auth_state_pending";
    private boolean authInProgress = false;
    private GoogleApiClient mApiClient;

    private SendAnalyticsTask mSendAnalyticsTask;
    private UpdateFirebaseTokenTask mUpdateTokenTask;

    private static final String SECTION_MAIN = "MainSection";
    private static final String SECTION_BENEFITS = "BenefitsSection";
    private static final String SECTION_MESSAGES = "Messages";
    private static final String SECTION_PROFILE_DATA = "Profile Data";
    private static final String SECTION_PREFERENCES = "Preferences";
    private static final String SECTION_ABOUT = "About";
    private static final String SECTION_MINI_GAMES = "Mini Games";

    public static final String SUBSECTION_KEY = "subsection";

    private android.support.v7.widget.Toolbar toolbar;

    private String lastSectionFragment = SECTION_MAIN;
    private String lastSubsection = SECTION_BENEFITS;

    DrawerLayout mDrawerLayout;
    NavigationView mNavigationView;
    FragmentManager mFragmentManager;
    FragmentTransaction mFragmentTransaction;

    ShowcaseView tutorial;

    AppCompatImageView settingToolbarAccess;
    AppCompatImageView miniGamesToolbarAccess;
    AppCompatImageView tutorialButton;
    Button okBackToolbarButton;

    int counter = 0;

    // Where save the button id that invoke a DatePickerDialogFragment
    int idButtonDatePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sessionData = SessionData.getSessionData(MainActivity.this);
        setContentView(R.layout.activity_main);

        if(savedInstanceState != null) {
            authInProgress = savedInstanceState.getBoolean(AUTH_PENDING);
        }

        if (!isMyServiceRunning(BackgroundService.class)){ //método que determina si el servicio ya está corriendo o no
            Intent serv = new Intent(getApplicationContext(),BackgroundService.class); //serv de tipo Intent
            getApplicationContext().startService(serv); //ctx de tipo Context
            Log.d("App", "Service started");
        } else {
            Log.d("App", "Service already running");
        }

        mApiClient = new GoogleApiClient.Builder(this)
                .addApi(Fitness.HISTORY_API)
                .addScope(new Scope(Scopes.FITNESS_ACTIVITY_READ_WRITE))
                .addConnectionCallbacks(
                        new GoogleApiClient.ConnectionCallbacks() {
                            @Override
                            public void onConnected(Bundle bundle) {
                                Log.i(TAG, "Connected!!!");
                                // Now you can make calls to the Fitness APIs.  What to do?
                                // Look at some data!!
                                new ReadActiveTimeDataTask().execute();
                            }

                            @Override
                            public void onConnectionSuspended(int i) {
                                // If your connection to the sensor gets lost at some point,
                                // you'll be able to determine the reason and react to it here.
                                if (i == GoogleApiClient.ConnectionCallbacks.CAUSE_NETWORK_LOST) {
                                    Log.i(TAG, "Connection lost.  Cause: Network Lost.");
                                } else if (i == GoogleApiClient.ConnectionCallbacks.CAUSE_SERVICE_DISCONNECTED) {
                                    Log.i(TAG, "Connection lost.  Reason: Service Disconnected");
                                }
                            }


                        }
                )
                .enableAutoManage(this, 0, new GoogleApiClient.OnConnectionFailedListener() {
                    @Override
                    public void onConnectionFailed(ConnectionResult result) {
                        Log.i(TAG, "Google Play services connection failed. Cause: " +
                                result.toString());
                    }
                })
                .build();


        String initialSection = TabsInitFragment.TAB_BENEFITS;

        /**
         *Setup the DrawerLayout and NavigationView
         */

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        mNavigationView = (NavigationView) findViewById(R.id.shitstuff);


        /**
         * Lets inflate the very first fragment
         * Here , we are inflating the TabFragment as the first Fragment
         */

        if (getIntent().hasExtra(SUBSECTION_KEY)) {
            changeSection(getIntent().getStringExtra(SUBSECTION_KEY));
            initialSection = getIntent().getStringExtra(SUBSECTION_KEY);
        }

        mFragmentManager = getSupportFragmentManager();
        mFragmentTransaction = mFragmentManager.beginTransaction();
        mFragmentTransaction.replace(R.id.containerView, TabsInitFragment.newInstance(initialSection)).commit();


        /**
         * Setup Drawer Toggle of the Toolbar
         */

        toolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.main_text_title);
        ActionBarDrawerToggle mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.app_name,
                R.string.app_name);

        mDrawerLayout.addDrawerListener(mDrawerToggle);

        mDrawerToggle.syncState();

        // Tutorial instantiation
        tutorial = new ShowcaseView.Builder(this)
                .withMaterialShowcase()
                .setContentTitle(getString(R.string.tutorial_welcome_title))
                .setContentText(getString(R.string.tutorial_welcome_explanation))
                .setTarget(Target.NONE)
                .setOnClickListener(this)
                .setStyle(R.style.CustomShowcaseTheme1)
                .build();

        Button skipTutorialButton = (Button) LayoutInflater.from(this).inflate(R.layout.button_skip_tutorial, tutorial, false);
        RelativeLayout.LayoutParams secondParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        secondParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        secondParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        secondParams.setMargins(35, 0, 0, 35);
        skipTutorialButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tutorial.hide();
                tutorial.setStyle(R.style.CustomShowcaseTheme1);
            }
        });
        tutorial.addView(skipTutorialButton, secondParams);

        if(!SessionData.getSessionData(getApplicationContext()).isFirstAccessToMainSection())
            tutorial.hide();

        /**
         * Setup click events on the Navigation View Items.
         */

        mNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                mDrawerLayout.closeDrawers();

                int menuItemId = menuItem.getItemId();

                if (menuItemId == R.id.nav_user) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, TabsInitFragment.newInstance(TabsInitFragment.TAB_BENEFITS)).commit();
                    menuItem.setChecked(true);
                    toolbar.setTitle(R.string.main_text_title);
                    settingToolbarAccess.setVisibility(View.VISIBLE);
                    miniGamesToolbarAccess.setVisibility(View.VISIBLE);
                    okBackToolbarButton.setVisibility(View.GONE);
                    lastSectionFragment = SECTION_MAIN;
                    lastSubsection = SECTION_BENEFITS;

                }
                if (menuItemId == R.id.nav_messages) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, TabsInitFragment.newInstance(TabsInitFragment.TAB_MESSAGES)).commit();
                    menuItem.setChecked(true);
                    toolbar.setTitle(R.string.main_text_title);
                    settingToolbarAccess.setVisibility(View.VISIBLE);
                    miniGamesToolbarAccess.setVisibility(View.VISIBLE);
                    okBackToolbarButton.setVisibility(View.GONE);
                    lastSectionFragment = SECTION_MAIN;
                    lastSubsection = SECTION_MESSAGES;

                }
                if (menuItemId == R.id.nav_profile) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, TabsInitFragment.newInstance(TabsInitFragment.TAB_PROFILE_DATA)).commit();
                    menuItem.setChecked(true);
                    toolbar.setTitle(R.string.main_text_title);
                    settingToolbarAccess.setVisibility(View.VISIBLE);
                    miniGamesToolbarAccess.setVisibility(View.VISIBLE);
                    okBackToolbarButton.setVisibility(View.GONE);
                    lastSectionFragment = SECTION_MAIN;
                    lastSubsection = SECTION_PROFILE_DATA;

                }
                if (menuItemId == R.id.nav_configuration) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, new PreferencesFragment()).commit();
                    menuItem.setChecked(true);
                    toolbar.setTitle(R.string.message_pref_title);
                    settingToolbarAccess.setVisibility(View.GONE);
                    miniGamesToolbarAccess.setVisibility(View.GONE);
                    okBackToolbarButton.setVisibility(View.VISIBLE);
                    lastSectionFragment = SECTION_PREFERENCES;

                }
                if (menuItemId == R.id.nav_mini_games) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, new MiniGamesMenuFragment()).commit();
                    menuItem.setChecked(true);
                    toolbar.setTitle(R.string.mini_games_title);
                    settingToolbarAccess.setVisibility(View.GONE);
                    miniGamesToolbarAccess.setVisibility(View.GONE);
                    okBackToolbarButton.setVisibility(View.VISIBLE);
                    okBackToolbarButton.setText(R.string.back);
                    lastSectionFragment = SECTION_MINI_GAMES;

                }
                if (menuItemId == R.id.nav_about) {
                    FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.containerView, new AboutFragment()).commit();
                    menuItem.setChecked(true);
                    toolbar.setTitle(R.string.about_title);
                    settingToolbarAccess.setVisibility(View.GONE);
                    miniGamesToolbarAccess.setVisibility(View.GONE);
                    okBackToolbarButton.setVisibility(View.VISIBLE);
                    lastSectionFragment = SECTION_ABOUT;

                }
                if (menuItemId == R.id.log_out) {
                    //cleaning session variables and database
                    SessionData sd = SessionData.getSessionData(getApplicationContext());
                    sd.deletePreferences();
                    String dbName = (LocalDataBaseHelper.DATABASE_NAME);
                    getApplicationContext().deleteDatabase(dbName);
                    //Esthetic closing for the app
                    ProgressDialog closing = new ProgressDialog(MainActivity.this);

                    closing.setTitle(getString(R.string.wait_please));
                    closing.setMessage(getString(R.string.closing_app));
                    closing.show();

                    final Handler handler = new Handler();

                    handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                //Do something after 2500ms
                                                finish();
                                                if (Build.VERSION_CODES.KITKAT <= Build.VERSION.SDK_INT) {
                                                    ((ActivityManager) getApplication().getSystemService(ACTIVITY_SERVICE))
                                                            .clearApplicationUserData();
                                                } else{
                                                    SFBSessionUtils.deleteAppData(getApplication());
                                                }
                                                System.exit(0);
                                            }
                                        }
                            , 2500);
                }
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawerLayout);
                drawer.closeDrawer(GravityCompat.START);
                return true;
            }

        });

        settingToolbarAccess = (AppCompatImageView) findViewById(R.id.setting_toolbar);
        settingToolbarAccess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Check and change background of navigationview item
                mNavigationView.setCheckedItem(R.id.nav_configuration);

                // Call to configuration fragment
                FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.containerView, new PreferencesFragment()).commit();

                // Do changes in common views contained in activity
                toolbar.setTitle(R.string.message_pref_title);
                settingToolbarAccess.setVisibility(View.GONE);
                miniGamesToolbarAccess.setVisibility(View.GONE);
                okBackToolbarButton.setVisibility(View.VISIBLE);

                // Save current fragment shown
                lastSectionFragment = SECTION_PREFERENCES;
            }
        });

        miniGamesToolbarAccess = (AppCompatImageView) findViewById(R.id.mini_games_toolbar);
        miniGamesToolbarAccess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Check and change background of navigationview item
                mNavigationView.setCheckedItem(R.id.nav_mini_games);

                // Call to configuration fragment
                FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.containerView, new MiniGamesMenuFragment()).commit();

                // Do changes in common views contained in activity
                toolbar.setTitle(R.string.mini_games_title);
                settingToolbarAccess.setVisibility(View.GONE);
                miniGamesToolbarAccess.setVisibility(View.GONE);
                okBackToolbarButton.setVisibility(View.VISIBLE);
                okBackToolbarButton.setText(R.string.back);
                // Save current fragment shown
                lastSectionFragment = SECTION_MINI_GAMES;
            }
        });

        okBackToolbarButton = (Button) findViewById(R.id.button2_toolbar);
        okBackToolbarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        tutorialButton = (AppCompatImageView) findViewById(R.id.help_toolbar);
        tutorialButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFirstPageTutorial();
            }
        });

        okBackToolbarButton.setText(R.string.ok);
        okBackToolbarButton.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
        settingToolbarAccess.setVisibility(View.VISIBLE);
        miniGamesToolbarAccess.setVisibility(View.VISIBLE);
        tutorialButton.setVisibility(View.VISIBLE);

    }

    @Override
    protected void onResume() {
        super.onResume();
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
        switch (lastSectionFragment) {
            case SECTION_PREFERENCES:

                // Check and change background of navigationview item
                mNavigationView.setCheckedItem(R.id.nav_configuration);

                fragmentTransaction.replace(R.id.containerView, new PreferencesFragment()).commit();
                toolbar.setTitle(R.string.message_pref_title);
                settingToolbarAccess.setVisibility(View.GONE);
                miniGamesToolbarAccess.setVisibility(View.GONE);
                okBackToolbarButton.setVisibility(View.VISIBLE);
                break;
            case SECTION_MINI_GAMES:
                // Check and change background of navigationview item
                mNavigationView.setCheckedItem(R.id.nav_about);

                fragmentTransaction.replace(R.id.containerView, new MiniGamesMenuFragment()).commit();
                toolbar.setTitle(R.string.mini_games_title);
                settingToolbarAccess.setVisibility(View.GONE);
                miniGamesToolbarAccess.setVisibility(View.GONE);
                okBackToolbarButton.setVisibility(View.VISIBLE);
                break;
            case SECTION_ABOUT:
                // Check and change background of navigationview item
                mNavigationView.setCheckedItem(R.id.nav_about);

                fragmentTransaction.replace(R.id.containerView, new AboutFragment()).commit();
                toolbar.setTitle(R.string.about_title);
                settingToolbarAccess.setVisibility(View.GONE);
                miniGamesToolbarAccess.setVisibility(View.GONE);
                okBackToolbarButton.setVisibility(View.VISIBLE);
                break;
            default:
                switch (lastSubsection) {
                    case SECTION_MESSAGES:

                        // Check and change background of navigationview item
                        mNavigationView.setCheckedItem(R.id.nav_messages);

                        fragmentTransaction.replace(R.id.containerView, TabsInitFragment.newInstance(TabsInitFragment.TAB_MESSAGES)).commit();
                        toolbar.setTitle(R.string.main_text_title);
                        break;
                    case SECTION_PROFILE_DATA:

                        // Check and change background of navigationview item
                        mNavigationView.setCheckedItem(R.id.nav_profile);

                        fragmentTransaction.replace(R.id.containerView, TabsInitFragment.newInstance(TabsInitFragment.TAB_PROFILE_DATA)).commit();
                        toolbar.setTitle(R.string.main_text_title);
                        break;
                    default:

                        // Check and change background of navigationview item
                        mNavigationView.setCheckedItem(R.id.nav_user);

                        fragmentTransaction.replace(R.id.containerView, TabsInitFragment.newInstance(TabsInitFragment.TAB_BENEFITS)).commit();
                        lastSectionFragment = SECTION_BENEFITS;
                        toolbar.setTitle(R.string.main_text_title);
                        break;
                }
                break;
        }
        // Try to send analytical data
        mSendAnalyticsTask = new SendAnalyticsTask(this);
        mSendAnalyticsTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);

        if(!sessionData.getIsFirebaseTokenUpdatedInServer()){
            mUpdateTokenTask = new UpdateFirebaseTokenTask(this);
            mUpdateTokenTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void) null);
        }
    }

    @Override
    public void onBackPressed() {
        if (lastSectionFragment.equals(SECTION_PREFERENCES) ||
                lastSectionFragment.equals(SECTION_ABOUT) ||
                lastSectionFragment.equals(SECTION_MINI_GAMES)) {

            FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();

            lastSectionFragment = SECTION_MAIN;

            switch (lastSubsection) {
                case SECTION_MESSAGES:

                    // Check and change background of navigationview item
                    mNavigationView.setCheckedItem(R.id.nav_messages);

                    fragmentTransaction.replace(R.id.containerView, TabsInitFragment.newInstance(TabsInitFragment.TAB_MESSAGES)).commit();
                    toolbar.setTitle(R.string.main_text_title);
                    break;
                case SECTION_PROFILE_DATA:

                    // Check and change background of navigationview item
                    mNavigationView.setCheckedItem(R.id.nav_profile);

                    fragmentTransaction.replace(R.id.containerView, TabsInitFragment.newInstance(TabsInitFragment.TAB_PROFILE_DATA)).commit();
                    toolbar.setTitle(R.string.main_text_title);
                    break;
                default:

                    // Check and change background of navigationview item
                    mNavigationView.setCheckedItem(R.id.nav_user);

                    fragmentTransaction.replace(R.id.containerView, TabsInitFragment.newInstance(TabsInitFragment.TAB_BENEFITS)).commit();
                    lastSectionFragment = SECTION_BENEFITS;
                    toolbar.setTitle(R.string.main_text_title);
                    break;
            }
            okBackToolbarButton.setVisibility(View.GONE);
            settingToolbarAccess.setVisibility(View.VISIBLE);
            miniGamesToolbarAccess.setVisibility(View.VISIBLE);

        } else {
            super.onBackPressed();
        }
    }

    private void showFirstPageTutorial(){
        counter = 0;
        switch (lastSectionFragment) {
            case SECTION_MAIN:
            case SECTION_BENEFITS:
            case SECTION_MESSAGES:
            case SECTION_PROFILE_DATA:
                tutorial.setContentTitle(getString(R.string.tutorial_main_section_title));
                tutorial.setContentText(getString(R.string.tutorial_main_section_text_1));
                tutorial.setShowcase(Target.NONE, true);
                break;
            case SECTION_PREFERENCES:
                tutorial.setContentTitle(getString(R.string.tutorial_preferences_section_title));
                tutorial.setContentText(getString(R.string.tutorial_preferences_section_text_1));
                tutorial.setShowcase(Target.NONE, true);
                break;
            case SECTION_MINI_GAMES:
                tutorial.setContentTitle(getString(R.string.tutorial_mini_games_section_title));
                tutorial.setContentText(getString(R.string.tutorial_mini_games_section_text_1));
                tutorial.setShowcase(Target.NONE, true);
                break;
            case SECTION_ABOUT:
                try {
                    Field field = toolbar.getClass().getDeclaredField("mNavButtonView");
                    field.setAccessible(true);
                    View navView = (View) field.get(toolbar);
                    tutorial.setShowcase(new ViewTarget(navView), true);
                    tutorial.setContentTitle(getString(R.string.tutorial_nav_section_title));
                    tutorial.setContentText(getString(R.string.tutorial_nav_section_text_1));
                } catch (Exception e) {
                    tutorial.setShowcase(Target.NONE, true);
                    tutorial.setContentTitle(getString(R.string.tutorial_nav_section_title_alternative));
                    tutorial.setContentText(getString(R.string.tutorial_nav_section_text_1_alternative));
                }
                break;
            default:
                break; //TODO check possible errors
        }
        tutorial.show();
    }

    @Override
    public void onBenefitsFragmentInteraction(Uri uri) {
    }

    @Override
    public void goToProfileDataSection() {
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.containerView, TabsInitFragment.newInstance(TabsInitFragment.TAB_PROFILE_DATA)).commit();
        lastSectionFragment = SECTION_MAIN;
        lastSubsection = SECTION_PROFILE_DATA;
    }

    @Override
    public void onPreferencesFragmentInteraction(Uri uri) {

    }

    @Override
    public void refreshLanguage() {
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.containerView, new PreferencesFragment()).commit();
    }

    @Override
    public void onTabsInitFragmentInteraction(Uri uri) {

    }

    @Override
    public void changeSection(String sectionTag) {
        switch (sectionTag) {
            case TabsInitFragment.TAB_BENEFITS:

                // Check and change background of navigationview item
                mNavigationView.setCheckedItem(R.id.nav_user);

                lastSubsection = SECTION_BENEFITS;
                break;
            case TabsInitFragment.TAB_MESSAGES:

                // Check and change background of navigationview item
                mNavigationView.setCheckedItem(R.id.nav_messages);

                lastSubsection = SECTION_MESSAGES;
                break;
            case TabsInitFragment.TAB_PROFILE_DATA:

                // Check and change background of navigationview item
                mNavigationView.setCheckedItem(R.id.nav_profile);

                lastSubsection = SECTION_PROFILE_DATA;
                break;
            default:
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (lastSectionFragment) {
            case SECTION_MAIN:
            case SECTION_BENEFITS:
            case SECTION_MESSAGES:
            case SECTION_PROFILE_DATA:
                switch (counter) {
                    case 0:
                        ViewTarget target = new ViewTarget(((ViewGroup) ((TabLayout) findViewById(R.id.tabs)).getChildAt(0)).getChildAt(0));
                        tutorial.setContentTitle(getString(R.string.tutorial_user_section_title));
                        tutorial.setContentText(getString(R.string.tutorial_user_section_text_1));
                        tutorial.setShowcase(target, true);
                        break;
                    case 1:
                        ViewTarget target2 = new ViewTarget(((ViewGroup) ((TabLayout) findViewById(R.id.tabs)).getChildAt(0)).getChildAt(1));
                        tutorial.setContentTitle(getString(R.string.tutorial_messages_section_title));
                        tutorial.setContentText(getString(R.string.tutorial_messages_section_text_1));
                        tutorial.setShowcase(target2, true);
                        break;
                    case 2:
                        ViewTarget target3 = new ViewTarget(((ViewGroup) ((TabLayout) findViewById(R.id.tabs)).getChildAt(0)).getChildAt(2));
                        tutorial.setContentTitle(getString(R.string.tutorial_profile_section_title));
                        tutorial.setContentText(getString(R.string.tutorial_profile_section_text_1));
                        tutorial.setShowcase(target3, true);
                        break;
                    case 3:
                        try {
                            Field field = toolbar.getClass().getDeclaredField("mNavButtonView");
                            field.setAccessible(true);
                            View navView = (View) field.get(toolbar);
                            tutorial.setShowcase(new ViewTarget(navView), true);
                            tutorial.setContentTitle(getString(R.string.tutorial_nav_section_title));
                            tutorial.setContentText(getString(R.string.tutorial_nav_section_text_1));
                            tutorial.setStyle(R.style.CustomShowcaseTheme2);

                            break;
                        } catch (Exception e) {
                            tutorial.setShowcase(Target.NONE, true);
                            tutorial.setContentTitle(getString(R.string.tutorial_nav_section_title_alternative));
                            tutorial.setContentText(getString(R.string.tutorial_nav_section_text_1_alternative));
                            tutorial.setStyle(R.style.CustomShowcaseTheme2);

                            break;
                        }
                    default:
                        tutorial.hide();
                        tutorial.setStyle(R.style.CustomShowcaseTheme1);
                        break;
                }
                counter++;
                counter = counter % 5;

                break;
            case SECTION_PREFERENCES:
                switch (counter) {
                    case 0:
                        try {
                            Field field = toolbar.getClass().getDeclaredField("mNavButtonView");
                            field.setAccessible(true);
                            View navView = (View) field.get(toolbar);
                            tutorial.setShowcase(new ViewTarget(navView), true);
                            tutorial.setContentTitle(getString(R.string.tutorial_nav_section_title));
                            tutorial.setContentText(getString(R.string.tutorial_nav_section_text_1));
                            tutorial.setStyle(R.style.CustomShowcaseTheme2);
                            break;
                        } catch (Exception e) {
                            tutorial.setShowcase(Target.NONE, true);
                            tutorial.setContentTitle(getString(R.string.tutorial_nav_section_title_alternative));
                            tutorial.setContentText(getString(R.string.tutorial_nav_section_text_1_alternative));
                            tutorial.setStyle(R.style.CustomShowcaseTheme2);
                            break;
                        }
                    default:
                        tutorial.hide();
                        tutorial.setStyle(R.style.CustomShowcaseTheme1);

                }
                counter++;
                counter = counter % 2;
                break;
            default:
                tutorial.hide();
                break;
        }
    }

    // InteractionListener methods for access to different forms since UserProfileDataFragment

    @Override
    public void onPersonalDataFragmentInteraction(Uri uri) {
    }

    @Override
    public void goToEditPersonalDataForm() {
        goToForm(SFBConstantsAndCodes.PERSONAL_DATA_FORM_ID);
    }

    @Override
    public void goToTestRichmond() {
        goToForm(SFBConstantsAndCodes.RICHMOND_TEST_FORM_ID);
    }

    @Override
    public void goToTestFagerstrom() {
        goToForm(SFBConstantsAndCodes.FAGERSTROM_TEST_FORM_ID);
    }

    @Override
    public void goToPreviousSmokingHabitsForm() {
        goToForm(SFBConstantsAndCodes.PREVIOUS_SMOKING_HABITS_ID);
    }

    @Override
    public void goToQuittingAttemptDateForm() {
        goToForm(SFBConstantsAndCodes.START_QUITTING_ATTEMPT_ID);
    }

    // Close the current instance of the personalData fragment and create a new instance
    @Override
    public void refreshPersonalDataSection() {
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.containerView, TabsInitFragment.newInstance(TabsInitFragment.TAB_PROFILE_DATA)).commit();
    }

    // Auxiliary method for test forms
    public void goToForm(int idFormToAccess) {
        Intent intent = new Intent(this, FormActivity.class);
        intent.putExtra("idForm", idFormToAccess);
        startActivity(intent);
    }

    // TODO Currently, this method is unused.
    @Override
    public void setDateInDatePicker(int id, String title) {
        this.idButtonDatePicker = id;
        callDatePicker(title);
    }

    private void callDatePicker(String title) {
        DatePickerDialogFragment fragment = DatePickerDialogFragment.newInstance(title);
        fragment.show(getSupportFragmentManager(), "DatePicker");
    }

    // Change the button text to appear the selected date in datePicker
    @Override
    public void setDate(Calendar calendar) {
        ((EditText) findViewById(idButtonDatePicker)).setText(SFBDate.dateToString(calendar));
    }

    /**
     *  Create a {@link DataSet} to insert data into the History API, and
     *  then create and execute a {@link DataReadRequest} to verify the insertion succeeded.
     *  By using an {@link AsyncTask}, we can schedule synchronous calls, so that we can query for
     *  data after confirming that our insert was successful. Using asynchronous calls and callbacks
     *  would not guarantee that the insertion had concluded before the read request was made.
     *  An example of an asynchronous call using a callback can be found in the example
     *  on deleting data below.
     */
    private class ReadActiveTimeDataTask extends AsyncTask<Void, Void, Void> {

        SessionData sessionData = SessionData.getSessionData(MainActivity.this);

        protected Void doInBackground(Void... params) {
            Calendar previousDay = Calendar.getInstance();
            previousDay.add(Calendar.DAY_OF_WEEK,-1);

            if(true /*sessionData.getLastGoogleFitConnectionDate().before(previousDay) &&
                    !(sessionData.getRegisterDate().get(Calendar.DAY_OF_YEAR) == Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
                        && sessionData.getRegisterDate().get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR))*/) {
                // Begin by creating the query.
                DataReadRequest readRequest = queryFitnessData(sessionData.getRegisterDate());

                // [START read_dataset]
                // Invoke the History API to fetch the data with the query and await the result of
                // the read request.
                DataReadResult dataReadResult =
                        Fitness.HistoryApi.readData(mApiClient, readRequest).await(1, TimeUnit.MINUTES);
                // [END read_dataset]

                // For the sake of the sample, we'll print the data so we can see what we just added.
                // In general, logging fitness information should be avoided for privacy reasons.
                String dailyFitnessActivityLastDaysInMinutes = getDailyActivityLastDaysInMinutes(dataReadResult);

                if (!dailyFitnessActivityLastDaysInMinutes.equals("")) {
                    sessionData.setDailyFitnessActivityLastDays(dailyFitnessActivityLastDaysInMinutes);
                    sessionData.setLastGoogleFitConnectionDate(Calendar.getInstance());
                    sessionData.setIsFitnessActivityUpdated(false);
                }

            }
            return null;
        }
    }

    /**
     * Return a {@link DataReadRequest} for all step count changes in the past week.
     */
    public static DataReadRequest queryFitnessData(Calendar registerDate) {
        // [START build_read_data_request]

        Calendar midnight = Calendar.getInstance();
        midnight.set(Calendar.HOUR_OF_DAY, 0);
        midnight.set(Calendar.MINUTE, 0);
        midnight.set(Calendar.SECOND, 0);
        midnight.set(Calendar.MILLISECOND, 0);

        long endTime = midnight.getTimeInMillis();


        long startTime = 0;

        // TODO: Uncomment this if in the future exists a problem caused by an excess of information (xml request too big, update problems in the database, ...)
/*        Calendar lastDaysMidnight = midnight;
        lastDaysMidnight.add(Calendar.DAY_OF_YEAR, -10);

        if(registerDate.before(midnight)) // We request daily information for last X days or ...
            startTime = lastDaysMidnight.getTimeInMillis();
        else*/
            startTime = registerDate.getTimeInMillis(); // ... since the user registration date if s/he has not been registered for X days

        if(startTime > endTime - 86400000){
            Calendar previousDay = (Calendar) midnight.clone();
            previousDay.set(Calendar.DAY_OF_YEAR, -1);
            startTime = previousDay.getTimeInMillis();
        }
        java.text.DateFormat dateFormat = getDateInstance();
        //Log.i(TAG, "Range Start: " + dateFormat.format(startTime));
        //Log.i(TAG, "Range End: " + dateFormat.format(endTime));

        DataReadRequest readRequest = new DataReadRequest.Builder()
                .aggregate(DataType.TYPE_ACTIVITY_SEGMENT, DataType.AGGREGATE_ACTIVITY_SUMMARY)
                .setTimeRange(startTime, endTime, TimeUnit.MILLISECONDS)
                .bucketByActivitySegment(1, TimeUnit.MINUTES)
                .enableServerQueries()
                .build();
        return readRequest;
    }

    /**
     * Log a record of the query result. It's possible to get more constrained data sets by
     * specifying a data source or data type, but for demonstrative purposes here's how one would
     * dump all the data. In this sample, logging also prints to the device screen, so we can see
     * what the query returns, but your app should not log fitness information as a privacy
     * consideration. A better option would be to dump the data you receive to a local data
     * directory to avoid exposing it to other applications.
     */
    public static String getDailyActivityLastDaysInMinutes(DataReadResult dataReadResult) {

        List<Integer> dailyActivityLastDays = new ArrayList<>();
        Integer fitnessMinutesInADay = 0;
        long startDay = 0;

        if (dataReadResult.getBuckets().size() > 0) {
            Log.i(TAG, "Number of returned buckets of DataSets is: "
                    + dataReadResult.getBuckets().size());
            for (Bucket bucket : dataReadResult.getBuckets()) {



                long startTime = bucket.getStartTime(TimeUnit.MILLISECONDS);
                long endTime = bucket.getEndTime(TimeUnit.MILLISECONDS);
                int activeMinutes = (int) ((endTime - startTime) / (60 * 1000));
                if (!isActiveType(bucket.getActivity())) {
                    activeMinutes = 0;
                }

                if(startDay == 0)
                {
                    startDay = startTime;
                }
                //Log.d("WALKIRIA", SFBDate.dateToString(startDay)+ " - " +SFBDate.dateToString(startTime));

                if(SFBDate.dateToString(startDay).equals(SFBDate.dateToString(startTime))) {
                    fitnessMinutesInADay += activeMinutes;
                }
                else{
                    dailyActivityLastDays.add(fitnessMinutesInADay);
                    fitnessMinutesInADay = activeMinutes;
                    startDay = startTime;
                }

            }
            dailyActivityLastDays.add(fitnessMinutesInADay);
            // Log.i(TAG, "Active time the last seven days (in minutes)" + dailyActivityLastDays.toString());
        }

        return dailyActivityLastDays.toString();
        // [END parse_read_data_result]
    }

    /**
     * Returns true of false depending on if the passed activity is one of our "active" activities
     *
     * @param activity to validate
     * @return is activity "active"
     */
    private static boolean isActiveType(String activity) {
        switch (activity) {
            case FitnessActivities.WALKING:
            case FitnessActivities.WALKING_FITNESS:
            case FitnessActivities.WALKING_NORDIC:
            case FitnessActivities.WALKING_STROLLER:
            case FitnessActivities.WALKING_TREADMILL:
            case FitnessActivities.RUNNING:
            case FitnessActivities.RUNNING_JOGGING:
            case FitnessActivities.RUNNING_SAND:
            case FitnessActivities.RUNNING_TREADMILL:
            case FitnessActivities.BIKING:
            case FitnessActivities.BIKING_HAND:
            case FitnessActivities.BIKING_MOUNTAIN:
            case FitnessActivities.BIKING_ROAD:
            case FitnessActivities.BIKING_SPINNING:
            case FitnessActivities.BIKING_STATIONARY:
            case FitnessActivities.BIKING_UTILITY:
            case FitnessActivities.AEROBICS:
            case FitnessActivities.STAIR_CLIMBING:
            case FitnessActivities.SWIMMING:
            case FitnessActivities.SWIMMING_OPEN_WATER:
            case FitnessActivities.SWIMMING_POOL:
                return true;
            default:
                return false;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(AUTH_PENDING, authInProgress);
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public class UpdateFirebaseTokenTask extends AsyncTask<Void, Void, Boolean> {

        Context context;


        public UpdateFirebaseTokenTask(Context context){
            this.context = context;
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected Boolean doInBackground(Void... voids) {

            GenerateXMLFile file = GenerateXMLFile.getInstance();

            boolean isHttpResponseCorrect = false;

            // Check if exists an internet connection
            if (XMLHttpPost.isConnectedToInternet(getApplicationContext())) {
                // SEND HTTP POST REQUEST
                String responseXML = null;

                // Specific xml request using the values
                String fileXMLRequest = file.updateToken();

                try {
                    //Introduce XML and catch server response
                    responseXML = XMLHttpPost.envioXmlHttpPost(fileXMLRequest, getApplicationContext(),
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    getApplicationContext()).getUserCredentials()) );
                } catch (CertificateException | NoSuchAlgorithmException | KeyManagementException | IOException | KeyStoreException e) {
                    e.printStackTrace();
                }
                isHttpResponseCorrect = responseXML.equals("created");
            }

            return isHttpResponseCorrect;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            mUpdateTokenTask = null;

            if(success) {
               sessionData.setIsFirebaseTokenUpdatedInServer(true);
            }
        }
        @Override
        protected void onCancelled() {
            mUpdateTokenTask = null;
            super.onCancelled();
        }

    }


    private class SendAnalyticsTask extends AsyncTask<Void, Void, List<Boolean>> {

        Context context;

        SessionData sessionData = SessionData.getSessionData(context);
        LocalDataBaseHelper db;

        private SendAnalyticsTask(Context context) {
            this.context = context;
            db = new LocalDataBaseHelper(context);
        }

        @Override
        protected List<Boolean> doInBackground(Void... params) {

            List<Boolean> sendCorrectly = new ArrayList<>();

            String responseXML2 = null;
            String responseXML3 = null;
            String responseXML4 = null;
            String responseXML5 = null;
            String responseXML6 = null;

            GenerateXMLFile file = GenerateXMLFile.getInstance();

            //Sending message interaction statistics
            List<SFBMessageInteractionAnalytic> SFBMessageInteractionAnalytics = db.selectMessagesInteractionsToSend();
            if (SFBMessageInteractionAnalytics.size() > 5 && XMLHttpPost.isConnectedToInternet(context)) {
                String fileXMLRequest2 = file.addMessageInteractions(SFBMessageInteractionAnalytics);
                try {
                    //Introduce XML and catch server response
                    responseXML2 = XMLHttpPost.envioXmlHttpPost(fileXMLRequest2, context,
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    context).getUserCredentials()));

                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }
            sendCorrectly.add(responseXML2 != null && responseXML2.equals("created"));


            //Sending app interaction statistics
            List<SFBAppInteractionAnalytic> SFBAppInteractionAnalytics = db.selectAppInteractions();
            if (SFBAppInteractionAnalytics.size() > 10 && XMLHttpPost.isConnectedToInternet(context)) {
                String fileXMLRequest3 = file.addAppInteraction(SFBAppInteractionAnalytics);
                try {
                    //Introduce XML and catch server response
                    responseXML3 = XMLHttpPost.envioXmlHttpPost(fileXMLRequest3, context,
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    context).getUserCredentials()));

                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }
            sendCorrectly.add(responseXML3 != null && responseXML3.equals("created"));

            //Sending app configuration updates
            if (!sessionData.getIsConfigurationUpdated() && XMLHttpPost.isConnectedToInternet(context)) {

                Integer code = sessionData.getMuteNotifications();
                Calendar notDisturbUntil = sessionData.getMuteNotificationsUntil();

                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                String timestampToSend = simpleDateFormat.format(notDisturbUntil.getTime());
                Resources res = getResources();
                Configuration conf = res.getConfiguration();
                String lang = conf.locale.getLanguage();
                String fileXMLRequest4 = file.setConfiguration(code, timestampToSend, lang);
                try {
                    //Introduce XML and catch server response
                    responseXML4 = XMLHttpPost.envioXmlHttpPost(fileXMLRequest4, context,
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    context).getUserCredentials()));

                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }
            sendCorrectly.add(responseXML4 != null && responseXML4.equals("created"));

            if(!sessionData.getIsFitnessActivityUpdated() && XMLHttpPost.isConnectedToInternet(context)){

                String dailyFitnessString = sessionData.getDailyFitnessActivityLastDays();
                List<String> dailyFitnessActivityLastDays = Arrays.asList(dailyFitnessString.substring(1,dailyFitnessString.length()-1).split(","));

                List<String> formattedFitnessActivityDates = new ArrayList<>();

                Calendar fitnessActivityDate = sessionData.getLastGoogleFitConnectionDate();
                fitnessActivityDate.add(Calendar.DAY_OF_YEAR, - dailyFitnessActivityLastDays.size());
                for(String dailyFitnessActivity : dailyFitnessActivityLastDays) {
                    formattedFitnessActivityDates.add(SFBDate.dateToString(fitnessActivityDate.getTime()));
                    fitnessActivityDate.add(Calendar.DAY_OF_YEAR, 1);
                }


                String fileXMLRequest5 = file.addFitnessActivity(dailyFitnessActivityLastDays, formattedFitnessActivityDates);
                try {
                    //Introduce XML and catch server response
                    responseXML5 = XMLHttpPost.envioXmlHttpPost(fileXMLRequest5, context,
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    context).getUserCredentials()));

                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }
            sendCorrectly.add(responseXML5 != null && responseXML5.equals("created"));


            //Sending app interaction statistics
            List<SFBMiniGameAnalytics> miniGameActivities = db.selectMiniGameActivities();
            if (miniGameActivities.size() > 5 && XMLHttpPost.isConnectedToInternet(context)) {
                String fileXMLRequest6 = file.addMiniGameActivity(miniGameActivities);
                try {
                    //Introduce XML and catch server response
                    responseXML6 = XMLHttpPost.envioXmlHttpPost(fileXMLRequest6, context,
                            SFBEncode.encodeStringBase64(SessionData.getSessionData(
                                    context).getUserCredentials()));

                } catch (CertificateException | IOException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }
            sendCorrectly.add(responseXML6 != null && responseXML6.equals("created"));
            return sendCorrectly;
        }

        @Override
        protected void onPostExecute(final List<Boolean> success) {
            mSendAnalyticsTask = null;

            if (success.get(0)) {
                db.deleteMessageInteractionsToSend();
            }
            if (success.get(1)) {
                db.deleteAppInteractions();
            }
            if (success.get(2)) {
                sessionData.setIsConfigurationUpdated(true);
            }
            if(success.get(3)){
                sessionData.setIsFitnessActivityUpdated(true);
            }
            if(success.get(4)){
                db.deleteMiniGamesActivity();
            }
        }

        @Override
        protected void onCancelled() {
            mSendAnalyticsTask = null;
            super.onCancelled();
        }
    }
}
