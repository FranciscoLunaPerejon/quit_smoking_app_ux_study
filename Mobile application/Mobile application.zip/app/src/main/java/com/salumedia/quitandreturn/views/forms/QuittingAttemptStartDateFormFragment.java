package com.salumedia.quitandreturn.views.forms;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.SFBFragment;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;

import java.util.Calendar;



/**
 * Created by Francisco on 28/4/17.
 */

/**
 * A fragment that shows the start quitting period form
 */
public class QuittingAttemptStartDateFormFragment extends SFBFragment {

    // invoke to a datePickerDialog besides to show the calendar in this fragment.

    // Tag used to identify the fragment and for analytical purpose
    public static final String TAG = "START_QUITTING_PERIOD_FORM";


    DatePicker startQuittingAttempt;

    // Auxiliary view to inflate the fragment. It is used in auxiliary methods, so it is set as an
    // attribute of the class
    View rootView;

    // Default necessary constructor
    public QuittingAttemptStartDateFormFragment() {
    }

    // Constructor that allow receive information from the invoking class
    public static QuittingAttemptStartDateFormFragment newInstance(Bundle arguments){

        QuittingAttemptStartDateFormFragment f =  new QuittingAttemptStartDateFormFragment();
        //Extract information if exists
        if(arguments != null){
            f.setArguments(arguments);
        }
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Not View attributes instantiation
        section_name = SFBConstantsAndCodes.ANALYTIC_SECTION_ADD_QUITTING_ATTEMPT; // Analysis purpose
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Inflating the dialog fragment
        rootView = inflater.inflate(R.layout.form_fragment_start_quitting_attempt, null);

        // Getting the current date
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        // View date attribute instantiation and show current date on it
        startQuittingAttempt = (DatePicker) rootView.findViewById(R.id.quitting_attempt_date);
        startQuittingAttempt.updateDate(year, month, day);


        return rootView;
    }
}
