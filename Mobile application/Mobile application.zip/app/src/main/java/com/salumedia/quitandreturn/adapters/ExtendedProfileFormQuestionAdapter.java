package com.salumedia.quitandreturn.adapters;

import android.content.Context;
import android.graphics.PorterDuff;
import android.support.annotation.IdRes;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.model.SFBExtendedProfileFormQuestion;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.views.forms.ExtendedProfileFormActivity;

import java.util.Arrays;
import java.util.List;


/**
 * Created by Francisco on 16/6/17.
 */

public class ExtendedProfileFormQuestionAdapter extends RecyclerView.Adapter<ExtendedProfileFormQuestionAdapter.QuestionViewHolder> {

    private List<SFBExtendedProfileFormQuestion> sfbExtendedProfileFormQuestions;

    private Context mContext;

    public ExtendedProfileFormQuestionAdapter(Context context, List<SFBExtendedProfileFormQuestion> sfbExtendedProfileFormQuestions){
        this.sfbExtendedProfileFormQuestions = sfbExtendedProfileFormQuestions;
        mContext = context;
    }

    public static class QuestionViewHolder extends RecyclerView.ViewHolder{

        RelativeLayout questionLayout;
        TextView questionTitle;
        TextView questionDescription;
        TextView questionTypeResponseExplanation;
        LinearLayout answerView;


        public QuestionViewHolder(View itemView) {
            super(itemView);
            questionLayout = (RelativeLayout) itemView.findViewById(R.id.extended_form_question_layout);
            questionTitle = (TextView) itemView.findViewById(R.id.question_title);
            questionDescription = (TextView) itemView.findViewById(R.id.question_description);
            questionTypeResponseExplanation = (TextView) itemView.findViewById(R.id.question_type_response_explanation);
            answerView = (LinearLayout) itemView.findViewById(R.id.question_answer_options_view);
        }
    }

    @Override
    public QuestionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_extendend_profile_form_question, parent, false);
        QuestionViewHolder vh = new QuestionViewHolder(v);

        return vh;
    }

    @Override
    public void onBindViewHolder(QuestionViewHolder holder, int position) {

        final SFBExtendedProfileFormQuestion question = sfbExtendedProfileFormQuestions.get(position);

        holder.questionTitle.setText(question.getTitle());
        holder.questionDescription.setText(question.getDescription());

        switch (question.getTypeQuestion()){
            case ExtendedProfileFormActivity.RATING_BAR_QUESTION_KEY:
                holder.questionTypeResponseExplanation.setText(R.string.extended_form_ratingbar_explanation);
                RatingBar questionRatingBar = new RatingBar(mContext, null, android.R.attr.ratingBarStyle);
                questionRatingBar.getProgressDrawable().setColorFilter(mContext.getResources().getColor(R.color.colorAccent), PorterDuff.Mode.SRC_ATOP);
                questionRatingBar.setNumStars(question.getNumberOfAnswers());
                questionRatingBar.setStepSize(1);
                LinearLayout.LayoutParams questionResponseViewParams = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.WRAP_CONTENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT);
                questionRatingBar.setLayoutParams(questionResponseViewParams);
                questionRatingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                    @Override
                    public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                        Boolean[] response = question.getAnswerResponses();
                        Arrays.fill(response, false);
                        response[Float.valueOf(rating).intValue()-1] = true;
                        question.setAnswerResponses(response);
                    }
                });
                setPreviousRatingBarResponse(questionRatingBar, question.getAnswerResponses());
                holder.answerView.addView(questionRatingBar);
                holder.answerView.setGravity(Gravity.CENTER);
                break;
            case ExtendedProfileFormActivity.CHECK_BOX_QUESTION_KEY:
                holder.questionTypeResponseExplanation.setText(R.string.extended_form_checkbox_explanation);
                for(int i = 0; i<question.getNumberOfAnswers();i++){
                    CheckBox questionCheckBox = new CheckBox(mContext);
                    questionCheckBox.setText(question.getAnswerTexts()[i]);
                    setPreviousCheckBoxCheckedState(questionCheckBox, question.getAnswerResponses(), i);
                    questionCheckBox.setOnCheckedChangeListener(new ChangeCheckedQuestionListener(i, question));
                    holder.answerView.addView(questionCheckBox);
                }
                break;
            case ExtendedProfileFormActivity.RADIO_BUTTON_QUESTION_KEY:
                holder.questionTypeResponseExplanation.setText(R.string.extended_form_radiobutton_explanation);
                RadioGroup questionRadioGroup = new RadioGroup(mContext);
                questionRadioGroup.setOrientation(RadioGroup.VERTICAL);
                for(int i = 0; i<question.getNumberOfAnswers();i++){
                    RadioButton questionRadioButton = new RadioButton(mContext);
                    questionRadioButton.setText(question.getAnswerTexts()[i]);
                    questionRadioGroup.addView(questionRadioButton);

                }
                questionRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                        Boolean[] response = question.getAnswerResponses();
                        Arrays.fill(response, false);
                        response[group.indexOfChild(group.findViewById(checkedId))] = true;
                        question.setAnswerResponses(response);
                    }
                });
                setPreviousRadioGroupResponse(questionRadioGroup, question.getAnswerResponses());
                if(position == 0){
                    SessionData sessionData = SessionData.getSessionData(mContext);
                    if(sessionData.getPatientCode().equals(SessionData.NOT_HAVE_PATIENT_CODE)){
                        ((RadioButton) questionRadioGroup.getChildAt(1)).setChecked(true);
                    }else {
                        ((RadioButton) questionRadioGroup.getChildAt(0)).setChecked(true);
                    }
                }
                holder.answerView.addView(questionRadioGroup);
                break;
        }
        if(position == 0){
            holder.questionLayout.setVisibility(View.GONE);
        }

    }

    @Override
    public int getItemCount() {
        return sfbExtendedProfileFormQuestions.size();
    }


    private void setPreviousRatingBarResponse(RatingBar questionRatingBar, Boolean[] answerResponses) {
        for(int i = 0; i<answerResponses.length; i++){
            if(answerResponses[i]){
                questionRatingBar.setRating(i+1);
            }
        }
    }

    private void setPreviousCheckBoxCheckedState(CheckBox questionCheckBox, Boolean[] answerResponses, int i) {
        questionCheckBox.setChecked(answerResponses[i]);
    }

    private void setPreviousRadioGroupResponse(RadioGroup questionRadioGroup, Boolean[] answerResponses) {
        for(int i = 0; i<answerResponses.length; i++){
            if(answerResponses[i]){
                ((RadioButton) questionRadioGroup.getChildAt(i)).setChecked(answerResponses[i]);
                break;
            }
        }

    }

    private class ChangeCheckedQuestionListener implements CompoundButton.OnCheckedChangeListener{

        private SFBExtendedProfileFormQuestion question;
        private int checkPosition;

        ChangeCheckedQuestionListener(int checkPosition, SFBExtendedProfileFormQuestion question){
            this.question = question;
            this.checkPosition = checkPosition;
        }

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            Boolean[] responses = question.getAnswerResponses();
            responses[checkPosition] = isChecked;
            question.setAnswerResponses(responses);
        }
    }


}
