package com.salumedia.quitandreturn.model;

import android.content.Context;
import android.content.res.Resources;

import com.salumedia.quitandreturn.R;
import com.salumedia.quitandreturn.session.local.SessionData;
import com.salumedia.quitandreturn.utils.SFBConstantsAndCodes;
import com.salumedia.quitandreturn.utils.SFBCurrencyConversions;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Random;




/**
 * Created by joaquin on 11/5/16.
 */

public class SFBNotification {

    private String senderId;
    private String receivedId;
    private String text;
    private Integer type;
    private Calendar sentDate;
    private String id;
    //badges
    private Integer idDrawableCode;
    private Integer achieved;
    //from user or server
    private String photoUrl;
    private String userName;
    //id message in server
    private String idServer;
    private Boolean favorite;
    private Boolean read;



    public SFBNotification() {
    }

    public SFBNotification(String senderId, String receivedId, String text, Integer type, Calendar sentDate) {
        this.senderId = senderId;
        this.receivedId = receivedId;
        this.sentDate = sentDate;
        this.text = text;
        this.type = type;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getReceivedId() {
        return receivedId;
    }

    public void setReceivedId(String receivedId) {
        this.receivedId = receivedId;
    }

    public Calendar getSentDate() {
        return sentDate;
    }

    public void setSentDate(Calendar sentDate) {
        this.sentDate = sentDate;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getIdDrawableCode() {
        return idDrawableCode;
    }

    public void setIdDrawableCode(Integer idDrawableCode) {
        this.idDrawableCode = idDrawableCode;
    }

    public Integer getAchieved() {
        return achieved;
    }

    public void setAchieved(Integer achieved) {
        this.achieved = achieved;
    }

    public String getPhotoUrl() {
        return photoUrl == null ? "" : photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public String getUserName() {
        return userName == null ? "" : userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getIdServer(){
        return idServer;
    }

    public void setIdServer(String idServer){
        this.idServer = idServer;
    }

    public Boolean getFavorite() {
        return favorite;
    }

    public void setFavorite(Boolean favorite) {
        this.favorite = favorite;
    }

    public Boolean getRead() {
        return read;
    }

    public void setRead(Boolean read) {
        this.read = read;
    }


    public static ArrayList<SFBNotification> createAchieveNotifications(SFBSmokingData smokingData, Context context) {
        final String userId = SessionData.getSessionData(context).getUserId();
        final List<SFBQuittingAttempt> sfbQuittingAttempts = smokingData.getQuittingAttempts();
        int numberQuittingPeriods = sfbQuittingAttempts.size();
        final float diarySpentMoney = sfbQuittingAttempts.get(numberQuittingPeriods-1).getWeeklyTobaccoExpenditure() / 7;
        final String currency = sfbQuittingAttempts.get(numberQuittingPeriods-1).getCurrency();
        final Float cigarettes = sfbQuittingAttempts.get(numberQuittingPeriods-1).getPreviousDailyCigarettes();
        final Float cigarettesPerHour = cigarettes / 24;

        Resources resources = context.getResources();
        ArrayList<SFBNotification> notifications = new ArrayList<>();

        String[] savings;
        String[] savingsMessages;

        switch (currency){
            case SFBCurrencyConversions.symbolTaiwaneseDollar:
                savings = context.getResources().getStringArray(R.array.saving_badges_twd);
                savingsMessages = context.getResources().getStringArray(R.array.saving_badges_message_twd);
                break;
            case SFBCurrencyConversions.symbolDollar:
                savings = context.getResources().getStringArray(R.array.saving_badges_dollars);
                savingsMessages = context.getResources().getStringArray(R.array.saving_badges_message_dollars);
                break;
            case SFBCurrencyConversions.symbolYuan:
                savings = context.getResources().getStringArray(R.array.saving_badges_yuan);
                savingsMessages = context.getResources().getStringArray(R.array.saving_badges_message_yuan);
                break;
            case SFBCurrencyConversions.symbolBritishPound:
                savings = context.getResources().getStringArray(R.array.saving_badges_british_pound);
                savingsMessages = context.getResources().getStringArray(R.array.saving_badges_message_british_pound);
                break;
            default:
                savings = context.getResources().getStringArray(R.array.saving_badges_euros);
                savingsMessages = context.getResources().getStringArray(R.array.saving_badges_message_euros);
                break;
        }

        for (int i = 0; i < savings.length; i++) {
            String item = savings[i];
            String itemMessage = savingsMessages[i];
            Integer saving = Integer.parseInt(item);
            Float numberOfDays = saving / diarySpentMoney;
            Calendar date = (Calendar) sfbQuittingAttempts.get(numberQuittingPeriods-1).getQuittingDate().clone();
            date.add(Calendar.DATE, Math.round(numberOfDays));
            SFBNotification notification = new SFBNotification(SFBConstantsAndCodes.NOTIFICATION_INTERNAL_BADGE,
                    userId,
                    itemMessage,
                    SFBConstantsAndCodes.NOTIFICATION_TYPE_SAVINGS,
                    date);
            notification.setIdDrawableCode(SFBConstantsAndCodes.SAVINGS_DRAWABLES[i]);
            notifications.add(notification);
        }

        String[] smokeFree = resources.getStringArray(R.array.smoke_free_badges);
        String[] smokeFreeMessages = resources.getStringArray(R.array.smoke_free_badges_message);
        for (int i = 0; i < smokeFree.length; i++) {
            String item = smokeFree[i];
            String itemMessage = smokeFreeMessages[i];
            Integer smokeFreeDay = Integer.parseInt(item);
            Calendar date = (Calendar) sfbQuittingAttempts.get(numberQuittingPeriods-1).getQuittingDate().clone();
            date.add(Calendar.DATE, smokeFreeDay);
            SFBNotification notification = new SFBNotification(SFBConstantsAndCodes.NOTIFICATION_INTERNAL_BADGE,
                    userId,
                    itemMessage,
                    SFBConstantsAndCodes.NOTIFICATION_TYPE_SMOKEFREE,
                    date);
            notification.setIdDrawableCode(SFBConstantsAndCodes.SMOKE_FREE_DRAWABLES[i]);
            notifications.add(notification);
        }


        String[] hoursRegainedInCigarettes = resources.getStringArray(R.array.hours_regained_badges_in_cigarettes);
        String[] hoursRegainedMessages = resources.getStringArray(R.array.hours_regained_badges_message);
        for (int i = 0; i < hoursRegainedInCigarettes.length; i++) {
            String item = hoursRegainedInCigarettes[i];
            String itemMessage = hoursRegainedMessages[i];
            Calendar date = (Calendar) sfbQuittingAttempts.get(numberQuittingPeriods-1).getQuittingDate().clone();
            date.add(Calendar.HOUR_OF_DAY, Math.round(Integer.parseInt(item) / cigarettesPerHour));
            SFBNotification notification = new SFBNotification(SFBConstantsAndCodes.NOTIFICATION_INTERNAL_BADGE,
                    userId,
                    itemMessage,
                    SFBConstantsAndCodes.NOTIFICATION_TYPE_HOURS_REGAINED,
                    date);
            notification.setIdDrawableCode(SFBConstantsAndCodes.HOURS_REGAINED_DRAWABLES[i]);
            notifications.add(notification);
        }

        String[] notSmokedCigarettes = resources.getStringArray(R.array.cigarettes_not_smoked_badges);
        String[] notSmokedCigarettesMessages = resources.getStringArray(R.array.cigarettes_not_smoked_badges_message);
        for (int i = 0; i < notSmokedCigarettes.length; i++) {
            String item = notSmokedCigarettes[i];
            String itemMessage = notSmokedCigarettesMessages[i];
            Integer cigarettesNotSmoked = Integer.parseInt(item);
            Float cigarettesToHours = cigarettesNotSmoked / cigarettesPerHour;
            Calendar date = (Calendar) sfbQuittingAttempts.get(numberQuittingPeriods-1).getQuittingDate().clone();
            date.add(Calendar.HOUR_OF_DAY, Math.round(cigarettesToHours));
            SFBNotification notification = new SFBNotification(SFBConstantsAndCodes.NOTIFICATION_INTERNAL_BADGE,
                    userId,
                    itemMessage,
                    SFBConstantsAndCodes.NOTIFICATION_TYPE_CIGARETTES_NOT_SMOKED,
                    date);
            notification.setIdDrawableCode(SFBConstantsAndCodes.CIGARETTES_DRAWABLES[i]);
            notifications.add(notification);
        }

        String[] otherNotifications = resources.getStringArray(R.array.other_badges_in_minutes);
        String[] otherNotificationsMessage = resources.getStringArray(R.array.other_badges_messages);
        for (int i = 0; i < otherNotifications.length; i++) {
            String item = otherNotifications[i];
            String itemMessage = otherNotificationsMessage[i];
            Calendar date = (Calendar) sfbQuittingAttempts.get(numberQuittingPeriods-1).getQuittingDate().clone();
            date.add(Calendar.MINUTE, Integer.parseInt(item));
            SFBNotification notification = new SFBNotification(SFBConstantsAndCodes.NOTIFICATION_INTERNAL_BADGE,
                    userId,
                    itemMessage,
                    SFBConstantsAndCodes.NOTIFICATION_TYPE_OTHER,
                    date);
            notification.setIdDrawableCode(SFBConstantsAndCodes.OTHER_DRAWABLES[i]);
            notifications.add(notification);
        }

        return notifications;
    }

    public static SFBNotification getWelcomeNotification(Calendar calendar, Context context){
        return new SFBNotification("internalCraving",
                "New user", context.getString(R.string.welcome_message_box_notification),
                SFBConstantsAndCodes.NOTIFICATION_TYPE_INFORMATION,
                calendar);
    }


    public static SFBNotification getCravingNotification(Context context) {

        final String internalCraving = "internalCraving";
        String name = SessionData.getSessionData(context).getUserNick();
        String gender = SessionData.getSessionData(context).getGender();
        String[] cravingPool = context.getResources().getStringArray(R.array.craving_message_pool);
        String[] cravingPoolGender = gender.equals(SFBConstantsAndCodes.USER_GENDER_FEMALE) ?
                context.getResources().getStringArray(R.array.craving_message_pool_female) :
                context.getResources().getStringArray(R.array.craving_message_pool_male);
        ArrayList<String> cravingList = new ArrayList<>();
        Collections.addAll(cravingList, cravingPool);
        Collections.addAll(cravingList, cravingPoolGender);
        Random random = new Random();
        int position = random.nextInt(cravingPool.length);
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.SECOND, random.nextInt(30 - 10) + 10);
        String text = String.format(cravingList.get(position), name);
        return new SFBNotification(internalCraving,
                SessionData.getSessionData(context).getUserId(),
                text,
                SFBConstantsAndCodes.NOTIFICATION_TYPE_CRAVING,
                calendar);
    }

    public static SFBNotification[] getLastAndNextAchieveNotification(ArrayList<SFBNotification> arrayList, Context context) {
        Calendar calendar = Calendar.getInstance();

        SFBNotification lastNotification = new SFBNotification();
        SFBNotification previousNotification = new SFBNotification();

        int selectedIndex = -1;
        long minimalDistance = Long.MAX_VALUE;
        long timeLastNotification = 0;

        for (int index = 0; index < arrayList.size(); index++) {
            SFBNotification notification = arrayList.get(index);
            if (notification.sentDate.after(calendar) && (minimalDistance > notification.sentDate.getTimeInMillis() - calendar.getTimeInMillis())) {
                minimalDistance = notification.sentDate.getTimeInMillis() - calendar.getTimeInMillis();
                selectedIndex = index;
            }
            if (timeLastNotification < notification.sentDate.getTimeInMillis()) {
                lastNotification = notification;
                timeLastNotification = lastNotification.sentDate.getTimeInMillis();
            }
        }

        SFBNotification selectedNotification;
        if (selectedIndex < 0) {
            selectedNotification = lastNotification;
            lastNotification.setSentDate(SessionData.getSessionData(context).getQuittingDate());
        } else {
            selectedNotification = arrayList.get(selectedIndex);
            if (selectedIndex > 0) {
                previousNotification = arrayList.get(selectedIndex - 1);
            }
        }

        return new SFBNotification[]{selectedNotification, previousNotification};
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
